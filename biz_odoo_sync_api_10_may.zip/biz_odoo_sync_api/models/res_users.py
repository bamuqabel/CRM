# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class ResUsers(models.Model):
    _inherit = "res.users"

    api_ref_code = fields.Char(reaonly=True)

class ResPartner(models.Model):
    _inherit = "res.partner"

    api_ref_code = fields.Char(reaonly=True)
