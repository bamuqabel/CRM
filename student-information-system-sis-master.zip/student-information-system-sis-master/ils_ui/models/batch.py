
from odoo import models, fields, api, _
import datetime
from odoo.exceptions import UserError
from datetime import timedelta

class ilsBatch(models.Model):
    _name = 'ils.batch'
    _description = 'Batch'
    _rec_name = 'name'

    code = fields.Char(string='Code', required=True)
    name = fields.Char()
    program_id = fields.Many2one(comodel_name='product.template', string='Program', domain="([('is_program', '=', True)])")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    s_date = fields.Date(string='Start Date')
    e_date = fields.Date(string='End Date')
    module_id = fields.Many2one(comodel_name='ils.modules')
    enrollment_student_group_ids = fields.One2many(comodel_name='ils.enrollment.student.group', inverse_name='batch_id', string="Enrollment Groups")
    is_student_enrolled = fields.Boolean(string="Is student enrolled", default=False, compute="_compute_enroll_student")
    timesheet_saved = fields.Boolean(string="Timesheet Saved", default=False)

    def _compute_enroll_student(self):
        for record in self:
            if record.program_id:
                enrollments = self.env['ils.enrollment'].search([('program_id', '=', record.program_id.id)])
                record.is_student_enrolled = True if enrollments else False

    @api.onchange('program_id')
    def onchange_program_id(self):
        for record in self:
            if record.program_id:
                enrollments = self.env['ils.enrollment'].search([('program_id', '=', record.program_id.id)])
                record.is_student_enrolled = True if enrollments else False

    @api.onchange('s_date')
    def onchange_s_date(self):
        for record in self:
            if record.s_date and record.program_id:
                program_duration = record.program_id.duration
                duration_days = program_duration * 30
                end_date = record.s_date + datetime.timedelta(days=duration_days)
                record.e_date = end_date

    def action_draft_timesheet(self):
        batch = self
        timetable_obj = self.env['ils.timetable']
        start_date_record = timetable_obj.search([
            ('batch_id', '=', batch.id),
            ('state', '=', 'draft')
            ], order='date', limit=1)
        end_date_record = timetable_obj.search([
            ('batch_id', '=', batch.id),
            ('state', '=', 'draft')
            ], order='date desc', limit=1)
        if start_date_record and end_date_record:
            # generate timesheet view
            action_context = {'timesheet_batch_id': batch.id,
                            'timesheet_start_date': start_date_record.date,
                            'timesheet_end_date': end_date_record.date}
            return {
                'name': 'Batch Timesheet',
                'type': 'ir.actions.client',
                'tag': 'timesheet.gantt_view',
                'context': action_context,
            }
        else:
            raise UserError(_("Timesheet not created! Please create timesheet first."))

    def action_saved_timesheet(self):
        batch = self
        timetable_obj = self.env['ils.timetable']
        start_date_record = timetable_obj.search([
            ('batch_id', '=', batch.id),
            ('state', '=', 'confirm')
            ], order='date', limit=1)
        end_date_record = timetable_obj.search([
            ('batch_id', '=', batch.id),
            ('state', '=', 'confirm')
            ], order='date desc', limit=1)
        if start_date_record and end_date_record:
            # generate timesheet view
            action_context = {'timesheet_batch_id': batch.id,
                            'timesheet_start_date': start_date_record.date,
                            'timesheet_end_date': end_date_record.date}
            return {
                'name': 'Batch Timesheet',
                'type': 'ir.actions.client',
                'tag': 'timesheet.gantt_view',
                'context': action_context,
            }
        else:
            raise UserError(_("Timesheet not created! Please create timesheet first."))

    def remove_branch_groups(self):
        batch_id = self
        # for Delete Existing Groups
        existing_groups = self.env['ils.enrollment.student.group'].search([('batch_id', '=', batch_id.id)])
        if existing_groups:
            if len(existing_groups) > 1:
                # Delete enrollments from groups
                sql_query = """DELETE
                                FROM enrollment_student_group_rel
                                WHERE group_id in """ + str(tuple(existing_groups.ids)) + """
                                """
                self.env.cr.execute(sql_query)
                # Delete groups from enrollments
                sql_query = """DELETE
                                FROM enrollment_group_rel
                                WHERE group_id in """ + str(tuple(existing_groups.ids)) + """
                                """
                self.env.cr.execute(sql_query)
            else:
                # Delete enrollments from groups
                sql_query = """DELETE
                                FROM enrollment_student_group_rel
                                WHERE group_id = """ + str(existing_groups.ids[0]) + """
                                """
                self.env.cr.execute(sql_query)
                # Delete groups from enrollments
                sql_query = """DELETE
                                FROM enrollment_group_rel
                                WHERE group_id = """ + str(existing_groups.ids[0]) + """
                                """
                self.env.cr.execute(sql_query)
            existing_groups.unlink() # Delete existing_groups

    def action_generate_timesheet(self):
        timetable_obj =  self.env['ils.timetable']
        timetable_line_obj =  self.env['ils.timetable.line']
        batch_obj = self.env['ils.batch']
        modue_obj = self.env['ils.modules']
        hr_holiday_obj = self.env['hr.holidays.public.line']
        academy_dayoff_obj = self.env['ils.academy.dayoff']
        time_table = {}
        batch_id= self
        academy_id = batch_id.academy_id
        start_date = batch_id.s_date
        end_date = batch_id.e_date
        batch_groups = batch_id.enrollment_student_group_ids
        time_slot = batch_id.get_timetable_timeslot()
        advance_start_date = end_date + datetime.timedelta(days=1)

        normal_module_groups = batch_id.enrollment_student_group_ids.filtered(lambda x: x.module_id.module_level == False)
        basic_module_groups = batch_id.enrollment_student_group_ids.filtered(lambda x: x.module_id.module_level == 'basic')
        basic_batch_groups = normal_module_groups + basic_module_groups

        advance_module_groups = batch_id.enrollment_student_group_ids.filtered(lambda x: x.module_id.module_level == 'advance')
        practical_module_groups = batch_id.enrollment_student_group_ids.filtered(lambda x: x.module_id.module_level == 'practical')

        while(start_date <= end_date):
            timesheet_record_check = timetable_obj.search([
                ('batch_id', '=', batch_id.id), ('date', '=', start_date)])
            if not timesheet_record_check:
                batch_group_index = 0
                time_index = 0
                holiday_id = hr_holiday_obj.search([('date', '=', start_date)])
                academy_day_off_id = academy_dayoff_obj.search([('day_off_date', '=', start_date), ('academy_id', '=', academy_id.id)])
                if not holiday_id and not academy_day_off_id and start_date.strftime("%A").lower() != 'sunday':
                    time_table_id = timetable_obj.create({
                        'date': start_date,
                        'week_day': start_date.strftime("%A").lower(),
                        'batch_id': batch_id.id })
                    while len(basic_batch_groups) > batch_group_index:
                        if time_index < len(time_slot):
                            batch_group = basic_batch_groups[batch_group_index]
                            total_no_of_lessons = batch_group.module_id.no_of_lessons

                            # available room condition
                            check_room_available = timetable_line_obj.search([
                                ('room_id', '=', batch_group.room_id.id),
                                ('time_index', '=', time_slot[time_index].get('time_index')),
                                ('date', '=', start_date)])
                            if check_room_available:
                                time_index += 1
                                continue

                            # teacher available condition
                            assign_teacher_ids = []
                            for teacher in  batch_group.teacher_ids:
                                teacher_working_hours = teacher.no_of_hours
                                check_teacher_available = timetable_line_obj.search([
                                    ('teacher_ids', 'in', [teacher.id]),
                                    ('date', '=', start_date)])
                                if len(check_teacher_available) < int(teacher_working_hours):
                                    assign_teacher_ids.append(teacher.id)
                            if assign_teacher_ids:
                                assign_teacher_ids = [ (4, teacher_id) for teacher_id in assign_teacher_ids ]
                            else:
                                batch_group_index += 1
                                continue

                            # module limit condition
                            check_created_modules = timetable_line_obj.search([
                                ('module_id', '=', batch_group.module_id.id),
                                ('batch_group_id', '=', batch_group.id)])

                            if time_slot[time_index].get('block') == True:
                                timetable_line_obj.create({
                                    'timetable_id': time_table_id.id,
                                    'date': start_date,
                                    'descripton': 'Break Time',
                                    'batch_time': time_slot[time_index].get('time'),
                                    'time_index': time_slot[time_index].get('time_index'),
                                    'batch_id': batch_id.id,
                                    'teacher_ids': batch_group.teacher_ids })
                                time_index += 1
                            elif len(check_created_modules) < batch_group.module_id.no_of_lessons:
                                timetable_line_obj.create({
                                    'timetable_id': time_table_id.id,
                                    'date': start_date,
                                    'descripton': '',
                                    'batch_time': time_slot[time_index].get('time'),
                                    'time_index': time_slot[time_index].get('time_index'),
                                    'batch_group_id': batch_group.id,
                                    'batch_id': batch_id.id,
                                    'module_id': batch_group.module_id.id,
                                    'room_id': batch_group.room_id.id,
                                    'teacher_ids': batch_group.teacher_ids })
                                batch_group_index += 1
                                time_index += 1
                            else:
                                batch_group_index += 1
                        else:
                            batch_group_index += 1

                    # for advance modules
                    if advance_module_groups:
                        batch_group_index = 0
                    while len(advance_module_groups) > batch_group_index:
                        if time_index < len(time_slot):
                            batch_group = advance_module_groups[batch_group_index]
                            total_no_of_lessons = batch_group.module_id.no_of_lessons

                            # check related basic module index in same date
                            if time_slot[time_index].get('time_index') > 1:
                                check_related_module = timetable_line_obj.search([
                                    ('module_id', '=', batch_group.module_id.related_module.id),
                                    ('date', '=', start_date),
                                    ('time_index', '=', time_slot[time_index].get('time_index') - 1)])
                                if check_related_module:
                                    time_index += 1
                                    continue

                            # available room condition
                            check_room_available = timetable_line_obj.search([
                                ('room_id', '=', batch_group.room_id.id),
                                ('time_index', '=', time_slot[time_index].get('time_index')),
                                ('date', '=', start_date)])
                            if check_room_available:
                                time_index += 1
                                continue

                            # teacher available condition
                            assign_teacher_ids = []
                            for teacher in  batch_group.teacher_ids:
                                teacher_working_hours = teacher.no_of_hours
                                check_teacher_available = timetable_line_obj.search([
                                    ('teacher_ids', 'in', [teacher.id]),
                                    ('date', '=', start_date)])
                                if len(check_teacher_available) < int(teacher_working_hours):
                                    assign_teacher_ids.append(teacher.id)
                            if assign_teacher_ids:
                                assign_teacher_ids = [ (4, teacher_id) for teacher_id in assign_teacher_ids ]
                            else:
                                batch_group_index += 1
                                continue

                            # module limit condition
                            check_created_modules = timetable_line_obj.search([
                                ('module_id', '=', batch_group.module_id.id),
                                ('batch_group_id', '=', batch_group.id)])

                            # check basic module is completed
                            if batch_group.module_id.related_module:
                                total_no_of_lessons_of_basic = batch_group.module_id.related_module.no_of_lessons
                                check_basic_created_modules = timetable_line_obj.search([
                                    ('module_id', '=', batch_group.module_id.related_module.id),
                                    ('batch_id', '=', batch_id.id)])
                                basic_module_timetable_created = True if len(check_basic_created_modules) == total_no_of_lessons_of_basic else False
                            else:
                                basic_module_timetable_created = False

                            if time_slot[time_index].get('block') == True:
                                timetable_line_obj.create({
                                    'timetable_id': time_table_id.id,
                                    'date': start_date,
                                    'descripton': 'Break Time',
                                    'batch_time': time_slot[time_index].get('time'),
                                    'time_index': time_slot[time_index].get('time_index'),
                                    'batch_id': batch_id.id, })
                                time_index += 1
                            elif len(check_created_modules) < batch_group.module_id.no_of_lessons and basic_module_timetable_created:
                                timetable_line_obj.create({
                                    'timetable_id': time_table_id.id,
                                    'date': start_date,
                                    'descripton': '',
                                    'batch_time': time_slot[time_index].get('time'),
                                    'time_index': time_slot[time_index].get('time_index'),
                                    'batch_group_id': batch_group.id,
                                    'batch_id': batch_id.id,
                                    'module_id': batch_group.module_id.id,
                                    'room_id': batch_group.room_id.id,
                                    'teacher_ids': assign_teacher_ids })
                                batch_group_index += 1
                                time_index += 1
                            else:
                                batch_group_index += 1
                        else:
                            batch_group_index += 1

                    # for practical modules
                    if practical_module_groups:
                        batch_group_index = 0
                    while len(practical_module_groups) > batch_group_index:
                        if time_index < len(time_slot):
                            batch_group = practical_module_groups[batch_group_index]
                            total_no_of_lessons = batch_group.module_id.no_of_lessons

                            # check related theory module index in same date
                            if time_slot[time_index].get('time_index') > 1:
                                check_related_module = timetable_line_obj.search([
                                    ('module_id', '=', batch_group.module_id.related_module.id),
                                    ('date', '=', start_date),
                                    ('time_index', '=', time_slot[time_index].get('time_index') - 1)])
                                if check_related_module:
                                    time_index += 1
                                    continue

                            # available room condition
                            check_room_available = timetable_line_obj.search([
                                ('room_id', '=', batch_group.room_id.id),
                                ('time_index', '=', time_slot[time_index].get('time_index')),
                                ('date', '=', start_date)])
                            if check_room_available:
                                time_index += 1
                                continue

                            # teacher available condition
                            assign_teacher_ids = []
                            for teacher in  batch_group.teacher_ids:
                                teacher_working_hours = teacher.no_of_hours
                                check_teacher_available = timetable_line_obj.search([
                                    ('teacher_ids', 'in', [teacher.id]),
                                    ('date', '=', start_date)])
                                if len(check_teacher_available) < int(teacher_working_hours):
                                    assign_teacher_ids.append(teacher.id)
                            if assign_teacher_ids:
                                assign_teacher_ids = [ (4, teacher_id) for teacher_id in assign_teacher_ids ]
                            else:
                                batch_group_index += 1
                                continue

                            # module limit condition
                            check_created_modules = timetable_line_obj.search([
                                ('module_id', '=', batch_group.module_id.id),
                                ('batch_group_id', '=', batch_group.id)])

                            if time_slot[time_index].get('block') == True:
                                timetable_line_obj.create({
                                    'timetable_id': time_table_id.id,
                                    'date': start_date,
                                    'descripton': 'Break Time',
                                    'batch_time': time_slot[time_index].get('time'),
                                    'time_index': time_slot[time_index].get('time_index'),
                                    'batch_id': batch_id.id,})
                                time_index += 1
                            elif len(check_created_modules) < batch_group.module_id.no_of_lessons:
                                timetable_line_obj.create({
                                    'timetable_id': time_table_id.id,
                                    'date': start_date,
                                    'descripton': '',
                                    'batch_time': time_slot[time_index].get('time'),
                                    'time_index': time_slot[time_index].get('time_index'),
                                    'batch_group_id': batch_group.id,
                                    'batch_id': batch_id.id,
                                    'module_id': batch_group.module_id.id,
                                    'room_id': batch_group.room_id.id,
                                    'teacher_ids': assign_teacher_ids })
                                batch_group_index += 1
                                time_index += 1
                            else:
                                batch_group_index += 1
                        else:
                            batch_group_index += 1
            start_date = start_date + datetime.timedelta(days=1)

        action_context = {'timesheet_batch_id': batch_id.id,
                        'timesheet_start_date': start_date,
                        'timesheet_end_date': end_date}
        return {
            'name': 'Batch Timesheet',
            'type': 'ir.actions.client',
            'tag': 'timesheet.gantt_view',
            'context': action_context,
        }

    def get_time(self, time_update_from, time_update_to):
        if time_update_from < 12.0:
            time = str("%.2f" %(time_update_from)) + " To " + str("%.2f" %(time_update_to))
        elif time_update_from == 12.0:
            time = str("%.2f" %(time_update_from)) + " To " + str("%.2f" %(time_update_to - 12))
        else:
            time_from = time_update_from if int(time_update_from) - 12 == 0 else time_update_from - 12
            time = str("%.2f" %(time_from)) + " To " + str("%.2f" %(time_update_to - 12))
        return time

    def get_timetable_timeslot(self):
        timeslot = []
        academy_id = self.academy_id if self else False
        if academy_id:
            batch_start_time = academy_id.batch_start_time
            batch_end_time = academy_id.batch_end_time + 12.00
            break_timeslots = []
            for break_timeslot in academy_id.timeslots:
                start_time = break_timeslot.start_time if break_timeslot.start_time_ampm == 'am' else break_timeslot.start_time + 12.00
                end_time = break_timeslot.end_time if break_timeslot.start_time_ampm == 'am' else break_timeslot.end_time + 12.00
                break_timeslots.append([break_timeslot.id, start_time, break_timeslot.start_time_ampm, end_time])

            batch_duration = 1.00
            time_update_from = batch_start_time
            time_update_to = 0.0
            time_index = 0
            added_time_slot_in_mid = False
            break_timeslot_added = False

            while time_update_to < batch_end_time:
                time_index += 1
                if break_timeslots and break_timeslot_added == False and break_timeslots[0][1] == time_update_from:
                    time_update_to = break_timeslots[0][3]
                    break_timeslot_added = True
                    time = self.get_time(time_update_from, time_update_to)
                    timeslot.append({
                        'time': time,
                        'block': True,
                        'time_index': time_index,
                        'academy_timeslot_id': break_timeslots[0][0] })
                    time_update_from = time_update_to
                elif break_timeslots and break_timeslot_added == False and break_timeslots[0][1] < time_update_from + batch_duration and added_time_slot_in_mid == False:
                    time_update_to = break_timeslots[0][1]
                    break_timeslot_added = True
                    added_time_slot_in_mid = True
                    time = self.get_time(time_update_from, time_update_to)
                    timeslot.append({
                        'time': time,
                        'block': False,
                        'time_index': time_index,
                        'academy_timeslot_id': False })
                    time_update_from = break_timeslots[0][1]
                elif  break_timeslot_added == True and added_time_slot_in_mid == True:
                    time_update_to = break_timeslots[0][3]
                    added_time_slot_in_mid = False
                    break_timeslot_added = False
                    time = self.get_time(time_update_from, time_update_to)
                    timeslot.append({
                        'time': time,
                        'block': True,
                        'time_index': time_index,
                        'academy_timeslot_id': break_timeslots[0][0] })
                    time_update_from = time_update_to
                    break_timeslots.pop(0)
                else:
                    if break_timeslot_added == True:
                        break_timeslots.pop(0)
                    break_timeslot_added = False
                    time_update_to = time_update_from + batch_duration
                    if time_update_to > batch_end_time:
                        time_update_to = batch_end_time
                    # check timeslot is less then batch_duration
                    if round(time_update_to - time_update_from, 2) != batch_duration:
                        continue
                    time = self.get_time(time_update_from, time_update_to)
                    timeslot.append({
                        'time': time,
                        'block': False,
                        'time_index': time_index,
                        'academy_timeslot_id': False })
                    time_update_from = time_update_to
        return timeslot

    def get_table_data(self, active_batch_id, selected_date_range, date_slot, timeslot):
        ils_timetable_obj =  self.env['ils.timetable']
        ils_timetable_line_obj =  self.env['ils.timetable.line']
        table_records = ils_timetable_obj.search([('batch_id', '=', active_batch_id), ('date', 'in', selected_date_range)])
        time_slot_data = {}

        for time in timeslot:
            for date in date_slot:
                batch_date = date.get('start_date')
                if time.get('block') == False:
                    time_slot_line = ils_timetable_line_obj.search([
                        ('date', '=', batch_date),
                        ('time_index','=', time.get('time_index')),
                        ('batch_id', '=', active_batch_id)])
                    if time_slot_data.get(time.get('time')):
                        time_slot_data.get(time.get('time')).append(time_slot_line)
                    else:
                        time_slot_data.update({
                            time.get('time'): [time_slot_line]
                            })
        return time_slot_data