# -*- coding: utf-8 -*-

# Part of Appjetty. See LICENSE file for full copyright and licensing details.

import json
import uuid
import datetime
import passlib.context

from odoo import http
from odoo.tools import  DEFAULT_SERVER_DATETIME_FORMAT
from odoo.http import request
from odoo import api, fields, models,SUPERUSER_ID
from json import dumps
from collections import OrderedDict
from odoo.tools.safe_eval import safe_eval


DEFAULT_CRYPT_CONTEXT = passlib.context.CryptContext(
    # kdf which can be verified by the context. The default encryption kdf is
    # the first of the list
    ['pbkdf2_sha512', 'plaintext'],
    # deprecated algorithms are still verified as usual, but ``needs_update``
    # will indicate that the stored hash should be replaced by a more recent
    # algorithm. Passlib 1.6 supports an `auto` value which deprecates any
    # algorithm but the default, but Ubuntu LTS only provides 1.5 so far.
    deprecated=['plaintext'],
)

MAP_FIELD_WITH_KEY = {'product':{'internal_reference':'default_code',
                                'sale_price':'list_price',
                                'product_category':'categ_id',
                                'attribute':'attribute_line_ids'},
                      'category':{'parent':'parent_id'},
                      'customer':{'name':'name','email':'email'},
                      'modules': {'name': 'name', 'code': 'course_code', 'duration': 'lesson_duration', 'hours': 'no_of_hours'}}

MAP_KEY_FOR_UPDATE = {'product':'default_code','category':'id','customer':'email','modules': 'course_code'}

MAP_KEY_WITH_MODEL = {'product':'product.template',
                    'category':'product.category',
                    'customer':'res.partner',
                    'product_attribute':'product.product',
                    'order':'sale.order',
                    'academy': 'ils.academy',
                    'batch': 'ils.batch',
                    'enrollment': 'ils.enrollment',
                    'student': 'res.partner',
                    'sponsor': 'res.partner',
                    'resion': 'academy.resion',
                    'city': 'academy.city',
                    'program': 'product.template',
                    'semester': 'ils.semester',
                    'qualification': 'ils.qualification',
                    'modules': 'ils.modules',
                    'room': 'ils.room',
                    'employer': 'ils.employer',
                    'employment': 'ils.employment',
                    }

#list for read data
GET_DATA_VAL = {'category':['id','name','parent_id'],
                'customer':['id','name','parent_id','type','street','street2','zip','city','state_id','country_id','email','phone','mobile'],
                'product':['id','name','default_code', 'lst_price', 'description_sale' ,'weight']}

#dynamic domain for delete
GET_DOMAIN_FOR_UNLINK = {'customer':'email',
                        'category':'id',
                        'product_attribute':'barcode',
                        'product':'barcode',
                        'modules': 'course_code'}

def get_domain(model):
    return GET_DOMAIN_FOR_UNLINK.get(model,False)



def get_field_data(model,data):
    model_fields = MAP_FIELD_WITH_KEY.get(model,False)
    final_list = []
    new_dict = {}
    for key,val in data.items():
        # if any(key in model_fields for key in data.items()):
        if model_fields.get(key,False):
            if key == 'attribute':
                for attribute_data in data.get(key,False):
                    attribute_id = request.env['product.attribute'].search([('name','like',str(attribute_data.get('name')))])
                    if not attribute_id.id:
                        return data.update({'attribute_available':False})
                    values_list = []
                    if attribute_data.get('values'):
                        for value in attribute_data.get('values'):
                            attribute_value_ids = request.env['product.attribute.value'].search([('name','like',value)])
                            values_list.append(attribute_value_ids.id)
                    final_list.append((0,0,{"attribute_id":attribute_id.id,"value_ids":[(6,0,values_list)]}))
                data[key] = final_list
            new_dict[model_fields.get(key,False)] = data.get(key,False)
        else:
            new_dict[key] = data.get(key,False)
    data.clear()
    data = new_dict.copy()
    return data

class SyncAPICalls(http.Controller):

    def get_exsiting_id(self,model,data):
        model_obj = self.get_model(model)
        field = MAP_KEY_FOR_UPDATE.get(model,False)
        val =  data.get(MAP_KEY_FOR_UPDATE.get(model,False))
        if not field and not val:
            exsiting_record = model_obj.sudo().search([('code','=',data.get('code'))])
        else:
            exsiting_record = model_obj.sudo().search([(field,'=',val)])
        return exsiting_record

    def __init__(self):
        self.expires_in = {}
        self.refresh_expires_in = 0

    #Check Token Expiration
    def token_timeout(self, token):
        expiry_time = token.date - token.create_date
        store_time = datetime.datetime.strptime(token.date.strftime(DEFAULT_SERVER_DATETIME_FORMAT), DEFAULT_SERVER_DATETIME_FORMAT)
        current_time = datetime.datetime.now()
        differenc = current_time - store_time
        diff_output = divmod(differenc.total_seconds(), expiry_time.total_seconds())
        if diff_output[0] >= expiry_time.total_seconds():
            return True
        else:
            return False

    #create new token
    def create_access_token_data(self, data, user_id, token_expiry, update=False):
        token_obje = request.env['store.token']
        token = token_obje.sudo().search([('user_id', '=', user_id),('date','>=',datetime.datetime.today())])
        if token:
            if token_expiry == None:
                token_expiry = 2
            result = {
                'access_token': token.acc_token,
                'expire_date': token.date + datetime.timedelta(hours=int(token_expiry))
            }
            return result
        else:
            if token_expiry == None:
                token_expiry = 2

            result = {"access_token": self.generate(data, user_id),
                      'expire_date': datetime.datetime.now() + datetime.timedelta(hours=int(token_expiry))}
                    
            vals = {
                'acc_token': result.get('access_token'),
                'date': result.get('expire_date'),
                'user_id': user_id,
                'token_expire_time': token_expiry
            }
            token_obje.sudo().create(vals)
        return result


    def generate(self, data=None, user_id=None):
        """
        :return: A new token
        :rtype: str
        """
        return str(uuid.uuid4())

    def _crypt_context(self):
        """ Passlib CryptContext instance used to encrypt and verify
        passwords. Can be overridden if technical, legal or political matters
        require different kdfs than the provided default.

        Requires a CryptContext as deprecation and upgrade notices are used
        internally
        """
        return DEFAULT_CRYPT_CONTEXT

    #Get New token
    @http.route(['/api/get_token'], csrf=False, type="http", methods=['GET'], auth="public", website=True)
    def generate_custom_token(self, *args, **kwargs):
        url = request.httprequest.url
        name = False
        pwd = False

        if request.params.get('user') and request.params.get('pass'):
            name = request.params.get('user')
            pwd = request.params.get('pass')
            db = request.params.get('db')
            token_expiry = request.params.get('token_expiry')

        res_obj = request.env['res.users']
        assert pwd
        request.env.cr.execute(
            "SELECT COALESCE(password, '') FROM res_users WHERE id=%s",
            [request.env.user.id]
        )
        [hashed] = request.env.cr.fetchone()
        valid, replacement = self._crypt_context()\
            .verify_and_update(pwd, hashed)
        try:
            uid = request.session.authenticate(db, name, pwd)
            if uid:
                user = res_obj.sudo().search([('login', '=', name)])
                data = {
                    'name': user.login,
                    'password': user.password,
                }
                result = self.create_access_token_data(data, user.id, token_expiry)
                data = {"access_token": result.get('access_token'),
                        'expire_date': str(result.get('expire_date'))}
                return json.dumps(data)
            else:
                return json.dumps({'error': 'Something went wrong during your token generation. May be your provided user name or password is incorrect!'})
        except Exception as e:
                return json.dumps({'error': str(e)})

    #Create Data in instence
    @http.route([
        '/api/create/<string:model>',
        ], type="http", csrf=False, auth="public", website=True)

    def get_api_create_call(self, model, record=False, methods=['POST'], **kwargs):
        rec_id = ''
        if request.params.get('token'):
            token_obj = request.env['store.token']
            token = token_obj.sudo().search([('acc_token', '=', request.params.get('token'))])
            if token and not self.token_timeout(token):
                url = request.httprequest.path.split('/')
                model_obj = self.get_model(model)
                final_resopnse = [{"response": []}]
                response = final_resopnse[0].get('response')
                try:
                    if request.params.get('vals'):
                        data_dict = safe_eval(request.params.get('vals',False))
                        for data in data_dict:
                            # data = get_field_data(model,data)
                            data = json.loads(request.params.get('vals'))
                            rec_id = self.get_exsiting_id(model,data)
                            if rec_id:
                                write_record_id = rec_id.sudo().write(data)
                                response.append({"message": "Record Update successfully!", "code": 200})
                            else:
                                create_record_id = model_obj.sudo().create(data)
                                if data.get('attribute_available') == False:
                                    response.append({"message": "Record Create successfully! and Attribute is not available so it will not set", "code": 200})
                                else:
                                    response.append({"message": "Record Create successfully!", "code": 200})
                    else:
                        response.append({"message": "Please check structure of provided data!"})
                except Exception as e:
                    response.append({"message": str(e), "code": 400})
                return json.dumps(final_resopnse)
            else:
                return json.dumps({'error': 'May be your provided token is expired so please recreate it and try again with new token!'})
        else:
                return json.dumps({'error': 'Please Provide a token!'})

    #For Delete Data 
    @http.route([
        '/api/delete/<string:model>/<string:record>',
        ], type="http", csrf=False, auth="public", website=True)
    def get_api_delete_call(self, model, record=False, methods=['POST'], **kwargs):
        if request.params.get('token'):
            token_obj = request.env['store.token']
            token = token_obj.sudo().search([('acc_token', '=', request.params.get('token'))])
            if token and not self.token_timeout(token):
                final_resopnse = [{"response": []}]
                response = final_resopnse[0].get('response')
                try:
                    url = request.httprequest.path.split('/')
                    data_ids = url[-1].split(',')
                    model_obj = self.get_model(model)
                    domain = get_domain(model)
                    if not domain:
                        for data in data_ids:
                            search_ids = model_obj.sudo().search([('id', '=', data)])
                            try:
                                if search_ids:
                                    delete_obj = search_ids.unlink()
                                    response.append({"message": "Record Successfully Deleted", "code": 200})
                                else:
                                    response.append({"message": "Record Not Found",  "code": 200})
                            except Exception:
                                response.append({"message": "You can not delete this record", "code": 400,})
                    else:
                        for data in data_ids:
                            search_ids = model_obj.sudo().search([(domain, '=', data)])
                            try:
                                if search_ids:
                                    delete_obj = search_ids.unlink()
                                    response.append({"message": "Record Successfully Deleted", "code": 200})
                                else:
                                    response.append({"message": "Record Not Found",  "code": 200})
                            except Exception:
                                response.append({"message": "You can not delete this record", "code": 400,})                      
                except Exception as e:
                    response.append({"message": str(e), "code": 400,})
                return json.dumps(final_resopnse)
            else:
                return json.dumps({'error': 'May be your provided token is expired so please recreate it and try again with new token!'})
        else:
                return json.dumps({'error': 'Please Provide a token!'})

    @http.route([
        '/api/read/<string:model>/<string:record>',
        ], type="http", csrf=False, auth="public", website=True)
    def get_api_read_call(self, model, record=False, fields=None, methods=['GET'], **kwargs):
        if request.params.get('token'):
            token_obj = request.env['store.token']
            token = token_obj.sudo().search([('acc_token', '=', request.params.get('token'))])
            if token and not self.token_timeout(token):
                try:
                    url = request.httprequest.path.split('/')
                    model_obj = self.get_model(model)
                    browse_obj = model_obj.sudo().browse(int(record))
                    if request.params.get('fields'):
                        data = browse_obj.sudo().read(request.params.get('fields').split(','))[0]
                    else:
                        data = browse_obj.sudo().read(['id','name'])[0]
                    if data:
                        return json.dumps(data)
                    else:
                        return json.dumps({'error': 'No records found!'})
                except Exception as e:
                    return json.dumps({'error': str(e)})
            else:
                return json.dumps({'error': 'May be your provided token is expired so please recreate it and try again with new token!'})
        else:
                return json.dumps({'error': 'Please Provide a token!'})

    @http.route([
        '/api/search/<string:model>',
        ], type="http", csrf=False, auth="public", website=True)
    def get_api_search_call(self, model, record=False, fields=None, methods=['GET'], **kwargs):
        if request.params.get('token'):
            token_obj = request.env['store.token']
            token = token_obj.sudo().search([('acc_token', '=', request.params.get('token'))])
            if token and not self.token_timeout(token):
                try:
                    url = request.httprequest.path.split('/')
                    model_obj = self.get_model(model)
                    search_data = model_obj.sudo().search([])
                    final_list = []
                    if search_data and not request.params.get('fields'):
                        for data in search_data:
                            final_list.append(OrderedDict([('id', data.id),
                                                       ('name', data.name),
                                                       ]))
                        return json.dumps(final_list)
                    if search_data and request.params.get('fields'):
                        for data in search_data:
                            final_list.append(data.read(request.params.get('fields').split(','))[0])
                        return json.dumps(final_list)
                    else:
                        return json.dumps({'error': 'No records found!'})
                except Exception as e:
                    return json.dumps({'error': str(e)})
            else:
                return json.dumps({'error': 'May be your provided token is expired so please recreate it and try again with new token!'})
        else:
                return json.dumps({'error': 'Please Provide a token!'})

    @http.route([
        '/api/get/<string:model>',
        ], type="http", csrf=False, auth="public", methods=['GET'], website=True)
    def get_api_model_call(self, model, pro_type=None, **kwargs):
        if kwargs.get('token'):
            token_obj = request.env['store.token']
            token = token_obj.sudo().search([('acc_token', '=', kwargs.get('token'))])
            get_data_dict = {}
            if token and not self.token_timeout(token):
                try:
                    domain = []
                    if kwargs.get('write_date'):
                        domain += [('write_date', '>=', str(kwargs.get('write_date')))]
                    else:
                        domain = domain
                    if self.get_record_data(model,domain):
                        return self.get_record_data(model,domain)
                    else:
                        return json.dumps({'error': 'No records found!'})
                except Exception as e:
                    return json.dumps({'error': str(e)})
            else:
                return json.dumps({'error': 'May be your provided token is expired so please recreate it and try again with new token!'})
        else:
                return json.dumps({'error': 'Please Provide a token!'})

    def get_product_json_data(self, json_dict,rec):
        template = rec
        attribute = []
        final_list = []
        for attribute_line in template.attribute_line_ids:
            attribute.append(attribute_line.attribute_id.id)
        json_dict.update({'attribute_ids' : attribute, 'status': template.active})
        if template.company_id:
            json_dict.update({'company_id':template.company_id.id})
        else:
            json_dict.update({'company_id':False})
            if not template.attribute_line_ids and len(template.product_variant_ids) == 1:
                if template.type == 'product':
                    qty = self.get_location_inventory(template.product_variant_ids.id)
                else:
                    qty = False
                json_dict.update({'product_variant_ids': template.product_variant_ids.id,'variations':False, 'qty':qty})
            else:
                json_dict.update({'product_variant_ids': False})
                varient_dict = {}
                index = 0
                for varient in template.product_variant_ids:
                    detail = varient.sudo().read(['id','name','default_code', 'lst_price', 'description_sale' ,'weight', 'categ_id'])
                    if detail:
                        varient_dict[index] = detail[0]
                        if varient.product_tmpl_id.type == 'product':
                            qty = self.get_location_inventory(varient.id)
                        else:
                            qty = False
                        varient_dict[index].update({'status': varient.active,'qty' : qty})
                        if varient.categ_id:
                            varient_dict[index].update({'categ_id': varient.categ_id.id})
                        else:
                            varient_dict[index].update({'categ_id': False})
                        index += 1
                json_dict['variations'] = varient_dict
            final_list.append(json_dict)
        return final_list


    def get_record_data(self, model, domain):
        current_obj = self.get_model(model)
        obj_data_ids = current_obj.sudo().search(domain)
        final_list = []
        read_list = GET_DATA_VAL.get(model,False)
        for rec in obj_data_ids:
            data = rec.sudo().read(read_list)
            if data:
                json_dict = data[0]
            if model == "product":
                final_list.append(self.get_product_json_data(json_dict,rec))
            else:
                final_list.append(json_dict)
            if len(final_list) == 0:
                final_list.append("No Records Found")
        return json.dumps(final_list)

    def get_location_inventory(self, product_id=None):
        stock_data = {}
        if product_id != False:
            stock_query = """ 
                    SELECT 
                    sum(stock_quant.quantity) as qty_on_hand,
                    stock_quant.location_id
                    FROM
                    stock_location 
                    LEFT JOIN 
                    stock_quant 
                    ON (stock_location.id = stock_quant.location_id AND 
                    stock_location.usage = 'internal' AND 
                    stock_location.company_id IS NOT NULL)
                    JOIN res_company ON (res_company.id = stock_location.company_id)
                    WHERE stock_quant.product_id = %s
                    GROUP BY stock_quant.location_id """ % (product_id)
            request.env.cr.execute(stock_query)
            stock_data = request.env.cr.dictfetchall()
        return stock_data


    def get_model(self, model):
        return request.env[MAP_KEY_WITH_MODEL.get(model)]

class StoreToken(models.Model):
    _name = 'store.token'

    acc_token = fields.Char('Access Token')
    date = fields.Datetime('Expiry date')
    user_id = fields.Integer('User Name')
    token_expire_time = fields.Char('Token Expire Time')