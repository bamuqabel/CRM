# -*- coding: utf-8 -*-

# Part of ILS. See LICENSE file for full copyright and licensing details.

{
    'name': 'Odoo Sync Custom API',
    'version': '13.0.0.1.1',
    'category': 'eCommerce',
    'summary': 'Odoo Sync API',
    'description': """
This module for Odoo Custom API for Sync data.
    """,
    'author': 'Innovative Leading Solutions organization',
    'license': 'OPL-1',
    'website': 'https://www.ils.com.sa/',
    'depends': ['website', 'product', 'sale_management', 'stock', 'sale_stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/session_token_view.xml'
    ],
    'demo': [
    ],
    'qweb':[
    ],
    'application':True,
    'installable': True,
    'auto_install': False
}
