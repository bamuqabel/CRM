# -*- coding: utf-8 -*-
# from odoo import http


# class RightechsPoReportPdf(http.Controller):
#     @http.route('/rightechs_po_report_pdf/rightechs_po_report_pdf/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/rightechs_po_report_pdf/rightechs_po_report_pdf/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('rightechs_po_report_pdf.listing', {
#             'root': '/rightechs_po_report_pdf/rightechs_po_report_pdf',
#             'objects': http.request.env['rightechs_po_report_pdf.rightechs_po_report_pdf'].search([]),
#         })

#     @http.route('/rightechs_po_report_pdf/rightechs_po_report_pdf/objects/<model("rightechs_po_report_pdf.rightechs_po_report_pdf"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('rightechs_po_report_pdf.object', {
#             'object': obj
#         })
