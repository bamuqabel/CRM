# -*- coding: utf-8 -*-

from . import api_token_configuaration
from . import api_configuration
from . import res_partner