# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _


class StudentReceivingList(models.TransientModel):
    _name = 'student.receiving.list'
    _description = "Student Result Receiving List"

    school_id = fields.Many2one('school.school', string='School Level', default=lambda self: self.env.user.school_id)
    institute_id = fields.Many2one('res.company', string="Institute", default=lambda self: self.env.user.company_id)
    stage_id = fields.Many2one('stage.stage', string='Stage')
    course_id = fields.Many2one('course.course', string='Course')
    batch_id = fields.Many2one('batch.batch', string='Batch')
    semester_id = fields.Many2one('semester.semester', string='Standard')
    all_division = fields.Boolean(string="All Divisions", default=False)
    division_ids = fields.Many2many('division.division', string='Divisions')
    academic_year_id = fields.Many2one('academic.year', string='Academic Year')

    @api.onchange('school_id')
    def onchange_school_id(self):
        """
            Set Institute base on School.
        """
        institutes = []
        self.institute_id = False
        self.stage_id = False
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_ids = False
        school_ids = False
        if self.school_id:
            school_ids = self.school_id.ids
            self.institute_id = self.school_id.institute_id.id
            institutes = self.institute_id.ids
        return {'domain':{'institute_id': [('id', 'in', institutes)], 'stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_ids = False

    @api.onchange('course_id')
    def onchange_course_id(self):
        self.batch_id = False
        self.semester_id = False
        self.division_ids = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        self.semester_id = False
        self.division_ids = False
        self.academic_year_id = False
        if self.batch_id and self.batch_id.academic_year_id:
            self.academic_year_id = self.batch_id.academic_year_id.id
        return {'domain':{'semester_id': [('id', 'in', self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        self.division_ids = False
        if not self.semester_id or not self.batch_id:
            self.division_ids = False
        divisions = []
        if self.semester_id and self.batch_id:
            divisions = self.semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.batch_id.id).mapped('division_ids').mapped('division_id').ids
        return {'domain':{'division_ids': [('id', 'in', divisions)]}}

    @api.onchange('all_division')
    def onchange_all_division(self):
        self.division_ids = False

    def print_report(self):
        self.ensure_one()
        [data] = self.read()
        lst = []
        divisions = False
        if self.all_division and self.semester_id and self.batch_id:
            divisions = self.semester_id.semester_history_ids.filtered(
                    lambda x: x.batch_id.id == self.batch_id.id
                    ).mapped('division_ids').mapped('division_id')
        else:
            divisions = self.division_ids
        for division in divisions:
            domain = [('school_id', '=', self.school_id.id), ('institute_id', '=', self.institute_id.id),
                        ('stage_id', '=', self.stage_id.id), ('course_id', '=', self.course_id.id),
                        ('batch_id', '=', self.batch_id.id), ('semester_id', '=', self.semester_id.id),
                        ('division_id', '=', division.id)]
            student_ids = self.env['student.student'].search(domain)
            lst.append({
                'school_id': self.school_id.id,
                'academic_year_id': self.academic_year_id.id,
                'division_id': division.id,
                'semester_id': self.semester_id.id,
                'student_ids': student_ids.ids
            })
        data.update({'student_data': lst})
        datas = {
            'ids': [],
            'model': 'student.student',
            'form': data,
        }
        return self.env.ref('sync_exam.action_report_student_result_receiving_list').report_action([], data=datas)
