
Make sure you have ``python-nvd3`` Python module installed::

Information for package from link 'https://python-nvd3o.readthedocs.io/en/stable/introduction.html'

pip3 install python-nvd3
