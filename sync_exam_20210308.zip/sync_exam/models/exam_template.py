# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class ExamTemplate(models.Model):
    _name = 'exam.template'
    _description = "Exam Template"

    name = fields.Char(string='Name', size=32, copy=False, required=True)
    pass_mark = fields.Float(string="Passing Marks", required=True)
    max_mark = fields.Float(string="Total Marks", required=True)
    weekly_exams = fields.Integer(string="Weekly Exam")
    weekly_exams_ids = fields.One2many('weekly.exams.values', 'exam_template_id', string="Weekly Exams Values")

    def create_weeks(self):
        if self.weekly_exams:
            week_vals = []
            for week_number in range(1,self.weekly_exams + 1):
                week = 'Week %s' %(str(week_number))
                vals = {
                    'name': week
                    }
                week_vals.append(vals)
            self.weekly_exams_ids = [(5)]
            self.weekly_exams_ids = [(0, 0, line) for line in week_vals]

    # Add containt for weekly exam - 24/02/2021
    _sql_constraints = [
        ('check_passing_marks', "CHECK((max_mark > pass_mark))", "Total Marks should be greater than passing Marks."),
        ('check_weekly_exams', "CHECK((weekly_exams > 0))", "Number of weekly exams should be greater than 0.")
    ]

class WeeklyExamValues(models.Model):
    _name = 'weekly.exams.values'
    _description = "Weekly Exam Values"

    exam_template_id = fields.Many2one('exam.template', string="Exam Template ID")
    name = fields.Char(string="Week Name")