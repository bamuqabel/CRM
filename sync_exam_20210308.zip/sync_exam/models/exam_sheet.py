# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, Warning


class ExamSheet(models.Model):
    _name = 'exam.sheet'
    _description = "Exam Sheet"

    school_id = fields.Many2one('school.school', string='School Level', default=lambda self: self.env.user.school_id)
    institute_id = fields.Many2one('res.company', string="Institute")
    stage_id = fields.Many2one('stage.stage', string='Stage')
    course_id = fields.Many2one('course.course', string='Course')
    batch_id = fields.Many2one('batch.batch', string='Batch')
    semester_id = fields.Many2one('semester.semester', string='Standard')
    division_id = fields.Many2one('division.division', string='Division')
    student_id = fields.Many2one('student.student', string='Student', required=True, ondelete='cascade')
    academic_year_id = fields.Many2one('academic.year', string='Academic Year')
    academic_term = fields.Selection ([
        ('other', 'Other'),
        # ('first_sessional', 'First Sessional'),
        ('first_term', 'First Term'),
        # ('second_sessional', 'Second Sessional'),
        ('second_term', 'Second Term')], string='Academic Term', default='first_term')
    grand_ids = fields.One2many('grand.performance.appraisal', 'exam_sheet_id', string="Grand Performance Appraisal", copy=False)
    state = fields.Selection ([
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('done', 'Done'),
        ('cancel', 'Cancel')], track_visibility='onchange',
        string='Status', default='draft', copy=False)
    exam_template_id = fields.Many2one('exam.template', string='Exam Template')

    @api.onchange('school_id')
    def onchange_school_id(self):
        """
            Set Institute base on School.
        """
        institutes = []
        self.institute_id = False
        self.stage_id = False
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False
        school_ids = False
        if self.school_id:
            school_ids = self.school_id.ids
            self.institute_id = self.school_id.institute_id.id
            institutes = self.institute_id.ids
        return {'domain':{'institute_id': [('id', 'in', institutes)], 'stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False

    @api.onchange('course_id')
    def onchange_course_id(self):
        self.batch_id = False
        self.semester_id = False
        self.division_id = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        self.semester_id = False
        self.division_id = False
        self.academic_year_id = False
        if self.batch_id and self.batch_id.academic_year_id:
            self.academic_year_id = self.batch_id.academic_year_id.id
        return {'domain':{'semester_id': [('id', 'in', self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        self.division_id = False
        if not self.semester_id or not self.batch_id:
            self.division_id = False
        divisions = []
        if self.semester_id and self.batch_id:
            divisions = self.semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.batch_id.id).mapped('division_ids').mapped('division_id').ids
        return {'domain':{'division_id': [('id', 'in', divisions)]}}

    @api.onchange('division_id')
    def onchange_division_id(self):
        get_students = self.get_students()
        students = []
        if get_students:
            students = get_students.ids
        return {'domain':{'student_id': [('id', 'in', students)]}}

    @api.depends('student_id', 'academic_term')
    def name_get(self):
        result = []
        for record in self:
            name = record.student_id.name
            if record.academic_year_id:
                academic_year =  record.academic_year_id.name_get() and record.academic_year_id.name_get()[0] and record.academic_year_id.name_get()[0][1] or '-'
                name = ''.join([name, ' [', academic_year, '] '])
            result.append((record.id, name))
        return result

    def action_confirm(self):
        for rec in self:
            if rec.academic_term != 'other':
                rec.fetch_results()
        return self.write({'state': 'confirm'})

    def action_done(self):
        for rec in self:
            if not rec.grand_ids:
                raise Warning(_('You cannot move the record in done state!'))
            rec.update_academic_record()
        return self.write({'state': 'done'})

    def action_reset_draft(self):
        return self.write({'state': 'draft'})

    def action_cancel(self):
        return self.write({'state': 'cancel'})

    def update_academic_record(self):
        if self.academic_term != 'other':
            result_list = []
            academic_grand_id = self.grand_ids.filtered(lambda l: l.type == 'academic')
            academic_common_vals = {
                'min_marks': 0.0,
                'max_marks': 0.0,
                'obtained_marks': 0.0,
            }
            subject_dict = {}
            if self.academic_term == 'first_term':
                first_sessional_result_list = self.student_id.result_calculation('first_sessional')
                first_term_result_list = self.student_id.result_calculation('first_term')
                result_list.extend(first_sessional_result_list + first_term_result_list)
            elif self.academic_term == 'second_term':
                # first_sessional_result_list = self.student_id.result_calculation('first_sessional')
                # first_term_result_list = self.student_id.result_calculation('first_term')
                second_sessional_result_list = self.student_id.result_calculation('second_sessional')
                second_term_result_list = self.student_id.result_calculation('second_term')
                result_list.extend(second_sessional_result_list + second_term_result_list)
            for line in result_list:
                academic_common_vals['min_marks'] += line.get('min_marks')
                academic_common_vals['max_marks'] += line.get('max_marks')
                academic_common_vals['obtained_marks'] += line.get('total_obtained_marks')
            academic_grand_id.write(academic_common_vals)

            # for weekly evaluation result update - 24/02/2021
            weekly_subject_grand_id = self.grand_ids.filtered(lambda l: l.type not in  ['academic','attendance_behaviour'])
            weekly_test_domain = self.weekly_test_domain()
            weekly_test_obj = self.env['weekly.test'].search(weekly_test_domain)
            if weekly_test_obj:
                for weekly_sub in weekly_subject_grand_id:
                    weekly_subject_common_vals = {}
                    total_obtained_attitude_marks = 0
                    total_obtained_aptitude_marks = 0
                    total_obtained_linguistics_marks = 0
                    semester_min_marks = 0
                    semester_total_marks = 0
                    if weekly_sub.type in ['aptitude','attitude']:
                        filtered_weekly_test_obj = weekly_test_obj.filtered(lambda l: l.weekly_test_subject_id.weekly_subject_type == 'aptitude_attitude')
                        total_aptitude_week_count = 0
                        total_attitude_week_count = 0
                        for filtered_week_obj in filtered_weekly_test_obj:
                            weekly_evaluation_lines = filtered_week_obj.weekly_test_result_ids.filtered(lambda l: l.student_id.id == self.student_id.id)
                            if weekly_sub.type == 'aptitude' and weekly_evaluation_lines.obtained_aptitude_marks > 0:
                                total_aptitude_week_count += 1
                                total_obtained_aptitude_marks += weekly_evaluation_lines.obtained_aptitude_marks
                            elif weekly_sub.type == 'attitude' and weekly_evaluation_lines.obtained_attitude_marks > 0:
                                total_attitude_week_count += 1
                                total_obtained_attitude_marks += weekly_evaluation_lines.obtained_attitude_marks
                            semester_total_marks = filtered_week_obj.weekly_test_subject_id.semester_total_marks
                            semester_min_marks = filtered_week_obj.weekly_test_subject_id.semester_min_marks
                        weekly_subject_common_vals.update({
                            'min_marks':semester_min_marks,
                            'max_marks':semester_total_marks,
                        })
                        if weekly_sub.type == 'aptitude':
                            if total_aptitude_week_count > 0:
                                final_obtained_aptitude_marks = (total_obtained_aptitude_marks / total_aptitude_week_count) * 5
                                weekly_subject_common_vals.update({
                                    'obtained_marks':final_obtained_aptitude_marks
                                })
                            else:
                                weekly_subject_common_vals.update({
                                    'obtained_marks':0.0
                                })
                            weekly_sub.write(weekly_subject_common_vals)

                        elif weekly_sub.type == 'attitude':
                            if total_attitude_week_count > 0:
                                final_obtained_attitude_marks = (total_obtained_attitude_marks / total_attitude_week_count) * 5
                                weekly_subject_common_vals.update({
                                    'obtained_marks':final_obtained_attitude_marks
                                })
                            else:
                                weekly_subject_common_vals.update({
                                    'obtained_marks':0.0
                                })
                            weekly_sub.write(weekly_subject_common_vals)
                    else:
                        filtered_weekly_test_obj = weekly_test_obj.filtered(lambda l: l.weekly_test_subject_id.weekly_subject_type == weekly_sub.type)
                        single_week_test = filtered_weekly_test_obj.weekly_test_result_ids.filtered(lambda l:l.student_id.id == self.student_id.id)
                        if single_week_test:
                            total_obtained_linguistics_marks = single_week_test.obtained_linguistics_marks
                        weekly_subject_common_vals.update({
                            'min_marks':filtered_weekly_test_obj.weekly_test_subject_id.semester_min_marks,
                            'max_marks':filtered_weekly_test_obj.weekly_test_subject_id.semester_total_marks,
                            'obtained_marks':total_obtained_linguistics_marks
                        })
                        weekly_sub.write(weekly_subject_common_vals)

        return True

    def create_grand_appraisal(self):
        for sheet in self:
            if sheet.academic_term != 'other':
                sheet.fetch_results()
            grand_type = self.env['grand.performance.appraisal']._fields['type']._description_selection(self.env)
            grand_list = []
            common_vals = {
                'min_marks': 0.0,
                'max_marks': 0.0,
                'obtained_marks': 0.0,
            }
            for line in grand_type:
                vals = common_vals.copy()
                vals.update({'type': line[0]})
                if line and line[0] in ['attendance_behaviour'] and sheet.exam_template_id:
                    vals.update({
                        'min_marks': sheet.exam_template_id.pass_mark,
                        'max_marks': sheet.exam_template_id.max_mark
                    })
                grand_list.append(vals)
            sheet.grand_ids = [(0, 0, line) for line in grand_list]
        return True

    def get_students(self):
        students = False
        for sheet in self:
            domain = [
                ('school_id', '=', sheet.school_id.id),
                ('institute_id', '=', sheet.institute_id.id),
                ('stage_id', '=', sheet.stage_id.id),
                ('course_id', '=', sheet.course_id.id),
                ('batch_id', '=', sheet.batch_id.id),
                ('semester_id', '=', sheet.semester_id.id),
                ('division_id', '=', sheet.division_id.id),
            ]
            students = self.env['student.student'].search(domain)
        return students

    def result_domain(self):
        domain = [
            ('student_id', '=', self.student_id.id),
            ('exam_id.school_id', '=', self.school_id.id),
            ('exam_id.institute_id', '=', self.institute_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('course_id', '=', self.course_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('division_id', '=', self.division_id.id),
            ('exam_id.academic_year_id', '=', self.academic_year_id.id),
        ]
        return domain

    def weekly_test_domain(self):
        domain = [
            ('school_id', '=', self.school_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('course_id', '=', self.course_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('academic_term', '=', self.academic_term),
            ('academic_year_id', '=', self.academic_year_id.id),
            ('exam_template_id', '=', self.exam_template_id.id)
        ]
        return domain

    def fetch_results(self):
        """ Result Calculation """
        FinalData = {}
        domain = self.result_domain()
        subjects =  self.student_id.optional_subject_ids + self.student_id.compulsary_subject_ids
        domain += [('subject_id', 'in', subjects.ids)]
        if self.academic_term == 'first_term':
            domain += [('exam_id.academic_term', 'in', ['first_term', 'first_sessional'])]
        elif self.academic_term == 'second_term':
            domain += [('exam_id.academic_term', 'in', ['second_term', 'second_sessional'])]

        result_ids = self.env['result.result'].search(domain, order='create_date desc')
        # Term Wise results
        first_term_results = result_ids.filtered(lambda l: l.exam_id.academic_term == 'first_term')
        first_sessional_results = result_ids.filtered(lambda l: l.exam_id.academic_term == 'first_sessional')
        second_term_results = result_ids.filtered(lambda l: l.exam_id.academic_term == 'second_term')
        second_sessional_results = result_ids.filtered(lambda l: l.exam_id.academic_term == 'second_sessional')
        # Term Wise Subjects
        first_term_result_subjects = first_term_results.mapped('subject_id').filtered(lambda l: not l.is_extra_subject).ids
        first_sessional_result_subjects = first_sessional_results.mapped('subject_id').filtered(lambda l: not l.is_extra_subject).ids
        second_term_result_subjects = second_term_results.mapped('subject_id').filtered(lambda l: not l.is_extra_subject).ids
        second_sessional_result_subjects = second_sessional_results.mapped('subject_id').filtered(lambda l: not l.is_extra_subject).ids

        TotalSubjectList = subjects.ids
        TotalSubjectList.sort()
        first_term_result_subjects.sort()
        first_sessional_result_subjects.sort()
        second_term_result_subjects.sort()
        second_sessional_result_subjects.sort()

        # Academic Term Wise Check
        if (self.academic_term == 'first_term' and TotalSubjectList != first_term_result_subjects and \
            TotalSubjectList != first_sessional_result_subjects) or (self.academic_term =='second_term'\
            and TotalSubjectList != second_term_result_subjects and \
            TotalSubjectList != second_sessional_result_subjects):
            raise Warning(_('You cannot move to next stage, because results are not available for selected student!'))

        FinalData.update({
            'subjects': subjects,
            'first_term_results': first_term_results,
            'first_sessional_results': first_sessional_results,
            'second_sessional_results': second_sessional_results,
            'second_term_results': second_term_results
        })
        return FinalData

    def unlink(self):
        ''' remove record'''
        for rec in self:
            if rec.state != 'draft' and rec.grand_ids:
                raise Warning(_('You cannot remove the record in this state!'))
        return super(ExamSheet, self).unlink()


class GrandPerformanceAppraisal(models.Model):
    _name = 'grand.performance.appraisal'
    _description = "Grand Performance Appraisal"

    @api.depends('obtained_marks', 'min_marks', 'max_marks', 'is_fail', 'is_attempt')
    def _compute_fail_student(self):
        for rec in self:
            rec.is_fail = False
            if not rec.is_attempt and rec.obtained_marks < rec.min_marks:
                rec.is_fail = True
                rec.state = 'fail'
            elif not rec.is_fail and not rec.is_attempt and rec.obtained_marks >= rec.min_marks:
                rec.state = 'pass'
            elif rec.is_attempt:
                rec.is_fail = True
                rec.state = 'not_attempt'
                rec.obtained_marks = False
            else:
                rec.state = 'draft'

    exam_sheet_id = fields.Many2one('exam.sheet', required=True, string='Exam Sheet', copy=False , ondelete='cascade')
    school_id = fields.Many2one('school.school', string='School Level', related="exam_sheet_id.school_id")
    institute_id = fields.Many2one('res.company', string="Institute", related="exam_sheet_id.institute_id")
    stage_id = fields.Many2one('stage.stage', string='Stage', related="exam_sheet_id.stage_id")
    course_id = fields.Many2one('course.course', string='Course', related="exam_sheet_id.course_id")
    batch_id = fields.Many2one('batch.batch', string='Batch', related="exam_sheet_id.batch_id")
    semester_id = fields.Many2one('semester.semester', string='Standard', related="exam_sheet_id.semester_id")
    division_id = fields.Many2one('division.division', string='Division', related="exam_sheet_id.division_id")
    student_id = fields.Many2one('student.student', string='Student', related="exam_sheet_id.student_id")
    academic_year_id = fields.Many2one('academic.year', string='Academic Year', related="exam_sheet_id.academic_year_id")
    academic_term = fields.Selection ([
        ('other', 'Other'),
        # ('first_sessional', 'First Sessional'),
        ('first_term', 'First Term'),
        # ('second_sessional', 'Second Sessional'),
        ('second_term', 'Second Term')], string='Academic Term', related="exam_sheet_id.academic_term")
    min_marks = fields.Float('Min Marks', required=True)
    max_marks = fields.Float('Max Marks', required=True)
    obtained_marks = fields.Float('Obtained Marks', copy=False, required=True)
    type = fields.Selection ([
        ('academic', 'Academic'),
        ('aptitude', 'Aptitude'),
        ('attitude', 'Attitude'),
        ('linguistic_skills', 'Linguistic Skills'),
        ('attendance_behaviour', 'Attendance & Behaviour')],
        string='Type', default='academic', required=True)
    state = fields.Selection ([
        ('draft', 'Draft'),
        ('pass', 'Pass'),
        ('fail', 'Fail'),
        ('not_attempt', 'Not Attempt')], track_visibility='onchange',
        string='Status', default='draft', copy=False)
    is_attempt = fields.Boolean("Is Not Attempt", copy=False)
    is_fail = fields.Boolean("Fail", compute=_compute_fail_student, copy=False, store=True)

    def _check_grand(self):
        for grand in self:
            domain = [
                ('id', '!=', grand.id),
                ('school_id', '=', grand.school_id.id),
                ('stage_id', '=', grand.stage_id.id),
                ('course_id', '=', grand.course_id.id),
                ('batch_id', '=', grand.batch_id.id),
                ('semester_id', '=', grand.semester_id.id),
                ('academic_term', '=', grand.academic_term),
                ('academic_year_id', '=', grand.academic_year_id.id),
                ('type', '=', grand.type),
                ('division_id', '=', grand.division_id.id),
                ('student_id', '=', grand.student_id.id),
            ]
            grand_ids = self.search(domain)
            if grand_ids:
                raise ValidationError(_('You cannot create/write same Grand Performance Appraisal records!'))

    def write(self, vals):
        record = super(GrandPerformanceAppraisal, self).write(vals)
        for grand in self:
            # Check same GrandPerformanceAppraisal code
            grand._check_grand()
        return record

    @api.model
    def create(self, vals):
        record = super(GrandPerformanceAppraisal, self).create(vals)
        # Check same GrandPerformanceAppraisal code
        record._check_grand()
        return record

    @api.onchange('min_marks', 'max_marks')
    def onchange_min_marks(self):
        if self.max_marks < self.min_marks:
            raise ValidationError(_('Minimum Marks should be less than Maximum Marks.'))

    @api.onchange('obtained_marks', 'max_marks')
    def onchange_obtained_marks(self):
        if self.max_marks < self.obtained_marks:
            raise ValidationError(_('Marks obtained must be less than or equal to Maximum Marks.'))

    @api.onchange('is_attempt')
    def onchange_is_attempt(self):
        if self.is_attempt:
            self.is_fail = True
            self.obtained_marks = False
