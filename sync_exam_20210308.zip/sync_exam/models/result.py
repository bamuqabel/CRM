# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import modules, models, fields, api, _
from odoo.exceptions import ValidationError


class Result(models.Model):
    _name = 'result.result'
    _description = "Result"

    @api.depends('max_marks', 'obtained_marks', 'total_obtained_marks', 'grace_marks', 'min_marks')
    def _compute_grade_points(self):
        for rec in self:
            rec.grade_point = 0.0
            if rec.total_obtained_marks and rec.max_marks:
                rec.grade_point = (rec.total_obtained_marks * 100)/rec.max_marks

    @api.depends('is_attempt', 'obtained_marks', 'total_obtained_marks', 'grace_marks', 'min_marks', 'is_fail', 'max_marks')
    def _compute_fail_student(self):
        for rec in self:
            rec.is_fail = False
            if rec.obtained_marks >= rec.min_marks:
                rec.grace_marks = 0.0
            if not rec.is_attempt and rec.total_obtained_marks < rec.min_marks:
                rec.is_fail = True
                rec.state = 'fail'
            elif not rec.is_fail and not rec.is_attempt and rec.total_obtained_marks >= rec.min_marks:
                rec.state = 'pass'
            elif rec.is_attempt:
                rec.is_fail = True
                rec.state = 'not_attempt'
                rec.grace_marks = False
                rec.obtained_marks = False
            else:
                rec.state = 'draft'

    @api.depends('is_attempt', 'obtained_marks', 'grace_marks', 'is_fail')
    def _compute_total_obtained_marks(self):
        for rec in self:
            rec.total_obtained_marks = rec.obtained_marks
            if rec.grace_marks:
                rec.total_obtained_marks = rec.obtained_marks + rec.grace_marks

    @api.depends('grade_point')
    def _compute_grade(self):
        for rec in self:
            rec.grade_id = False
            if rec.grade_point:
                domain = [('min_points', '<=', rec.grade_point),
                    ('max_points', '>=', rec.grade_point)]
                grade_id = self.env['grade.grade'].search(domain , limit=1)
                rec.grade_id = grade_id and grade_id.id

    exam_id = fields.Many2one('exam.exam', string="Exam", copy=False, ondelete='cascade')
    student_id = fields.Many2one('student.student', string='Student', copy=False , ondelete='cascade')
    date = fields.Date(string='Date', related="exam_id.result_date", store=True)
    stage_id = fields.Many2one(related="student_id.stage_id", string='Stage', store=True)
    course_id = fields.Many2one(related="student_id.course_id", string='Course', store=True)
    batch_id = fields.Many2one(related="student_id.batch_id", string='Batch', store=True)
    semester_id = fields.Many2one(related="student_id.semester_id", string='Standard', store=True)
    division_id = fields.Many2one(related="student_id.division_id", string='Division', store=True)
    subject_id = fields.Many2one(related="exam_id.subject_id", string='Subject', store=True)
    grade_type = fields.Selection (related="exam_id.grade_type", string='Grade Type', store=True)
    grade_id = fields.Many2one('grade.grade', string="Grade", compute=_compute_grade)
    is_attempt = fields.Boolean("Is Not Attempt", copy=False)
    is_fail = fields.Boolean("Fail", compute=_compute_fail_student, copy=False, store=True)
    min_marks = fields.Float('Min Marks', default=0.0)
    max_marks = fields.Float('Max Marks', default=0.0)
    obtained_marks = fields.Float('Obtained Marks', copy=False)
    grade_point = fields.Float('Points(%)', compute=_compute_grade_points, copy=False, store=True)
    state = fields.Selection ([
        ('draft', 'Draft'),
        ('pass', 'Pass'),
        ('fail', 'Fail'),
        ('not_attempt', 'Not Attempt')], track_visibility='onchange',
        string='Status', default='draft', copy=False)
    exam_type = fields.Selection(related="exam_id.exam_type", store=True,
        string='Exam Type', copy=False)
    grace_marks = fields.Float("Grace Marks")
    total_obtained_marks = fields.Float('Total Obtained Marks', compute=_compute_total_obtained_marks, copy=False, store=True)
    is_re_exam = fields.Boolean(related="exam_id.is_re_exam", string="Re-Exam Result", store=True)
    parent_exam_id = fields.Many2one(related="exam_id.parent_exam_id", string='Parent Exam', store=True)

    @api.depends('student_id')
    def name_get(self):
        result = []
        for record in self:
            name = "[Result]"
            if self.student_id and self.student_id.name:
                name = ' '.join([name, self.student_id.name])
            result.append((record.id, name))
        return result

    @api.onchange('is_attempt')
    def onchange_is_attempt(self):
        if self.is_attempt:
            self.is_fail = True
            self.obtained_marks = False
            self.grace_marks = False

    @api.onchange('grace_marks')
    def onchange_grace_marks(self):
        if self.min_marks < self.grace_marks:
            raise ValidationError(_('Grace Marks should be less than Minimum Marks.'))

    @api.onchange('min_marks')
    def onchange_min_marks(self):
        if self.max_marks < self.min_marks:
            raise ValidationError(_('Minimum Marks should be less than Maximum Marks.'))

    @api.onchange('total_obtained_marks')
    def onchange_total_obtained_marks(self):
        if self.max_marks < self.total_obtained_marks:
            raise ValidationError(_('Total Marks obtained must be less than or equal to Maximum Marks.'))

    @api.onchange('obtained_marks')
    def onchange_obtained_marks(self):
        if self.max_marks < self.obtained_marks:
            raise ValidationError(_('Marks obtained must be less than or equal to Maximum Marks.'))
