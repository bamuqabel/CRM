# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    re_exam_time = fields.Integer("No. of Re-exam", config_parameter='sync_exam.re_exam_time', default=1)
