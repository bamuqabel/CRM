# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _

class ExtraExamResult(models.Model):
    _name = 'extra.exam.result'
    _description = "Extra Subject(s) Exam Result"

    exam_id = fields.Many2one('exam.exam', string="Exam", ondelete='cascade')
    student_id = fields.Many2one('student.student', string='Student', copy=False , ondelete='cascade')
    date = fields.Date(string='Date', related="exam_id.result_date", store=True)
    stage_id = fields.Many2one(related="student_id.stage_id", string='Stage', store=True)
    course_id = fields.Many2one(related="student_id.course_id", string='Course', store=True)
    batch_id = fields.Many2one(related="student_id.batch_id", string='Batch', store=True)
    semester_id = fields.Many2one(related="student_id.semester_id", string='Standard', store=True)
    division_id = fields.Many2one(related="student_id.division_id", string='Division', store=True)
    subject_id = fields.Many2one(related="exam_id.subject_id", string='Subject', store=True)
    # grade_id = fields.Many2one('grade.grade', string="Grade")
    exam_type = fields.Selection(related="exam_id.exam_type", store=True,
        string='Exam Type', copy=False)
    grade_type = fields.Selection ([
        ('bad', 'Bad'),
        ('good', 'Good'),
        ('medium', 'Medium'),
        ('excellent', 'Excellent')], track_visibility='onchange',
        string='Grade')
