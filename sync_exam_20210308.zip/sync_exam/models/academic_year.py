# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class AcademicYear(models.Model):
    _name = 'academic.year'
    _description = "Grade"

    start_year = fields.Char(string='Start Year', copy=False, required=True)
    end_year = fields.Char(string='End Year', copy=False, required=True)

    _sql_constraints = [
        ('year', 'unique(start_year, end_year)', 'The start and end year name must be unique!')
    ]

    @api.depends('start_year', 'end_year')
    def name_get(self):
        result = []
        for record in self:
            name = False
            if record.start_year and record.end_year:
                name = ''.join([record.start_year, '-', record.end_year])
            result.append((record.id, name))
        return result


class BatchBatch(models.Model):
    _inherit = 'batch.batch'

    academic_year_id = fields.Many2one('academic.year', string='Academic Year')
