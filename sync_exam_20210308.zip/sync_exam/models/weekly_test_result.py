# -*- coding: utf-8 -*-

from odoo import modules, models, fields, api, _
from odoo.exceptions import ValidationError

class WeeklyTestResult(models.Model):
    _name = 'weekly.test.result'
    _description = "Weekly Evaluation Result"

    # Configration for Weekly Evaluations line - 24/02/2021
    week = fields.Char(string="Week")
    weekly_test_id = fields.Many2one('weekly.test', string="Weekly Evaluation", copy=False, ondelete='cascade')
    student_id = fields.Many2one('student.student', string='Student', copy=False , ondelete='cascade')
    date = fields.Date(string='Date', store=True)
    stage_id = fields.Many2one(related="student_id.stage_id", string='Stage', store=True)
    course_id = fields.Many2one(related="student_id.course_id", string='Course', store=True)
    batch_id = fields.Many2one(related="student_id.batch_id", string='Batch', store=True)
    semester_id = fields.Many2one(related="student_id.semester_id", string='Standard', store=True)
    division_id = fields.Many2one(related="student_id.division_id", string='Division', store=True)
    weekly_test_subject_id = fields.Many2one(related="weekly_test_id.weekly_test_subject_id", string='Weekly Evaluation Subject', store=True)
    min_marks = fields.Float('Min Marks', default=0.0)
    max_marks = fields.Float('Max Marks', default=0.0)
    obtained_linguistics_marks = fields.Float('Obtained Marks', copy=False)
    attitude_cw_marks = fields.Float('Attitude CW Marks', copy=False)
    attitude_hw_marks = fields.Float('Attitude HW Marks', copy=False)
    obtained_attitude_marks = fields.Float('Obtained Attitude Marks', copy=False)
    obtained_aptitude_marks = fields.Float('Obtained Aptitutde Marks', copy=False)
    state = fields.Selection ([
        ('draft', 'Draft'),
        ('pass', 'Pass'),
        ('fail', 'Fail'),
        ('not_attempt', 'Not Attempt')], track_visibility='onchange',
        string='Status', default='draft', copy=False)
    weekly_test_type = fields.Selection(related="weekly_test_id.test_type", store=True,
        string='Weekly Evaluation Type', copy=False)
    is_attempt = fields.Boolean("Is Not Attempt", copy=False)
    is_test_taken = fields.Boolean("Is Test Taken", copy=False)
    is_single_week = fields.Boolean("Is Single Week Test", copy=False)
    listening = fields.Float(string="Listening")
    speaking = fields.Float(string="Speaking")
    competence = fields.Float(string="Competence")

    @api.depends('student_id')
    def name_get(self):
        result = []
        for record in self:
            name = "[Weekly Evaluation Result]"
            if self.student_id and self.student_id.name:
                name = ' '.join([name, self.student_id.name])
            result.append((record.id, name))
        return result

    @api.onchange('is_attempt')
    def onchange_is_attempt(self):
        if self.is_attempt:
            self.obtained_linguistics_marks = False
            self.obtained_attitude_marks = False
            self.obtained_aptitude_marks = False

    @api.onchange('is_test_taken')
    def onchange_is_test_taken(self):
        if not self.is_test_taken:
            self.obtained_linguistics_marks = False
            self.obtained_attitude_marks = False
            self.obtained_aptitude_marks = False

    @api.onchange('obtained_linguistics_marks')
    def onchange_obtained_linguistics_marks(self):
        if not self.is_single_week:
            if self.max_marks < self.obtained_linguistics_marks:
                raise ValidationError(_('Linguistic Marks obtained must be less than or equal to Maximum Marks.'))
        if self.obtained_linguistics_marks > 0:
        	self.is_test_taken = True
        else:
        	self.is_test_taken = False

    @api.onchange('obtained_attitude_marks')
    def onchange_obtained_attitude_marks(self):
        if not self.is_single_week:
            if self.max_marks < self.obtained_attitude_marks:
                raise ValidationError(_('Attitude Marks obtained must be less than or equal to Maximum Marks.'))
        if self.obtained_attitude_marks > 0 and self.obtained_aptitude_marks > 0:
            self.is_test_taken = True
        else:
            self.is_test_taken = False

    @api.onchange('obtained_aptitude_marks')
    def onchange_obtained_aptitude_marks(self):
        if not self.is_single_week:
            if self.max_marks < self.obtained_aptitude_marks:
                raise ValidationError(_('Aptitude Marks obtained must be less than or equal to Maximum Marks.'))
        if self.obtained_aptitude_marks > 0 and self.obtained_attitude_marks > 0:
            self.is_test_taken = True
        else:
            self.is_test_taken = False

    @api.onchange('attitude_cw_marks')
    def onchange_attitude_cw_marks(self):
        if not self.attitude_cw_marks in range(0,int(self.weekly_test_subject_id.max_marks) + 1):
            raise ValidationError(_('Attitude CW marks should be in the range of 0 to %s.' %(str(self.weekly_test_subject_id.max_marks))))
        self.obtained_attitude_marks = 0
        self.obtained_attitude_marks += (self.attitude_cw_marks + self.attitude_hw_marks)
        self.obtained_attitude_marks = self.obtained_attitude_marks / 2

    @api.onchange('attitude_hw_marks')
    def onchange_attitude_hw_marks(self):
        if not self.attitude_hw_marks in range(0,int(self.weekly_test_subject_id.max_marks) + 1):
            raise ValidationError(_('Attitude HW marks should be in the range of 0 to %s.' %(str(self.weekly_test_subject_id.max_marks))))
        self.obtained_attitude_marks = 0
        self.obtained_attitude_marks += (self.attitude_cw_marks + self.attitude_hw_marks)
        self.obtained_attitude_marks = self.obtained_attitude_marks / 2

    @api.onchange('listening')
    def onchange_listening(self):
        if not self.listening in range(0,int(self.weekly_test_subject_id.listening) + 1):
            raise ValidationError(_('Listening marks should be in the range of 0 to %s.' %(str(self.weekly_test_subject_id.listening))))
        self.obtained_linguistics_marks = 0 
        self.obtained_linguistics_marks += (self.listening + self.speaking + self.competence)

    @api.onchange('speaking')
    def onchange_speaking(self):
        if not self.speaking in range(0,int(self.weekly_test_subject_id.speaking) + 1):
            raise ValidationError(_('Speaking marks should be in the range of 0 to %s.' %(str(self.weekly_test_subject_id.speaking))))
        self.obtained_linguistics_marks = 0 
        self.obtained_linguistics_marks += (self.listening + self.speaking + self.competence)

    @api.onchange('competence')
    def onchange_competence(self):
        if not self.competence in range(0,int(self.weekly_test_subject_id.competence) + 1):
            raise ValidationError(_('Competence marks should be in the range of 0 to %s.' %(str(self.weekly_test_subject_id.competence))))
        self.obtained_linguistics_marks = 0 
        self.obtained_linguistics_marks += (self.listening + self.speaking + self.competence)