# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from . import exam
from . import result
from . import grade
from . import exam_template
from . import res_config_settings
from . import academic_year
from . import extra_exam
from . import exam_sheet
from . import student
from . import weekly_test
from . import weekly_test_result
