# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, Warning


class Exam(models.Model):
    _name = 'exam.exam'
    _description = "Exam"

    def _compute_re_exam(self):
        for rec in self:
            rec.re_exam_count = 0
            exam_ids = self.search([('parent_exam_id', 'child_of', rec.ids), ('id', '!=', rec.id)])
            if exam_ids:
                rec.re_exam_count = len(exam_ids.ids)

    code = fields.Char(string='Code', copy=False, default='/')
    name = fields.Char(string='Name', size=32)
    grade_type = fields.Selection ([
        ('scale', 'Scale'),
        ('point', 'Point')], string='Grade Type',
        help="Select the type of grading used for this activity.\n \
        * If 'scale' is chosen, you can then choose the scale from the\
        'scale' dropdown. \n * If using 'point' grading, you can then enter\
         the maximum grade available for this activity.")
    academic_year_id = fields.Many2one('academic.year', string='Academic Year')
    start_date = fields.Date(string='Start Date', copy=False, default=fields.Date.today())
    end_date = fields.Date(string='End Date', copy=False, default=fields.Date.today())
    # classes_id = fields.Many2one('classes.classes', string="Classes")
    result_ids = fields.One2many('result.result', 'exam_id', string='Results', copy=False)
    stage_id = fields.Many2one('stage.stage', string='Stage')
    course_id = fields.Many2one('course.course', string='Course')
    batch_id = fields.Many2one('batch.batch', string='Batch')
    semester_id = fields.Many2one('semester.semester', string='Standard')
    division_id = fields.Many2one('division.division', string='Division')
    subject_id = fields.Many2one('subject.subject', string='Subject', copy=False)
    institute_id = fields.Many2one('res.company', string="Institute", default=lambda self: self.env.user.company_id)
    school_id = fields.Many2one('school.school', string='School Level', default=lambda self: self.env.user.school_id)
    result_date = fields.Date(string='Result Date', copy=False, default=fields.Date.today())
    state = fields.Selection ([
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('done', 'Done'),
        ('cancel', 'Cancel')], track_visibility='onchange',
        string='Status', default='draft', copy=False)
    exam_template_id = fields.Many2one('exam.template', string='Exam Template')
    exam_type = fields.Selection([('online', 'Online'), ('offline', 'Offline')], track_visibility='onchange',
        string='Exam Type', default='offline')
    is_division_exam = fields.Boolean(string="Is Division Wise Exam", default=True)
    re_exam_date = fields.Date(string='Re-Exam Date', copy=False)
    re_exam_count = fields.Integer(default=0, string="Re-Exam", compute=_compute_re_exam)
    is_re_exam = fields.Boolean(default=False, string="Is Re-Exam", copy=False)
    parent_exam_id = fields.Many2one('exam.exam', string='Parent Exam', copy=False)
    re_exam_id = fields.Many2one('exam.exam', string='Re-Exam', index=True, copy=False)
    child_ids = fields.One2many('exam.exam', 're_exam_id', string="Re-Exam", copy=False)
    academic_term = fields.Selection ([
        ('other', 'Other'),
        ('first_sessional', 'First Sessional'),
        ('first_term', 'First Term'),
        ('second_sessional', 'Second Sessional'),
        ('second_term', 'Second Term'),
        ('final', 'Final')], track_visibility='onchange',
        string='Academic Term', default='other')
    is_extra_subject = fields.Boolean("Is an Extra Subject?", related="subject_id.is_extra_subject")
    extra_result_ids = fields.One2many('extra.exam.result', 'exam_id', string="Extra Subject(s) Result", copy=False)

    _sql_constraints = [
        ('code', 'unique(code)', 'The Exam code must be unique!'),
    ]

    def unlink(self):
        ''' remove record'''
        for rec in self:
            if rec.state != 'draft' and rec.result_ids:
                raise Warning(_('You cannot remove the record in this state!'))
        return super(Exam, self).unlink()

    @api.onchange('result_date')
    def onchange_check_dates(self):
        if self.result_date and self.end_date and self.result_date < self.end_date:
            raise ValidationError(_('Result date of exam must be Greate than end date!'))

    @api.onchange('re_exam_date')
    def onchange_check_dates(self):
        if self.re_exam_date and self.result_date and self.re_exam_date < self.result_date:
            raise ValidationError(_('You can not create Re-Exam on the result date of main exam!'))

    def action_confirm(self):
        ctx = dict(self._context)
        students = self.with_context(ctx).get_students()
        if not students:
            raise ValidationError(_("Students not present in this standard, so you not allowed to confirm exam."))
        return self.write({'state': 'confirm'})

    def action_cancel(self):
        return self.write({'state': 'cancel'})

    def get_students(self):
        ctx = dict(self._context)
        students = False
        for exam in self:
            if not ctx.get('is_re_exam'):
                domain = [
                    ('school_id', '=', exam.school_id.id),
                    ('stage_id', '=', exam.stage_id.id),
                    ('course_id', '=', exam.course_id.id),
                    ('batch_id', '=', exam.batch_id.id),
                    ('semester_id', '=', exam.semester_id.id),
                ]
                if exam.is_division_exam and exam.division_id:
                    domain += [('division_id', '=', exam.division_id.id)]
                if not exam.is_extra_subject:
                    optional_students = self.env['student.student'].search(domain + [('optional_subject_ids', 'in', exam.subject_id.ids)])
                    compulsary_students = self.env['student.student'].search(domain + [('compulsary_subject_ids', 'in', exam.subject_id.ids)])
                    students = optional_students + compulsary_students
                else:
                    students = self.env['student.student'].search(domain + [('extra_subject_ids', 'in', exam.subject_id.ids)])
            else:
                exam_id = self.search([('parent_exam_id', 'child_of', exam.parent_exam_id.ids),
                                    ('id', '!=', exam.id)], order="id desc", limit=1)
                results = exam_id.mapped('result_ids').filtered(lambda l:
                    l.state in ['fail', 'not_attempt'] and
                    l.stage_id.id == exam.stage_id.id and
                    l.exam_id.school_id.id == exam.school_id.id and
                    l.course_id.id == exam.course_id.id and
                    l.batch_id.id == exam.batch_id.id and
                    l.semester_id.id == exam.semester_id.id and
                    l.subject_id.id == exam.subject_id.id)
                students = results.mapped('student_id')
        return students

    def create_re_exam(self):
        for exam in self:
            results = self.result_ids.filtered(lambda l: l.state in ['fail', 'not_attempt'])
            if not results:
                raise Warning(_("You can't create re-exam, there are not absent or fail student(s) result entry available."))

            config_obj = self.env['ir.config_parameter'].sudo()
            re_exam_time = config_obj.get_param('sync_exam.re_exam_time')
            if re_exam_time and exam.re_exam_count == int(re_exam_time):
                raise Warning(_("You can create re-exam only %s time(s)." % re_exam_time))
            if not exam.re_exam_date:
                raise ValidationError(_("Please configure re-exam date on exam view."))
            if exam.re_exam_date:
                vals = {
                    'school_id': exam.school_id.id,
                    "institute_id": exam.institute_id.id,
                    'stage_id': exam.stage_id.id,
                    'course_id': exam.course_id.id,
                    'batch_id': exam.batch_id.id,
                    'semester_id': exam.semester_id.id,
                    "is_division_exam": exam.is_division_exam,
                    "division_id": exam.division_id.id,
                    "name": 'Re-'+ exam.name,
                    "grade_type": exam.grade_type,
                    "academic_year_id": exam.academic_year_id.id,
                    "start_date": exam.re_exam_date,
                    "end_date": exam.re_exam_date,
                    "subject_id": exam.subject_id.id,
                    "exam_template_id": exam.exam_template_id.id,
                    "academic_term": exam.academic_term,
                    "exam_type": exam.exam_type,
                    "result_date": False,
                    "re_exam_date": False,
                    "is_re_exam": True,
                    "parent_exam_id": exam.id,
                }
                exam_id = self.create(vals)
                if exam_id:
                    exam.re_exam_id = exam_id.id
            return True

    def action_view_re_exam(self):
        ''' open a view on one of the given partner_id '''
        self.ensure_one()
        exam_ids = self.search([('parent_exam_id', 'child_of', self.ids), ('id', '!=', self.id)])
        action = self.env.ref('sync_exam.action_exam_management').read()[0]
        if len(exam_ids) > 1:
            action['domain'] = [('id', 'in', exam_ids.ids)]
        elif len(exam_ids) == 1:
            action['views'] = [(self.env.ref('sync_exam.view_exam_form').id, 'form')]
            action['res_id'] = exam_ids.ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def create_results(self):
        ctx = dict(self._context)
        for exam in self:
            results = []
            students = exam.with_context(ctx).get_students()
            if not students:
                raise ValidationError(_("Students not present in this standard, so you not allowed to create results."))
            for student in students:
                vals = {
                    'student_id': student.id,
                    'date': exam.result_date,
                }
                if not exam.is_extra_subject:
                    vals.update({
                        'max_marks': exam.exam_template_id.max_mark or False,
                        'min_marks': exam.exam_template_id.pass_mark or False,
                    })
                results.append(vals)
            if not exam.is_extra_subject:
                exam.result_ids = [(0, 0, line) for line in results]
            else:
                exam.extra_result_ids = [(0, 0, line) for line in results]

    def action_done(self):
        ctx = dict(self._context)
        students = self.with_context(ctx).get_students()
        if not students:
            raise ValidationError(_("Students not present in this standard, so you not allowed to done exam."))
        return self.write({'state': 'done'})

    def action_reset_draft(self):
        return self.write({'state': 'draft'})

    @api.onchange('school_id')
    def onchange_school_id(self):
        """
            Set Institute base on School.
        """
        institutes = []
        self.institute_id = False
        self.stage_id = False
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False
        self.subject_id = False
        school_ids = False
        if self.school_id:
            school_ids = self.school_id.ids
            self.institute_id = self.school_id.institute_id.id
            institutes = self.institute_id.ids
        return {'domain':{'institute_id': [('id', 'in', institutes)], 'stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False
        self.subject_id = False

    @api.onchange('start_date')
    def onchange_start_date(self):
        if self.start_date:
            self.end_date = self.start_date

    @api.onchange('exam_template_id')
    def onchange_stage_id(self):
        if self.exam_template_id and self.result_ids:
            self.result_ids.write({
                'min_marks': self.exam_template_id.pass_mark,
                'max_marks': self.exam_template_id.max_mark
            })

    @api.onchange('course_id')
    def onchange_course_id(self):
        self.batch_id = False
        self.semester_id = False
        self.division_id = False
        self.subject_id = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        self.semester_id = False
        self.division_id = False
        self.subject_id = False
        self.academic_year_id = False
        if self.batch_id and self.batch_id.academic_year_id:
            self.academic_year_id = self.batch_id.academic_year_id.id
        return {'domain':{'semester_id': [('id', 'in', self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        self.division_id = False
        self.subject_id = False
        if not self.semester_id or not self.batch_id:
            self.division_id = False
        divisions = []
        subjects = []
        if self.semester_id and self.batch_id:
            divisions = self.semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.batch_id.id).mapped('division_ids').mapped('division_id').ids
            self.subject_id = False
            subjects = self.semester_id.semester_history_ids.mapped('subject_ids').ids
        return {'domain':{'division_id': [('id', 'in', divisions)], 'subject_id': [('id', 'in', subjects)]}}

    @api.model
    def create(self, vals):
        if not vals.get('is_re_exam') and vals.get('code', _('/')) == _('/'):
            vals['code'] = self.env['ir.sequence'].next_by_code('exam.exam') or _('/')
        if vals.get('is_re_exam') and vals.get('code', _('/')) == _('/'):
            vals['code'] = self.env['ir.sequence'].next_by_code('re-exam.exam') or _('/')
        exam = super(Exam, self).create(vals)
        #Check same exam code
        exam._check_exam()
        if exam.result_date and exam.end_date and exam.result_date < exam.end_date:
            raise ValidationError(_('Result date of exam must be Greate than end date!'))
        if exam.re_exam_date and exam.result_date and exam.re_exam_date < exam.result_date:
            raise ValidationError(_('You can not create Re-Exam on the result date of main exam!'))
        return exam

    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for obj in self:
            if obj.start_date > obj.end_date:
                raise ValidationError(_('start date of exam must be less than end date!'))

    def _check_exam(self):
        for exam in self:
            domain = [
                ('id', '!=', exam.id),
                ('school_id', '=', exam.school_id.id),
                ('stage_id', '=', exam.stage_id.id),
                ('course_id', '=', exam.course_id.id),
                ('batch_id', '=', exam.batch_id.id),
                ('semester_id', '=', exam.semester_id.id),
                ('start_date', '=', exam.start_date),
                ('end_date', '=', exam.end_date),
                ('academic_term', '=', exam.academic_term),
                ('academic_year_id', '=', exam.academic_year_id.id),
                ('subject_id', '=', exam.subject_id.id)
            ]
            if exam.is_division_exam and exam.division_id:
                domain += [('division_id', '=', exam.division_id.id)]
            exam_ids = self.search(domain)
            if exam_ids:
                raise ValidationError(_('You cannot create/write same exam records!'))

    def copy(self, default=None):
        self.ensure_one()
        code = self.env['ir.sequence'].next_by_code('exam.exam')
        chosen_name = default.get('name') if default else ''
        new_name = chosen_name or _('%s (copy)') % self.name
        default = dict(default or {}, code=code, name=new_name)
        return super(Exam, self).copy(default)

    @api.depends('name', 'code')
    def name_get(self):
        result = []
        for record in self:
            name = record.name or False
            if name and record.code:
                name = ''.join([name, ' [', record.code, ']'])
            result.append((record.id, name))
        return result

    def write(self, vals):
        record = super(Exam, self).write(vals)
        for exam in self:
            #Check same exam code
            exam._check_exam()
            if exam.result_date and exam.end_date and exam.result_date < exam.end_date:
                raise ValidationError(_('Result date of exam must be Greate than end date!'))
            if exam.re_exam_date and exam.result_date and exam.re_exam_date < exam.result_date:
                raise ValidationError(_('You can not create Re-Exam on the result date of main exam!'))
        return record

    def student_send_mail(self):
        self.ensure_one()
        if not self.is_re_exam and not self.re_exam_date:
            raise ValidationError(_("Please configure re-exam date on exam view."))
        results = self.result_ids.filtered(lambda l: l.state in ['fail', 'not_attempt'])
        if not results:
            raise ValidationError(_("Results are not present in fail or not attempt."))

        for result in results:
            if result.student_id and result.student_id.middle_name:
                mail_template_id = self.env.ref('sync_exam.mail_template_for_fail_students')
                # Mail For Failer student notice
                if mail_template_id:
                    mail_template_id.sudo().send_mail(result.id, force_send=False, raise_exception=False)