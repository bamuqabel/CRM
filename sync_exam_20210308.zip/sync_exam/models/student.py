# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from nvd3 import multiBarChart
from odoo import modules, models, fields, api, _


class StudentStudent(models.Model):
    _inherit = 'student.student'

    result_ids = fields.One2many('result.result', 'student_id', string='Results', copy=False)
    exam_sheet_ids = fields.One2many('exam.sheet', 'student_id', string='Exam Sheets', copy=False)
    extra_result_ids = fields.One2many('extra.exam.result', 'student_id', string='Extra Subject(s) Results', copy=False)
    # body_html = fields.Html('Body', translate=True, sanitize=False)

    def bar_garph(self, result_list):
        self.ensure_one()
        chart = multiBarChart(width=900, height=400, x_axis_format=None)
        xsubject = [line.get('subject_id').name for line in result_list]
        ymax = [line.get('max_marks') for line in result_list]
        ymarks_obtained = [line.get('total_obtained_marks') for line in result_list]

        chart.add_serie(name="Max", x=xsubject, y=ymax)
        chart.add_serie(name="Marks Obtained", x=xsubject, y=ymarks_obtained)
        chart.buildhtml()

        _html = chart.htmlcontent
        # if _html:
        #     self.body_html = _html
        return _html

    def result_domain(self):
        domain = [
            ('student_id', '=', self.id),
            ('exam_id.school_id', '=', self.school_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('course_id', '=', self.course_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('division_id', '=', self.division_id.id),
            ('exam_id.academic_year_id', '=', self.batch_id.academic_year_id.id),
        ]
        return domain

    def result_calculation(self, academic_term):
        """ Result Calculation """
        result_list = []
        subjects = self.optional_subject_ids + self.compulsary_subject_ids
        for subject in subjects:
            domain = self.result_domain()
            domain += [('subject_id', '=', subject.id),
                ('exam_id.academic_term', '=', academic_term)]
            result_id = self.env['result.result'].search(domain, order='create_date desc', limit=1)
            vals = {
                'subject_id': subject,
                'min_marks': result_id.min_marks or 0.0,
                'max_marks': result_id.max_marks or 0.0,
                'total_obtained_marks': result_id.total_obtained_marks,
                'state': result_id.state,
                'result_id': result_id,
            }
            result_list.append(vals)
        return result_list

    def term_result_calculation(self, academic_term):
        main_result_list = []
        result_list = []
        if academic_term == 'first_term':
            first_sessional_result_list = self.result_calculation('first_sessional')
            first_term_result_list = self.result_calculation('first_term')
            result_list.extend(first_sessional_result_list + first_term_result_list)
        elif academic_term == 'second_term':
            # first_sessional_result_list = self.result_calculation('first_sessional')
            # first_term_result_list = self.result_calculation('first_term')
            second_sessional_result_list = self.result_calculation('second_sessional')
            second_term_result_list = self.result_calculation('second_term')
            result_list.extend(second_sessional_result_list + second_term_result_list)
        for line in result_list:
            if line.get('subject_id') in [pro['subject_id'] for pro in main_result_list]:
                [pro.update({'min_marks': (pro.get('min_marks') + line.get('min_marks')),
                'max_marks': (pro.get('max_marks') + line.get('max_marks')),
                'total_obtained_marks': (pro.get('total_obtained_marks') + line.get('total_obtained_marks'))
                }) for pro in main_result_list if pro['subject_id'] == line.get('subject_id')]
            else:
                main_result_list.append(line)
        return main_result_list

    def final_result_calculation(self, academic_term):
        main_result_list = []
        final_result_list = []
        second_term_result = []
        first_term_result = []
        if academic_term == 'final':
            first_term_result = self.term_result_calculation('first_term')
            second_term_result = self.term_result_calculation('second_term')
            final_result_list.extend(first_term_result + second_term_result)
        for line in final_result_list:
            [line.update({'second_term_marks': pro.get('total_obtained_marks') or 0.0}) for pro in second_term_result if pro['subject_id'] == line.get('subject_id')]
            [line.update({'first_term_marks': pro.get('total_obtained_marks') or 0.0}) for pro in first_term_result if pro['subject_id'] == line.get('subject_id')]
            [line.update({'total_obtained_marks': (line.get('second_term_marks') + line.get('first_term_marks')) or 0.0}) for pro in main_result_list if pro['subject_id'] == line.get('subject_id')]

            if line.get('subject_id') in [pro['subject_id'] for pro in main_result_list]:
                [pro.update({'min_marks': (pro.get('min_marks') + line.get('min_marks')),
                'max_marks': (pro.get('max_marks') + line.get('max_marks')),
                'total_obtained_marks': (line.get('second_term_marks') + line.get('first_term_marks')) or 0.0
                }) for pro in main_result_list if pro['subject_id'] == line.get('subject_id')]
            else:
                main_result_list.append(line)
        return main_result_list

    def grand_result_domain(self):
        domain = [
            ('student_id', '=', self.id),
            ('school_id', '=', self.school_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('course_id', '=', self.course_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('division_id', '=', self.division_id.id),
            ('academic_year_id', '=', self.batch_id.academic_year_id.id),
        ]
        return domain

    def grand_result_calculation(self, academic_term):
        """Grand Result Calculation """
        grand_list = []
        domain = self.grand_result_domain()
        domain += [('academic_term', '=', academic_term)]
        sheet_id = self.env['exam.sheet'].search(domain, order='create_date desc', limit=1)
        for grand in sheet_id.grand_ids:
            vals = {
                'subject_id': grand.type,
                'min_marks': grand.min_marks or 0.0,
                'max_marks': grand.max_marks or 0.0,
                'total_obtained_marks': grand.obtained_marks or 0.0,
                'state': grand.state,
                'grand_id': grand,
            }
            grand_list.append(vals)
        return grand_list

    def final_grand_result_calculation(self, academic_term):
        main_grand_result_list = []
        final_result_list = []
        second_term_result = []
        first_term_result = []
        if academic_term == 'final':
            first_term_result = self.grand_result_calculation('first_term')
            second_term_result = self.grand_result_calculation('second_term')
            final_result_list.extend(first_term_result + second_term_result)
        for line in final_result_list:
            [line.update({'second_term_marks': pro.get('total_obtained_marks') or 0.0}) for pro in second_term_result if pro['subject_id'] == line.get('subject_id')]
            [line.update({'first_term_marks': pro.get('total_obtained_marks') or 0.0}) for pro in first_term_result if pro['subject_id'] == line.get('subject_id')]
            [line.update({'total_obtained_marks': (line.get('second_term_marks') + line.get('first_term_marks')) or 0.0}) for pro in main_grand_result_list if pro['subject_id'] == line.get('subject_id')]

            if line.get('subject_id') in [pro['subject_id'] for pro in main_grand_result_list]:
                [pro.update({'min_marks': (pro.get('min_marks') + line.get('min_marks')) or 0.0,
                'max_marks': (pro.get('max_marks') + line.get('max_marks')) or 0.0,
                'total_obtained_marks': (line.get('second_term_marks') + line.get('first_term_marks')) or 0.0
                }) for pro in main_grand_result_list if pro['subject_id'] == line.get('subject_id')]
            else:
                main_grand_result_list.append(line)
        return main_grand_result_list

    def get_class_teacher(self):
        """
            GET Class Teacher
        """
        for student in self:
            faculty_subject_id = self.env['faculty.subject'].sudo().search([
                ('course_id', '=', student.course_id.id),
                ('batch_id', '=', student.batch_id.id),
                ('semester_id', '=', student.semester_id.id),
                ('division_id', '=', student.division_id.id),
            ], limit=1)
            faculty_id = faculty_subject_id.faculty_id
            return faculty_id

    def extra_exam_result_calculation(self, academic_term):
        extra_result_list = []
        subjects = self.extra_subject_ids
        for subject in subjects:
            domain = self.result_domain()
            domain += [('exam_id.academic_term', '=', academic_term), ('subject_id', '=', subject.id)]
            exam_id = self.env['extra.exam.result'].search(domain, order='create_date desc', limit=1)
            vals = {
                'subject_id': subject,
                'result_id': exam_id,
                'grade_type': exam_id.grade_type,
            }
            extra_result_list.append(vals)
        return extra_result_list

    def grand_calculation(self, result_list):
        total_obtained_marks = sum([line.get('total_obtained_marks') for line in result_list if line.get('total_obtained_marks')])
        total_max_marks = sum([line.get('max_marks') for line in result_list if line.get('max_marks')])
        grade_point = self.get_grade_point(total_obtained_marks, total_max_marks)
        grade_id = self.get_grade_id(grade_point)
        grand_dict = {'percentage': grade_point, 'grade_id': grade_id}
        return grand_dict

    def get_grade_point(self, total_obtained_marks, total_max_marks):
        grade_point = 0.0
        if total_obtained_marks and total_max_marks:
            grade_point = (total_obtained_marks * 100)/total_max_marks
        return grade_point

    def get_grade_id(self, grade_point):
        grade_id = self.env['grade.grade']
        if grade_point:
            domain = [('min_points', '<=', grade_point),
                ('max_points', '>=', grade_point)]
            grade_id = self.env['grade.grade'].search(domain , limit=1)
        return grade_id

    def get_status(self, total_obtained_marks, min_marks):
        if total_obtained_marks and min_marks:
            if total_obtained_marks < min_marks:
                return 'Fail'
            elif total_obtained_marks >= min_marks:
                return 'Pass'
        return 'NA'
