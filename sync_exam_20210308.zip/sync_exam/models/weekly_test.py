# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, Warning


class WeeklyTest(models.Model):
    _name = 'weekly.test'
    _description = 'Weekly Evaluation'

    @api.model
    def default_get(self, fields):
        res = super(WeeklyTest,self).default_get(fields)
        context = dict(self._context)
        weekly_eval_sub_obj = self.env['weekly.test.subject'].search([])
        weekly_test_subject_id = False
        if context.get('current_view_name') == 'aptitude_attitude':
            weekly_test_subject_id = weekly_eval_sub_obj.filtered(lambda l:l.weekly_subject_type == 'aptitude_attitude').id
        elif context.get('current_view_name') == 'linguistic':
            weekly_test_subject_id = weekly_eval_sub_obj.filtered(lambda l:l.weekly_subject_type == 'linguistic_skills').id
        res.update({'weekly_test_subject_id':weekly_test_subject_id})
        return res

    # Configuration for Weekly Evaluation - 24/02/2021
    name = fields.Char(string='Name')
    code = fields.Char(string='Code', copy=False, default='/')
    academic_year_id = fields.Many2one('academic.year', string='Academic Year')
    weekly_test_result_ids = fields.One2many('weekly.test.result', 'weekly_test_id', string='Results', copy=False)
    stage_id = fields.Many2one('stage.stage', string='Stage')
    course_id = fields.Many2one('course.course', string='Course')
    batch_id = fields.Many2one('batch.batch', string='Batch')
    semester_id = fields.Many2one('semester.semester', string='Standard')
    division_id = fields.Many2one('division.division', string='Division')
    weekly_test_subject_id = fields.Many2one('weekly.test.subject', string='Weekly Evaluation Subject', copy=False)
    institute_id = fields.Many2one('res.company', string="Institute", default=lambda self: self.env.user.company_id)
    school_id = fields.Many2one('school.school', string='School Level', default=lambda self: self.env.user.school_id)
    state = fields.Selection ([
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('done', 'Done'),
        ('cancel', 'Cancel')], track_visibility='onchange',
        string='Status', default='draft', copy=False)
    exam_template_id = fields.Many2one('exam.template', string='Exam Template', required=True)
    week_id = fields.Many2one('weekly.exams.values', string="Week")
    test_type = fields.Selection([('online', 'Online'), ('offline', 'Offline')], track_visibility='onchange',
        string='Test Type', default='offline')
    academic_term = fields.Selection ([
        ('other', 'Other'),
        ('first_sessional', 'First Sessional'),
        ('first_term', 'First Term'),
        ('second_sessional', 'Second Sessional'),
        ('second_term', 'Second Term'),
        ('final', 'Final')], track_visibility='onchange',
        string='Academic Term', default='other')
    is_single_week_template = fields.Boolean(string="Is Single Week Template", compute="_get_exam_template")

    _sql_constraints = [
        ('code', 'unique(code)', 'The Exam code must be unique!'),
    ]

    @api.onchange('exam_template_id')
    def onchange_exam_template_id(self):
        return {'domain': {'week_id': [('exam_template_id', '=', self.exam_template_id.id)]}}

    @api.onchange('weekly_test_subject_id')
    def onchange_weekly_test_subject_id(self):
        if self.weekly_test_subject_id and self.weekly_test_subject_id.single_time_test:
            self.is_single_week_template = True
        else:
            self.is_single_week_template = False

    def _get_exam_template(self):
        for rec in self:
            if rec.weekly_test_subject_id and rec.weekly_test_subject_id.single_time_test:
                rec.is_single_week_template = True
            else:
                rec.is_single_week_template = False

    def unlink(self):
        ''' remove record'''
        for rec in self:
            if rec.state != 'draft' and rec.weekly_test_result_ids:
                raise Warning(_('You cannot remove the record in this state!'))
        return super(WeeklyTest, self).unlink()

    def create_weekly_tests(self):
        for test in self:
            domain = [
                ('school_id', '=', test.school_id.id),
                ('stage_id', '=', test.stage_id.id),
                ('course_id', '=', test.course_id.id),
                ('batch_id', '=', test.batch_id.id),
                ('semester_id', '=', test.semester_id.id),
                ('division_id', '=', test.division_id.id)
            ]
            students = self.env['student.student'].search(domain)
            week_results = []
            for student in students:
                if not test.exam_template_id and not test.exam_template_id.weekly_exams:
                    raise ValidationError(_("Number of weeks not set in this exam template."))
                else:
                    if test.weekly_test_subject_id.single_time_test:
                        vals = {
                            'week': 'Week 1',
                            'student_id':student.id,
                            'max_marks': test.weekly_test_subject_id.semester_total_marks or False,
                            'min_marks': test.weekly_test_subject_id.semester_min_marks or False,
                            'weekly_test_type': test.test_type or False,
                            'is_single_week':True,
                        }
                        week_results.append(vals)
                    else:
                        vals = {
                            'week': test.week_id.name,
                            'student_id':student.id,
                            'max_marks': test.weekly_test_subject_id.max_marks or False,
                            'min_marks': test.weekly_test_subject_id.min_marks or False,
                            'weekly_test_type': test.test_type or False,
                            'is_single_week':False,
                        }
                        week_results.append(vals)
            test.weekly_test_result_ids = [(0, 0, line) for line in week_results]

    def _check_weekly_test(self):
        for test in self:
            domain = [
                ('id', '!=', test.id),
                ('school_id', '=', test.school_id.id),
                ('stage_id', '=', test.stage_id.id),
                ('course_id', '=', test.course_id.id),
                ('batch_id', '=', test.batch_id.id),
                ('semester_id', '=', test.semester_id.id),
                ('division_id', '=', test.division_id.id),
                ('academic_term', '=', test.academic_term),
                ('academic_year_id', '=', test.academic_year_id.id),
                ('exam_template_id', '=', test.exam_template_id.id),
                ('weekly_test_subject_id', '=', test.weekly_test_subject_id.id),
                ('week_id', '=', test.week_id.id)
            ]
            test_ids = self.search(domain)
            if test_ids:
                raise ValidationError(_('You cannot create/write same test records!'))

    @api.onchange('school_id')
    def onchange_school_id(self):
        institutes = []
        self.institute_id = False
        self.stage_id = False
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False
        school_ids = False
        if self.school_id:
            school_ids = self.school_id.ids
            self.institute_id = self.school_id.institute_id.id
            institutes = self.institute_id.ids
        return {'domain':{'institute_id': [('id', 'in', institutes)], 'stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False

    @api.onchange('course_id')
    def onchange_course_id(self):
        self.batch_id = False
        self.semester_id = False
        self.division_id = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        self.semester_id = False
        self.division_id = False
        self.academic_year_id = False
        if self.batch_id and self.batch_id.academic_year_id:
            self.academic_year_id = self.batch_id.academic_year_id.id
        return {'domain':{'semester_id': [('id', 'in', self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        self.division_id = False
        if not self.semester_id or not self.batch_id:
            self.division_id = False
        divisions = []
        if self.semester_id and self.batch_id:
            divisions = self.semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.batch_id.id).mapped('division_ids').mapped('division_id').ids
        return {'domain':{'division_id': [('id', 'in', divisions)]}}

    def action_confirm(self):
        domain = [
            ('school_id', '=', self.school_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('course_id', '=', self.course_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('division_id', '=', self.division_id.id)
        ]
        students = self.env['student.student'].search(domain)
        if not students:
            raise ValidationError(_("Students not present in this standard, so you not allowed to confirm weekly evaluation."))
        return self.write({'state': 'confirm'})

    def action_cancel(self):
        return self.write({'state': 'cancel'})

    def action_done(self):
        domain = [
            ('school_id', '=', self.school_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('course_id', '=', self.course_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('division_id', '=', self.division_id.id)
        ]
        students = self.env['student.student'].search(domain)
        if not students:
            raise ValidationError(_("Students not present in this standard, so you not allowed to done weekly evaluation."))
        return self.write({'state': 'done'})

    def action_reset_draft(self):
        return self.write({'state': 'draft'})

    def copy(self, default=None):
        self.ensure_one()
        code = self.env['ir.sequence'].next_by_code('weekly.test')
        chosen_name = default.get('name') if default else ''
        new_name = chosen_name or _('%s (copy)') % self.name
        default = dict(default or {}, code=code, name=new_name)
        return super(WeeklyTest, self).copy(default)

    @api.model
    def create(self, vals):
        if vals.get('code', _('/')) == _('/'):
            vals['code'] = self.env['ir.sequence'].next_by_code('weekly.test') or _('/')
        test = super(WeeklyTest, self).create(vals)
        #Check same Weekly Evaluation code
        test._check_weekly_test()
        return test

    def write(self, vals):
        record = super(WeeklyTest, self).write(vals)
        for test in self:
            #Check same Weekly Evaluation code
            test._check_weekly_test()
        return record

    @api.depends('name', 'code')
    def name_get(self):
        result = []
        for record in self:
            name = record.name or False
            if name and record.code:
                name = ''.join([name, ' [', record.code, ']'])
            result.append((record.id, name))
        return result


class WeeklyTestSubject(models.Model):
    _name = 'weekly.test.subject'
    _description = 'Weekly Evaluation Subject'

    name = fields.Char(string='Name')
    weekly_subject_type = fields.Selection([
        ('aptitude_attitude', 'Aptitude/Attitude'),
        ('linguistic_skills', 'Linguistic Skills')],
        string='Weekly Subject Type')
    single_time_test = fields.Boolean(string='Single Time Test')
    max_marks = fields.Integer(string='Maximum marks')
    min_marks = fields.Integer(string='Minimum marks')
    semester_total_marks = fields.Integer(string='Semester Total Marks')
    semester_min_marks = fields.Integer(string='Semester Passing Marks')
    listening = fields.Float(string="Listening")
    speaking = fields.Float(string="Speaking")
    competence = fields.Float(string="Competence")

    @api.onchange('min_marks')
    def onchange_min_marks(self):
        if self.min_marks > self.max_marks:
            raise ValidationError(_('Minimum Marks should be less than Maximum Marks.'))

    @api.onchange('max_marks')
    def onchange_max_marks(self):
        if self.max_marks < self.min_marks:
            raise ValidationError(_('Maximum Marks should be more than Minimum Marks.'))

    @api.onchange('semester_min_marks')
    def onchange_semester_min_marks(self):
        if self.semester_min_marks > self.semester_total_marks:
            raise ValidationError(_('Semester Passing Marks should be less than Semester Maximum Marks.'))

    @api.onchange('semester_total_marks')
    def onchange_semester_total_marks(self):
        if self.semester_total_marks < self.semester_min_marks:
            raise ValidationError(_('Semester Maximum Marks should be more than Semester Passing Marks.'))