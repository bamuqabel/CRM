# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class Grade(models.Model):
    _name = 'grade.grade'
    _description = "Grade"

    name = fields.Char(string='Name', size=32, copy=False, required=True)
    min_points = fields.Float('Min Points(%)', copy=False, required=True, default=0.0)
    max_points = fields.Float('Max Points(%)', copy=False, required=True, default=0.0)

    _sql_constraints = [
        ('check_max_points', "CHECK((max_points > min_points))", "Minimum Points should be less than Maximum Points."),
        ('name', 'unique(name)', 'The Grade name must be unique!')
    ]
