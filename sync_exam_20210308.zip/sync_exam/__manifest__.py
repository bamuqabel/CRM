# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

{
    'name': 'Exam Management',
    'version': '1.0',
    'website' : '',
    'category': 'Tools',
    'summary': 'Exam Management',
    'description': """
""",
    'author': 'Synconics Technologies Pvt. Ltd.',
    'website': 'http://www.synconics.in',
    'depends': ['sync_ems'],
    'data': [
        'security/exam_security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'data/mail_template.xml',
        'data/paper_format.xml',
        'data/weekly_test_subjects_data.xml',
        'views/exam_view.xml',
        'views/weekly_test_view.xml',
        'views/result_view.xml',
        'views/grade_views.xml',
        'views/academic_year_view.xml',
        'views/student_view.xml',
        'views/exam_template_view.xml',
        'views/res_config_settings_views.xml',
        'views/batch_views.xml',
        'views/exam_sheet_view.xml',
        'wizard/student_receiving_list_wiz_view.xml',
        'wizard/student_marksheet_wiz_view.xml',
        'report/receiving_list_template.xml',
        'report/student_marksheet_template.xml',
        'menu.xml',
        ],
    # 'external_dependencies': {
    #     'python': ['python-nvd3']
    # },
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

