# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import api, models, _


class StudentMarksheetTemplate(models.AbstractModel):
    _name = 'report.sync_exam.student_marksheet_template'
    _description = 'Wiz Student(s) Marksheet Template'

    @api.model
    def _get_report_values(self, docids, data=None):
        doc_model = []
        if data:
            doc_model = data.get('model')
        return {
            'doc_ids': docids,
            'doc_model': doc_model,
            'data': data,
        }

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
