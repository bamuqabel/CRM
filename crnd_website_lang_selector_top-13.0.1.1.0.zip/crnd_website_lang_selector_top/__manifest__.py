{
    "name": "Website Language selector (top)",
    "summary": "Move website's language selector on top",
    "version": "13.0.1.1.0",
    'author': "Center of Research and Development",
    'website': "https://crnd.pro",
    'category': 'Website',
    'license': 'OPL-1',
    "depends": [
        "website",
    ],
    "data": [
        "views/templates.xml",
    ],
    'images': ['static/description/banner.gif'],
    'price': 5.95,
    'currency': 'EUR',
}
