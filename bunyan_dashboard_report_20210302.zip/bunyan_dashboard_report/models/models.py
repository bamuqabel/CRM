# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell
import base64
from io import BytesIO
from datetime import datetime, timedelta
from collections import OrderedDict
from dateutil.relativedelta import relativedelta


class DashboardReport(models.TransientModel):
    _name = 'dashboard.report'
    _description = 'Dashboard Report'

    date_from = fields.Date(string="From", required=False, default=fields.Date.context_today)
    date_to = fields.Date(string="To", required=False, default=fields.Date.context_today)

    @api.constrains('from_date', 'to_date')
    def _check_start_end_dates(self):
        for sheet in self:
            if sheet.date_from > sheet.date_to:
                raise ValidationError('The From date cannot be later than the end date.')

    def print_xlsx(self):
        start = fields.Date.to_date(self.date_from)
        end = fields.Date.to_date(self.date_to)
        months = OrderedDict(((start + timedelta(_)).strftime("%b %y"), 0) for _ in range((end - start).days))
        months_dates = OrderedDict(((start + timedelta(_)).strftime("%Y-%m-1"), 0) for _ in range((end - start).days))
        dates = list(months)
        mo_dates = list(months_dates)
        employee_obj = self.env['hr.employee'].sudo()
        data_dates = {alpha_date:{} for alpha_date in dates}
        # Saudi Males
        dates_index = 0
        for dd in mo_dates:
            if mo_dates[dates_index] != mo_dates[-1]:
                sa_male_count = employee_obj.search_count([('country_id', '=', self.env.ref('base.sa').id), ('gender', '=', 'male'), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                sa_female_count = employee_obj.search_count([('country_id', '=', self.env.ref('base.sa').id), ('gender', '=', 'female'), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                sa_all_count = employee_obj.search_count([('country_id', '=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                all_sa_emp = employee_obj.search([('country_id', '=', self.env.ref('base.sa').id), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index + 1]), ('date_of_leave', '=', False)])
                all_emp_sa_days = []
                for emp in all_sa_emp:
                    all_emp_sa_days.append((fields.Date.today() - fields.Date.to_date(emp.date_of_join)).days / 365)
                tenure_saudi = sum(all_emp_sa_days) / len(all_emp_sa_days)

                all_notsa_emp = employee_obj.search([('country_id', '=', self.env.ref('base.sa').id), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index + 1]), ('date_of_leave', '=', False)])
                all_emp_notsa_days = []
                for emp in all_notsa_emp:
                    all_emp_notsa_days.append((fields.Date.today() - fields.Date.to_date(emp.date_of_join)).days / 365)
                tenure_not_saudi = sum(all_emp_notsa_days) / len(all_emp_notsa_days)

                sa_all_male_manager_count = employee_obj.search_count([('manager', '=', True),  ('gender', '=', 'male'),('country_id', '=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                sa_all_female_manager_count = employee_obj.search_count([('manager', '=', True),  ('gender', '=', 'female'),('country_id', '=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                sa_all = employee_obj.sudo().search([('country_id', '=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                saudi_ages = [e.age for e in sa_all]
                saudi_avg_ages = sum(saudi_ages) / len(saudi_ages)

                # There is no XML ID for HR Department, The primary key for the department is 35 for this environment.
                hr_employee_count = employee_obj.search_count([('department_id', '=', 35), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index + 1]), ('date_of_leave', '=', False)])

                not_sa_all_count = employee_obj.search_count([('country_id', '!=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                not_sa_all = employee_obj.sudo().search([('country_id', '!=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                not_sa_all_manager = employee_obj.sudo().search_count([('manager', '=', True),('country_id', '!=', self.env.ref('base.sa').id), ('gender', 'in', ('male', 'female')), ('date_of_join', '<=', mo_dates[dates_index]), '|', ('date_of_leave', '<=', mo_dates[dates_index+1]), ('date_of_leave', '=', False)])
                not_saudi_ages = [e.age for e in not_sa_all]
                not_saudi_avg_ages = sum(not_saudi_ages) / len(saudi_ages)
                saudi_joiners_count = employee_obj.search_count([('country_id', '=', self.env.ref('base.sa').id), ('date_of_join', '>=', mo_dates[dates_index]), ('date_of_join', '<=', mo_dates[dates_index+1])])

                saudi_resigned_count = employee_obj.search_count([('employee_status', '=', 'inactive'), ('country_id', '=', self.env.ref('base.sa').id), ('date_of_leave', '>=', mo_dates[dates_index]), ('date_of_leave', '<=', mo_dates[dates_index+1])])
                saudi_terminated_count = employee_obj.search_count([('employee_status', '=', 'terminate'), ('country_id', '=', self.env.ref('base.sa').id), ('date_of_leave', '>=', mo_dates[dates_index]), ('date_of_leave', '<=', mo_dates[dates_index+1])])

                not_saudi_joiners_count = employee_obj.search_count([('country_id', '!=', self.env.ref('base.sa').id), ('date_of_join', '>=', mo_dates[dates_index]), ('date_of_join', '<=', mo_dates[dates_index+1])])
                not_saudi_resigned_count = employee_obj.search_count([('employee_status', '=', 'inactive'), ('country_id', '!=', self.env.ref('base.sa').id), ('date_of_leave', '>=', mo_dates[dates_index]),('date_of_leave', '<=', mo_dates[dates_index + 1])])
                not_saudi_terminated_count = employee_obj.search_count([('employee_status', '=', 'terminate'), ('country_id', '=', self.env.ref('base.sa').id), ('date_of_leave', '>=', mo_dates[dates_index]), ('date_of_leave', '<=', mo_dates[dates_index + 1])])

                data_dates[dates[dates_index]].update({'tenure_saudi':tenure_saudi, 'tenure_not_saudi':tenure_not_saudi,'hr_employee_count':hr_employee_count,'not_sa_all_manager': not_sa_all_manager, 'sa_all_female_manager_count':sa_all_female_manager_count,'sa_all_male_manager_count':sa_all_male_manager_count, 'not_saudi_avg_ages': not_saudi_avg_ages, 'saudi_avg_ages': saudi_avg_ages, 'not_saudi_resigned_count':not_saudi_resigned_count,'not_saudi_terminated_count':not_saudi_terminated_count, 'saudi_resigned_count':saudi_resigned_count,'saudi_terminated_count': saudi_terminated_count,'not_saudi_joiners_count': not_saudi_joiners_count, 'saudi_joiners_count': saudi_joiners_count, 'sa_male_count': sa_male_count, 'sa_female_count': sa_female_count, 'sa_all_count': sa_all_count, 'not_sa_all_count': not_sa_all_count})
                dates_index += 1

        return self.dashboard_report_xlsx(data_dates)

    def dashboard_report_xlsx(self, dates):
        filename = 'Dashboard_Report_' + str(self.date_from) + '_to_' + str(self.date_to) + '.xlsx'
        fp = BytesIO()
        workbook = xlsxwriter.Workbook(fp)
        heading = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'bg_color': "#FFDAB9"})
        heading_red = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'bg_color': "#FFDAB9", 'color': 'red'})
        bold = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': "#C0C0C0"})
        bold_header = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': "#34a4eb"})
        amount_bold = workbook.add_format({'bold': True, 'align': 'right', 'bg_color': "#C0C0C0"})
        amount = workbook.add_format({'align': 'right'})
        border = workbook.add_format()
        bold.set_border(3)
        amount_bold.set_border(3)
        other_label = workbook.add_format({'font_size': 11, 'align': 'center', 'font_name': 'Times New Roman'})
        other_label_yellow = workbook.add_format({'font_size': 11, 'align': 'center', 'font_name': 'Times New Roman', 'bg_color': 'yellow'})
        styles = {'heading': heading, 'bold': bold, 'border': border, 'other_label': other_label, 'bold_header': bold_header,
                  'heading_red': heading_red, 'amount_bold': amount_bold, 'other_label_yellow': other_label_yellow}
        sheet = workbook.add_worksheet('HR Dashboard Report')
        row = 0
        col = 0
        sheet.set_column(row, col, 25)
        sheet.write(row, col, 'Variables', styles.get('bold'))
        sheet.write(row + 1, col, 'Head Count', styles.get('other_label'))
        sheet.write(row + 2, col, 'Saudi staff-M & F', styles.get('other_label'))
        sheet.write(row + 3, col, 'Saudi Male', styles.get('other_label'))
        sheet.write(row + 4, col, 'Saudi Female', styles.get('other_label'))
        sheet.write(row + 5, col, 'Expat staff', styles.get('other_label'))
        sheet.write(row + 6, col, 'Saudization', styles.get('heading_red'))
        sheet.write(row + 7, col, 'Saudi joiners', styles.get('other_label'))
        sheet.write(row + 8, col, 'Saudi lefters (Resigned)', styles.get('other_label'))
        sheet.write(row + 9, col, 'Saudi lefters (Terminated)', styles.get('other_label'))
        sheet.write(row + 10, col, 'Expat joiners', styles.get('other_label'))
        sheet.write(row + 11, col, 'Expat lefters (Resigned)', styles.get('other_label'))
        sheet.write(row + 12, col, 'Expat lefters (Terminated)', styles.get('other_label'))
        sheet.write(row + 13, col, 'Turnover', styles.get('heading_red'))
        sheet.write(row + 14, col, 'Attrition', styles.get('heading_red'))
        sheet.write(row + 15, col, "Tenure Saudi's", styles.get('other_label_yellow'))
        sheet.write(row + 16, col, "Tenure Expat's", styles.get('other_label_yellow'))
        sheet.write(row + 17, col, "Total Tenure", styles.get('other_label_yellow'))
        sheet.write(row + 18, col, "Avg. Age Saudi's", styles.get('other_label'))
        sheet.write(row + 19, col, "Avg. Age Expat's", styles.get('other_label'))
        sheet.write(row + 20, col, "Avg. age (S&E)", styles.get('other_label'))
        sheet.write(row + 21, col, "Managers", styles.get('other_label'))
        sheet.write(row + 22, col, "Managers to staff", styles.get('heading_red'))
        sheet.write(row + 23, col, "Managers -S", styles.get('other_label'))
        sheet.write(row + 24, col, "Managers -S/M", styles.get('other_label'))
        sheet.write(row + 25, col, "Managers -S/F", styles.get('other_label'))
        sheet.write(row + 26, col, "Managers -E", styles.get('other_label'))
        sheet.write(row + 27, col, "Saudis in managerial level", styles.get('other_label'))
        sheet.write(row + 28, col, "HR members", styles.get('other_label'))
        sheet.write(row + 29, col, "HR to Staff Ratio", styles.get('other_label'))

        for date, value in dates.items():
            col += 1
            if value.get('sa_all_count'):
                head_count = value.get('sa_all_count') + value.get('not_sa_all_count')
                sa_all_count = value.get('sa_all_count')
                sa_male_count = value.get('sa_male_count')
                sa_female_count = value.get('sa_female_count')
                not_sa_all_count = value.get('not_sa_all_count')
                saudi_joiners_count = value.get('saudi_joiners_count')
                saudi_resigned_count = value.get('saudi_resigned_count')
                saudi_terminated_count = value.get('saudi_terminated_count')
                not_saudi_joiners_count = value.get('not_saudi_joiners_count')
                not_saudi_resigned_count = value.get('not_saudi_resigned_count')
                not_saudi_terminated_count = value.get('not_saudi_terminated_count')
                not_saudi_avg_ages = value.get('not_saudi_avg_ages')
                saudi_avg_ages = value.get('saudi_avg_ages')
                sa_all_male_manager_count = value.get('sa_all_male_manager_count')
                sa_all_female_manager_count = value.get('sa_all_female_manager_count')
                not_sa_all_manager = value.get('not_sa_all_manager')
                all_avg_ages = (saudi_avg_ages + not_saudi_avg_ages) /2
                saudi_percent = head_count and (sa_all_count/ head_count) or 0.0
                turn_over = head_count and ((saudi_joiners_count + not_saudi_resigned_count) / head_count) or 0.0
                attrition = sa_all_count and ((saudi_terminated_count + not_saudi_terminated_count) / sa_all_count) or 0.0

                sheet.write(row, col, date, styles.get('bold_header'))
                sheet.write(row + 1, col, head_count)
                sheet.write(row + 2, col, sa_all_count)
                sheet.write(row + 3, col, sa_male_count)
                sheet.write(row + 4, col, sa_female_count)
                sheet.write(row + 5, col, not_sa_all_count)
                sheet.write(row + 6, col, "{:.2%}".format(saudi_percent))
                sheet.write(row + 7, col, saudi_resigned_count)
                sheet.write(row + 8, col, saudi_joiners_count)
                sheet.write(row + 9, col, saudi_terminated_count)
                sheet.write(row + 10, col, not_saudi_joiners_count)
                sheet.write(row + 11, col, not_saudi_resigned_count)
                sheet.write(row + 12, col, not_saudi_terminated_count)
                sheet.write(row + 13, col, "{:.2%}".format(turn_over))
                sheet.write(row + 14, col, "{:.2%}".format(attrition))
                sheet.write(row + 15, col, value.get('tenure_saudi'))
                sheet.write(row + 16, col, value.get('tenure_not_saudi'))
                sheet.write(row + 17, col, value.get('tenure_saudi') + value.get('tenure_not_saudi'))

                sheet.write(row + 18, col, saudi_avg_ages)
                sheet.write(row + 19, col, not_saudi_avg_ages)
                sheet.write(row + 20, col, all_avg_ages)

                sheet.write(row + 21, col, sa_all_male_manager_count + not_sa_all_manager)
                sheet.write(row + 22, col, "{:.2%}".format(head_count and (sa_all_male_manager_count + sa_all_female_manager_count)/ head_count) or 0.0)
                sheet.write(row + 23, col, sa_all_male_manager_count + sa_all_female_manager_count)
                sheet.write(row + 24, col, sa_all_male_manager_count)
                sheet.write(row + 25, col, sa_all_female_manager_count)
                sheet.write(row + 26, col, not_sa_all_manager)
                sheet.write(row + 27, col, (sa_all_male_manager_count + not_sa_all_manager) and "{:.2%}".format((sa_all_male_manager_count + sa_all_female_manager_count) / (sa_all_male_manager_count + not_sa_all_manager) or 0.0))
                sheet.write(row + 28, col, value.get('hr_employee_count'))
                sheet.write(row + 29, col, "{:.2%}".format(head_count and (value.get('hr_employee_count') / head_count) or 0.0))



        workbook.close()
        file_save = base64.encodestring(fp.getvalue())
        fp.close()
        attachment_id = self.env['ir.attachment'].create({'name': filename,
                                                          'datas': file_save,
                                                          'store_fname': filename,
                                                          'res_model': 'vacancy.report.wiz',
                                                          'res_id': self.id,
                                                          'type': 'binary',
                                                          })
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/%s?download=true' % (attachment_id.id),
            'target': 'self',
            'nodestroy': False,
        }