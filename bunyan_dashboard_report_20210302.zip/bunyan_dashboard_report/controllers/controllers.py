# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanDashboardReport(http.Controller):
#     @http.route('/bunyan_dashboard_report/bunyan_dashboard_report/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_dashboard_report/bunyan_dashboard_report/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_dashboard_report.listing', {
#             'root': '/bunyan_dashboard_report/bunyan_dashboard_report',
#             'objects': http.request.env['bunyan_dashboard_report.bunyan_dashboard_report'].search([]),
#         })

#     @http.route('/bunyan_dashboard_report/bunyan_dashboard_report/objects/<model("bunyan_dashboard_report.bunyan_dashboard_report"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_dashboard_report.object', {
#             'object': obj
#         })
