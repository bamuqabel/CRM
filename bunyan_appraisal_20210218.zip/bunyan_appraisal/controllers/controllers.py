# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanAppraisal(http.Controller):
#     @http.route('/bunyan_appraisal/bunyan_appraisal/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_appraisal/bunyan_appraisal/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_appraisal.listing', {
#             'root': '/bunyan_appraisal/bunyan_appraisal',
#             'objects': http.request.env['bunyan_appraisal.bunyan_appraisal'].search([]),
#         })

#     @http.route('/bunyan_appraisal/bunyan_appraisal/objects/<model("bunyan_appraisal.bunyan_appraisal"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_appraisal.object', {
#             'object': obj
#         })
