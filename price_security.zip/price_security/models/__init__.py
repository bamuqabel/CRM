##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import account_invoice_line
from . import account_payment_term
from . import discount_restriction
from . import product_pricelist
from . import product_template
from . import res_users
from . import sale_order
from . import sale_order_line
from . import res_partner
