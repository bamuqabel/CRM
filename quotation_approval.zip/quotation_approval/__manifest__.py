# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Quotations Approval',
    'version': '13.0',
    'category': 'Sales',
    'author': 'ILS',
    'sequence': 15,
    'summary': 'Quotations Approval',
    'description': """
Manage sales quotations Approval.
    """,
    'author': 'ILS',
    'website': 'https://www.ils.com.sa',
    'license': 'LGPL-3',
    'support': 'sales@ils.com.sa',
    'depends': ['sale'],
    'data': [
        'views/sale_view.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'images': ['static/description/banner.png'],
}
