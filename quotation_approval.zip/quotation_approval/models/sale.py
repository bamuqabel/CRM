# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = "sale.order"
     
#   @api.multi
    def action_sent(self):
        self.write({'state': 'sent'})


 

