# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = "sale.order"

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('waiting_for_approval', 'Waiting For Approval'),
    	('approved', 'Approved'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')
    
#   @api.multi
    def action_waiting_for_approval(self):
        self.write({'state': 'waiting_for_approval'})

#   @api.multi
    def action_approved(self):
        self.write({'state': 'approved'})
 

