Res Documents
=============

Configuration
-------------
Configure Document Type