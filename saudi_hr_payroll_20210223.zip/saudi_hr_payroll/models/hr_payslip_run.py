# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, models, fields, _
from odoo.exceptions import UserError


class HrPayslipRun(models.Model):
    _inherit = "hr.payslip.run"

    # def confirm_payslip(self):
    #     for line in self.slip_ids:
    #         if line.state == 'draft':
    #             line.action_payslip_done()

    def generate_bank_details_report(self):
        for rec in self:
            slip_ids = rec.slip_ids.search([('state', '=', 'draft'), ('id', 'in', rec.slip_ids.ids)])
            if slip_ids:
                raise UserError(_("Please Confirm Employee Payslips"))
            else:
                return {
                   'type': 'ir.actions.act_window',
                   'res_model': 'bank.details.report',
                   'view_mode': 'form',
                   'view_type': 'form',
                   'view_id': self.env.ref('saudi_hr_payroll.bank_details_reports_print_view').id,
                   'target': 'new',
                   'context': self.env.context
                }