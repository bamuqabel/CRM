# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from dateutil.relativedelta import relativedelta


class ContractRenewals(models.Model):
    _name = 'contract.renew'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Contract Renewals'

    name = fields.Char(string="Name", required=True, default=lambda s: s.env['ir.sequence'].next_by_code('contract.renew.sequence'))
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=True, related='expired_contract_id.employee_id')
    state = fields.Selection(string="State", selection=[('new', 'New'), ('hr_approval', 'HR Approved'), ('approved', 'Approved'), ('new_contract_created', 'New Contract Created'), ('refused', 'Refuse')], required=False, default='new')
    # Expired Contract Details
    expired_contract_id = fields.Many2one(comodel_name="hr.contract", string="Expired Contract", required=True, )
    expired_contract_date_start = fields.Date(string="Start Date", related='expired_contract_id.date_start')
    expired_contract_date_end = fields.Date(string="End Date", related='expired_contract_id.date_end')
    expired_structure_type_id = fields.Many2one(comodel_name="hr.payroll.structure.type", related='expired_contract_id.structure_type_id', )
    expired_job_id = fields.Many2one(comodel_name="hr.job", related='expired_contract_id.job_id', )
    # New Contract Details
    new_contract_id = fields.Many2one(comodel_name="hr.contract", string="New Contract", required=False, )
    new_contract_date_start = fields.Date(string="Start Date", )
    new_contract_date_end = fields.Date(string="End Date", )
    new_structure_type_id = fields.Many2one(comodel_name="hr.payroll.structure.type", string="Salary Structure Type", default=lambda s: s.expired_contract_id.structure_type_id.id)
    new_job_id = fields.Many2one(comodel_name="hr.job", string="Job Position", default=lambda s: s.expired_contract_id.job_id.id, )
    ceo_signature = fields.Binary(string="CEO Signature", )
    is_employee_accept = fields.Boolean(string="Employee Accept",  )
    employee_signature = fields.Binary(string="Employee Signature", copy=False)

    def create_new_contract(self):
        for rec in self:
            if rec.expired_contract_id:
                rec.new_contract_id = rec.expired_contract_id.copy({
                    "date_start": rec.new_contract_date_start or rec.expired_contract_id.date_start,
                    "date_end": rec.new_contract_date_end, "job_id": rec.new_job_id.id or rec.expired_job_id.id or False,
                    "structure_type_id": rec.new_structure_type_id.id or rec.expired_structure_type_id.id or False,
                    "name": fields.Date.today().strftime('%Y') + ' - ' + rec.expired_contract_id.employee_id.code,
                    })
                rec.new_contract_id.ceo_signature = rec.ceo_signature or False
                if rec.new_contract_id:
                    rec.state = 'new_contract_created'
                    template_id = self.env.ref('bunyan_renew_contract.mail_template_renew_contract_employee')
                    email_to = rec.employee_id.work_email or ''
                    if template_id:
                        email_values = {'email_to': email_to}
                        template_id.send_mail(self.id, force_send=True, raise_exception=False,
                                              email_values=email_values)

    def approve_contract_renew(self):
        for rec in self:
            if rec.ceo_signature:
                rec.state = 'approved'
            else:
                raise UserError(_('Please, Sign the document!'))

    def hr_approve_contract_renew(self):
        for rec in self:
            rec.state = 'hr_approval'

    def refuse_contract_renew(self):
        for rec in self:
            rec.state = 'refused'

    def accept_employee_contract(self):
        hr_contract_managers = []
        for user in self.env['res.users'].search([]):
            if user.has_group('hr_contract.group_hr_contract_manager'):
                hr_contract_managers.append(user.login)
        for rec in self:
            if rec.employee_signature and rec.new_contract_id.state != 'open' and not rec.new_contract_id.employee_signature:
                rec.new_contract_id.state = 'open'
                rec.new_contract_id.employee_signature = rec.employee_signature
                template_id = self.env.ref('bunyan_renew_contract.mail_template_renew_contract_hr_manager')
                email_to = ','.join(hr_contract_managers)
                if template_id:
                    email_values = {'email_to': email_to}
                    template_id.send_mail(self.id, force_send=True, raise_exception=False,
                                          email_values=email_values)


class HREmployee(models.Model):
    _name = 'hr.employee'
    _inherit = 'hr.employee'

    passport_city = fields.Char(string="Passport Issued City", required=False, )
    passport_city_ar = fields.Char(string="Passport Issued City (Arabic)", required=False, )
    passport_issue_date = fields.Date(string="Passport Issue Date", required=False, default=fields.Date.context_today)


class HRContract(models.Model):
    _name = 'hr.contract'
    _inherit = 'hr.contract'

    hijri_start_date = fields.Char(string="Start Date (Hijri)", required=False, )
    hijri_end_date = fields.Char(string="End Date (Hijri)", required=False, )
    # Signature
    ceo_signature = fields.Binary(string="CEO Signature", )
    employee_signature = fields.Binary(string="Employee Signature", copy=False)
    is_approved_ceo = fields.Boolean(string="CEO Approved", default=False, copy=False)

    def approve_contract_ceo(self):
        hr_contract_hr = []
        for user in self.env['res.users'].search([]):
            if user.has_group('hr_contract.group_hr_contract_manager'):
                hr_contract_hr.append(user.login)
        for rec in self:
            if not rec.ceo_signature:
                raise UserError("CEO Signature is required for the approval")
            rec.is_approved_ceo = True
            template_id = self.env.ref('bunyan_renew_contract.mail_template_new_contract_hr_manager')
            if rec.employee_id and rec.employee_id.work_email:
                hr_contract_hr.append(rec.employee_id.work_email)
            email_to = ','.join(hr_contract_hr)
            if template_id:
                email_values = {'email_to': email_to}
                template_id.send_mail(self.id, force_send=True, raise_exception=False,
                                      email_values=email_values)

    def accept_employee_contract(self):
        hr_contract_managers = []
        for user in self.env['res.users'].search([]):
            if user.has_group('hr_contract.group_hr_contract_manager'):
                hr_contract_managers.append(user.login)
        for rec in self:
            if rec.employee_signature and rec.state != 'open':
                rec.state = 'open'
                template_id = self.env.ref('bunyan_renew_contract.mail_template_new_contract_ee_manager')
                email_to = ','.join(hr_contract_managers)
                if template_id:
                    email_values = {'email_to': email_to}
                    template_id.send_mail(self.id, force_send=True, raise_exception=False,
                                          email_values=email_values)

    @api.model
    def create(self, values):
        res = super(HRContract, self).create(values)
        hr_contract_ceo = []
        for user in self.env['res.users'].search([]):
            if user.has_group('bunyan_approval_levels.group_ceo'):
                hr_contract_ceo.append(user.login)

        template_id = self.env.ref('bunyan_renew_contract.mail_template_new_contract_ceo')
        email_to = ','.join(hr_contract_ceo)
        if template_id:
            email_values = {'email_to': email_to}
            template_id.send_mail(res.id, force_send=True, raise_exception=False,
                                  email_values=email_values)
        return res


class Partner(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    street_ar = fields.Char(string="Street (Arabic)", required=False, )
    street2_ar = fields.Char(string="Street2 (Arabic)", required=False, )
    city_ar = fields.Char(string="City (Arabic)", required=False, )
