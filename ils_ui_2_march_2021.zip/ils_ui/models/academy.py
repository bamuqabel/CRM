# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError

class ilsAcademy(models.Model):
    _name = 'ils.academy'
    _description = 'Academy'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    arabic_name = fields.Char(string='Arabic Name', required=True)
    country_id = fields.Many2one(comodel_name='res.country', string='Academy Country')
    resion_id = fields.Many2one(comodel_name='academy.resion', string='Academy Region', domain="([('country_id', '=', country_id)])")
    city_id = fields.Many2one(comodel_name='academy.city', string='Academy City', domain="([('resion_id', '=', resion_id)])") 
    phone = fields.Char(string='Academy Phone Number')
    email =  fields.Char(string='Academy Email')
    responsible = fields.Many2one(comodel_name='res.partner', string='Academy Responsible')
    batches = fields.One2many(comodel_name='ils.batch', inverse_name='academy_id', string='Batches')
    timeslots = fields.One2many(comodel_name='ils.academy.timeslot', inverse_name='academy_id', string='Break Timeslots')
    batch_start_time = fields.Float(string='Start Time')
    batch_end_time = fields.Float(string='End Time')
    day_off_list = fields.One2many(comodel_name='ils.academy.dayoff', inverse_name='academy_id', string='Day Off List')
    active = fields.Boolean('Active', default=False)


class AcademyCity(models.Model):
    _name = 'academy.city'
    _description = 'Academy City'

    name = fields.Char(string='Name')
    resion_id = fields.Many2one(comodel_name='academy.resion', string='Resion')


class AcademyResion(models.Model):
    _name = 'academy.resion'
    _description = 'Academy Resion'

    name = fields.Char(string='Name')
    country_id = fields.Many2one(comodel_name='res.country', string='Country')


class ilsAcademyTimeslot(models.Model):
    _name = 'ils.academy.timeslot'
    _description = 'Academy Timeslot'
    _order = 'academy_id, sequence, id'

    name = fields.Char(string="Name", required="1")
    start_time = fields.Float(string="Start Time", required="1")
    start_time_ampm = fields.Selection([
            ('am', 'AM'),
            ('pm', 'PM'),
        ], string="Start time AM/PM", required="1")
    end_time = fields.Float(string="End Time", required="1")
    end_time_ampm = fields.Selection([
            ('am', 'AM'),
            ('pm', 'PM'),
        ], string="End time AM/PM", required="1")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    sequence = fields.Integer(string='Sequence', default=10)

    def get_block_time_description(self, timeslot_id=False):
        descripton = False
        if timeslot_id:
            descripton = self.browse(timeslot_id).name
        return descripton


class ilsAcademyDayOff(models.Model):
    _name = 'ils.academy.dayoff'
    _description = 'Academy Day Off'
    _order = 'academy_id, sequence, id'

    name = fields.Char(string="Name", required="1")
    day_off_date = fields.Date(string="Off Date")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    sequence = fields.Integer(string='Sequence', default=10)