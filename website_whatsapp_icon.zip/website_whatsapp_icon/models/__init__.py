# -*- coding: utf-8 -*-

from . import inherit_res_config_settings
