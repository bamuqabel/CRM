# -*- coding: utf-8 -*-
import simplejson

from odoo import models, fields, api
from dateutil.relativedelta import relativedelta
from lxml import etree
import json


class AppraisalType(models.Model):
    _name = 'appraisal.type'
    _description = 'Appraisal Type'

    name = fields.Char(string="Name", required=True, )
    criteria_ids = fields.One2many(comodel_name="appraisal.criteria", inverse_name="appraisal_type_id", string="Criteria", required=False, )
    type = fields.Selection(string="Type", selection=[('annual', 'Annual'), ('probation', 'Probation'), ], )
    job_ids = fields.Many2many(comodel_name="hr.job", relation="appraisal_type_hr_job_rel", column1="appraisal_type_id", column2="job_id", string="Applies On", )


class AppraisalCriteria(models.Model):
    _name = 'appraisal.criteria'
    _description = 'Appraisal Criteria'
    
    appraisal_type_id = fields.Many2one(comodel_name="appraisal.type", string="Appraisal Type", required=True, )
    name = fields.Char(string="Criteria", required=False, )
    expected_score = fields.Selection(string="Expected Rate", selection=[('1', 'Unsatisfactory'),
                                                                         ('2', 'Need Improvement'),
                                                                         ('3', 'Meet Expectation'),
                                                                         ('4', 'Exceed Expectation')], default='1', )
    
    
class HRAppraisal(models.Model):
    _name = 'hr.appraisal'
    _inherit = 'hr.appraisal'

    appraisal_type_id = fields.Many2one(comodel_name="appraisal.type", string="Appraisal Type", required=False, )
    appraisal_type = fields.Selection(related='appraisal_type_id.type')
    appraisal_criteria_ids = fields.One2many(comodel_name="employee.appraisal.criteria", inverse_name="appraisal_id",
                                             string="Appraisal", required=False, )
    strengths_technical = fields.Text(string="Technical", required=False, )
    strengths_behavioral = fields.Text(string="Behavioral", required=False, )
    improve_technical = fields.Text(string="Technical", required=False, )
    improve_behavioral = fields.Text(string="Behavioral", required=False, )
    individual_plan = fields.Selection(string="Options", selection=[('enroll', 'Enroll the employee in Mentroship program for six months'),
                                                                    ('success_plan', 'Employee is a part of Succession plan'),
                                                                    ('promotion', 'Promotion'),
                                                                    ('salary_increase', 'Salary Increase'),
                                                                    ('training_course', 'Enroll in training course'),
                                                                    ], default='enroll', )
    individual_plan_justification = fields.Text(string="Justification", required=False, )
    hrm_signature = fields.Binary(string="HRM Signature", )
    employee_signature = fields.Binary(string="Employee Signature", )
    line_manager_signature = fields.Binary(string="Line Manager Signature", )
    employee_job_id = fields.Many2one(related='employee_id.job_id')
    state = fields.Selection(string="State", selection_add=[('direct_manager_approve', 'Direct Manager'), ('done', )])
    hide_plan_options = fields.Boolean(string="Hide Plan Options", )
    hide_plan_options_compute = fields.Boolean(string="Hide Plan Options (Compute)", compute="_compute_hide_plan_options_compute")

    @api.depends('hide_plan_options')
    def _compute_hide_plan_options_compute(self):
        for rec in self:
            rec.hide_plan_options_compute = rec.hide_plan_options and rec.employee_id.user_id.id == rec.env.user.id

    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        """
        Overrides orm field_view_get.
        @return: Dictionary of Fields, arch and toolbar.
        """
        res = super(HRAppraisal, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu)
        if view_type != 'form' or not self._context.get('params', False):
            return res

        print(type(self._context.get('params').get('id')))
        if self._context.get('params').get('id') and self.browse(self._context.get('params').get('id')).state == 'direct_manager_approve':
            doc = etree.XML(res['arch'])
            for node in doc.xpath('//field'):
                if not node.xpath("//field[@name='actual_score']"):
                    node.set('readonly', '1')
                    node_values = node.get('modifiers')
                    modifiers = json.loads(node_values)
                    modifiers["readonly"] = True
                    node.set('modifiers', simplejson.dumps(modifiers))
            res['arch'] = etree.tostring(doc)
        return res

    @api.onchange('individual_plan')
    def _onchange_individual_plan(self):
        for rec in self:
            rec.individual_plan_justification = ''

    @api.onchange('appraisal_type_id')
    def _onchange_appraisal_type_id(self):
        for rec in self:
            if rec.appraisal_criteria_ids:
                rec.appraisal_criteria_ids = [(5, 0, 0)]
            if rec.appraisal_type_id:
                app_type_vals = []
                for criteria in rec.appraisal_type_id.criteria_ids:
                    app_type_vals.append((0, 0, {'name': criteria.name, 'expected_score': criteria.expected_score}))
                rec.appraisal_criteria_ids = app_type_vals

    @api.model
    def create(self, values):
        res = super(HRAppraisal, self).create(values)
        res._onchange_employee_id()
        res.action_mail_send_notify()
        return res

    def set_direct_manager_approve(self):
        self.state = 'direct_manager_approve'

    def button_send_appraisal(self):
        res = super(HRAppraisal, self).button_send_appraisal()
        self.action_mail_send_notify()
        return res

    def action_mail_send_notify(self, position=None):
        """
        This function compose an email by default
        """
        self.ensure_one()
        # ir_model_data = self.env['ir.model.data']
        res_users = self.env['res.users'].search([])
        template_id = False
        email_to = ''
        try:
            if self.state == '':
                pass
            elif self.state == 'new':
                template_id = self.env.ref('bunyan_appraisal.mail_template_appraisal_notify_hr_manager')
                for user in res_users:
                    if user.has_group('hr_appraisal.group_hr_appraisal_manager'):
                        if user.email:
                            email_to = email_to and email_to + ',' + user.email or email_to + user.email
            elif self.state == 'pending':
                template_id = self.env.ref('bunyan_appraisal.mail_template_appraisal_notify_direct_manager')
                for manager in self.manager_ids:
                    if manager.work_email:
                        email_to = email_to and email_to + ',' + manager.work_email or email_to + manager.work_email
        except ValueError:
            template_id = False
        if template_id:
            email_values = {'email_to': email_to}
            template_id.send_mail(self.id, force_send=True, raise_exception=False, email_values=email_values)
        return True


class EmployeeAppraisalCriteria(models.Model):
    _name = 'employee.appraisal.criteria'
    _description = 'Employee Appraisal Criteria'

    name = fields.Char(string="Criteria", required=True, )
    appraisal_id = fields.Many2one(comodel_name="hr.appraisal", string="Employee Appraisal Criteria", required=False, )
    expected_score = fields.Selection(string="Expected Rate", selection=[('1', 'Unsatisfactory'),
                                                                          ('2', 'Need Improvement'),
                                                                          ('3', 'Meet Expectation'),
                                                                          ('4', 'Exceed Expectation')], default='1', )
    actual_score = fields.Selection(string="Actual Rate", selection=[('1', 'Unsatisfactory'), ('2', 'Need Improvement'),
                                                                        ('3', 'Meet Expectation'),
                                                                        ('4', 'Exceed Expectation')], default='1', )
    result = fields.Char(string="Result", compute='_compute_result')

    @api.depends('expected_score', 'actual_score')
    def _compute_result(self):
        for rec in self:
            if rec.expected_score == rec.actual_score:
                rec.result = 'Best Result'
            elif rec.expected_score > rec.actual_score:
                rec.result = 'Need PIP'
            elif rec.expected_score < rec.actual_score:
                rec.result = 'Exceed the required performance'
            else:
                rec.result = ''


class HREmployee(models.Model):
    _name = 'hr.employee'
    _inherit = 'hr.employee'

    next_appraisal_date = fields.Date(string="Next Appraisal Date", compute="_compute_next_appraisal_date")

    @api.depends('appraisal_date_related')
    def _compute_next_appraisal_date(self):
        for rec in self:
            rec.next_appraisal_date = fields.Date.to_date(rec.appraisal_date_related) + relativedelta(years=1)

    @api.model
    def run_create_appraisal(self):
        appraisal_env = self.env['hr.appraisal']
        today_date = fields.Date.today()
        for rec in self.search([]):
            if rec.next_appraisal_date == today_date:
                created_appraisal = appraisal_env.create({'employee_id': rec.id})
                if created_appraisal:
                    rec.appraisal_date_related = today_date
                    created_appraisal.action_mail_send_notify()
