# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class FlightBooking(models.Model):
    _name = 'flight.booking'
    _inherit = 'flight.booking'

    state = fields.Selection(selection_add=[('waiting_manager_approval', 'Waiting Manager Approval'), ('direct_manager', 'Direct Manager'), ('confirm',), ('ceo', 'CEO'), ('validate', )], string='Status', default='draft')
    is_direct_manager = fields.Boolean(string="Is Direct Manager", compute='_compute_is_direct_manager')
    has_direct_manager = fields.Boolean(string="Has Direct Manager", compute='_compute_is_direct_manager')

    @api.depends('employee_id')
    def _compute_is_direct_manager(self):
        """
        Check if the employee_id has a direct manager:
        - If yes, the direct manager has a user or not
        - If no, move to the next level of approval
        :return:
        """
        for rec in self:
            rec.is_direct_manager = False
            rec.has_direct_manager = False
            if rec.employee_id:
                if rec.employee_id.parent_id and rec.employee_id.parent_id.user_id:
                    rec.has_direct_manager = True
                    if rec.employee_id.parent_id.user_id == self.env.user:
                        rec.is_direct_manager = True

    def flight_booking_direct_manager(self):
        """
            Change state to confirm and send message to employee for flight confirmation.
            :return: True
        """
        self.ensure_one()
        if self.ticket_type == 'group' or self.ticket_type == 'family':
            if not self.group_member_ids:
                raise UserError(_("Please add Group Member Details first !"))
        self._add_followers()
        self.state = 'confirm'
        self.message_post(message_type="email", subtype='mail.mt_comment', body=_('Booking Confirmed By Direct Manager: %s.' % self.employee_id.parent_id.display_name))

    def flight_booking_confirm(self):
        """
            Change state to confirm and send message to employee for flight confirmation.
            :return: True
        """
        self.ensure_one()
        if self.ticket_type == 'group' or self.ticket_type == 'family':
            if not self.group_member_ids:
                raise UserError(_("Please add Group Member Details first !"))
        self._add_followers()
        self.state = 'confirm'
        self.message_post(message_type="email", subtype='mail.mt_comment', body=_('Booking Confirmed.'))

    def flight_booking_request_manager_approval(self):
        """
            Change state to Waiting Manager Approval
            :return: True
        """
        self.ensure_one()
        if self.ticket_type == 'group' or self.ticket_type == 'family':
            if not self.group_member_ids:
                raise UserError(_("Please add Group Member Details first !"))
        self._add_followers()
        self.state = 'waiting_manager_approval'
        self.message_post(message_type="email", subtype='mail.mt_comment', body=_('Manager Approval Requested.'))
