# -*- coding: utf-8 -*-

import json
import requests
from odoo.tools import ustr
from odoo.exceptions import UserError
from odoo import models, fields, api, _
from requests.auth import HTTPBasicAuth
import datetime


MAP_KEY_WITH_MODEL = {
    'academy': 'ils.academy',
    'batch': 'ils.batch',
    'education': 'ils.education',
    'employer': 'ils.employer',
    'employment': 'ils.employment',
    'enrollment': 'ils.enrollment',
    'modules': 'ils.modules',
    'qualification': 'ils.qualification',
    'room': 'ils.room',
    'semester': 'ils.semester',
    'school': 'ils.school',
    'teacher': 'ils.teacher',
}

class IlsFields(models.Model):
    _name = 'ils.fields'
    _description = 'ILS Fields'

    api_call_id = fields.Many2one('ils.api.configuration', string="Field Id")
    model_field_name = fields.Many2one('ir.model.fields', string="Model Field")
    custom_field_name = fields.Char(string="Custom Field Name")


class ApiConfiguration(models.Model):
    _name = 'ils.api.configuration'
    _description = 'Api Configuration'
    _order = 'sequence, name, id'

    name = fields.Char(String="API Name")
    url = fields.Char(String="API URL")
    sequence = fields.Integer(index=True, help="Gives the sequence order when displaying a list of bank statement lines.", default=1)
    model_id = fields.Many2one('ir.model', String="API Model", domain=[
                               '|', '|', '|', ('model', '=like', 'ils%'), ('model', '=like', 'res.partner'), ('model', '=like', 'res.users'), ('model', '=like', 'product.template')])
    fields_ids = fields.One2many('ils.fields', 'api_call_id', string="Field Names")
    lms = fields.Selection(string='LMS', required=True, selection=[('bunyan','Bunyan LMS'), ('ehl','Vet By EHL'), ('upm','UPM')])
    
    def update_api_call_data(self):
        cron_id = self.env.context.get('cron_id', False)
        if cron_id:
            cron = self.env['ir.cron'].browse(cron_id)
            effected_model_id = cron.effected_model
            if effected_model_id.model in ['res.partner', 'ils.enrollment']:
                token = self.env['ils.api.token.configuration'].search([], limit=1).auth_token
                effected_rec_id = cron.rel_api_config_record
                headers = {'accept': '*/*',
                           'content-type': 'application/json',
                           'Authorization': token}
                if effected_model_id.model == 'product.template':
                    model_records = self.env[effected_model_id.model].search([('is_program', '=', True)])
                elif effected_model_id.model == 'res.partner':
                    model_records = self.env[effected_model_id.model].search([('contact_type', '=', 'student')])
                else:
                    model_records = self.env[effected_model_id.model].search([])
                mapping_fields = {field.custom_field_name:field.model_field_name.name for field in effected_rec_id.fields_ids}
                counter = 1
                for rec in model_records:
                    if not rec.api_ref_code:
                        url = False
                        data_dict = {}
                        if effected_model_id.model == 'ils.enrollment' and effected_rec_id.lms and effected_rec_id.lms == rec.program_id.lms:
                            data_dict['IsActive'] = True if rec.state != 'inactive' else False
                            data_dict['DepartmentId'] = rec.program_id.api_department_ref
                            data_dict['CourseId'] = rec.program_id.api_course_ref
                            if rec.student_id and rec.student_id and rec.student_id.api_ref_code:
                                data_dict['UserId'] = rec.student_id.api_ref_code
                            if not rec.student_id.api_ref_code:
                                continue
                            url = effected_rec_id.url.replace('{user_id}', rec.student_id.api_ref_code)
                        elif effected_model_id.model == 'res.partner':
                            ehl_program_id = self.env['ils.enrollment'].search([('id', 'in', rec.student_enrollment.ids), ('program_id.lms', '=', 'ehl')], limit=1).program_id
                            if ehl_program_id:
                                url = effected_rec_id.url
                                data_dict['DepartmentId'] = ehl_program_id.api_department_ref
                                data_dict['CourseId'] = ehl_program_id.api_course_ref
                        for field_data in mapping_fields:
                            ir_model_field=self.env['ir.model.fields'].search([('model','=',effected_model_id.model),('name','=',mapping_fields.get(field_data))])
                            if field_data == 'Gender':
                                if mapping_fields.get(field_data) and mapping_fields.get(field_data) == 'gender':
                                    if rec.gender:
                                        if rec.gender == 'male':
                                            data_dict['Gender'] = 1   
                                        elif rec.gender == 'female':
                                            data_dict['Gender'] = 2
                                    else:
                                        data_dict['Gender'] = 0
                            elif ir_model_field.ttype == 'many2one':
                                data_dict.update({field_data:str(getattr(rec, mapping_fields.get(field_data)).id)})
                            elif ir_model_field.ttype == 'float':
                                data_dict.update({field_data:float(getattr(rec, mapping_fields.get(field_data)))})
                            else:
                                data_dict.update({field_data:str(getattr(rec, mapping_fields.get(field_data)))})
                            if getattr(rec, mapping_fields.get(field_data)) == False:
                                data_dict.update({field_data: False})
                        if url and data_dict.get('DepartmentId'):
                            if effected_model_id.model == 'res.partner':
                                if data_dict['FirstName'] and data_dict['LastName'] and data_dict['Username'] and data_dict['EmailAddress']:
                                    data = json.dumps(data_dict)
                                    req = requests.post(
                                        url, headers=headers, data=data)
                                    if req.content:
                                        content = json.loads(req.content) 
                                        response_id = False
                                        if content.get('Id'):
                                            response_id = content.get('Id')
                                        elif content.get('EnrollmentId'):
                                            response_id = content.get('EnrollmentId')
                                        if response_id:
                                            rec.api_ref_code = response_id
                            else:
                                data = json.dumps(data_dict)
                                req = requests.post(
                                    url, headers=headers, data=data)
                                if req.content:
                                    content = json.loads(req.content) 
                                    response_id = False
                                    if content.get('Id'):
                                        response_id = content.get('Id')
                                    elif content.get('EnrollmentId'):
                                        response_id = content.get('EnrollmentId')
                                        rec.state = 'sent_to_lms'
                                    if response_id:
                                        rec.api_ref_code = response_id
                            counter += 1
                            if counter == 1:
                                break
        return True

    def action_create_schedulers(self):
        dependent_api = self.search([('sequence', '=', self.sequence - 1)], limit=1)
        ir_cron_obj = self.env['ir.cron']
        model_name = self.model_id.name
        self_model_name = self.env['ir.model'].search(
            [('model', '=like', 'ils.api.configuration')])
        dependent_cron = ir_cron_obj.search(
            [('is_dynamic_crone', '=', True), ('effected_model', '=', dependent_api.model_id.id)])
        if not dependent_cron and self.sequence > 1:
            raise UserError(_('Please schedule %s API first!' % dependent_api.name))
        nextcall = False
        if dependent_cron:
            nextcall = dependent_cron.nextcall + datetime.timedelta(minutes = 10)
        else:
            nextcall = datetime.datetime.now() + datetime.timedelta(minutes = 10)
        ir_crons = ir_cron_obj.search(
            [('is_dynamic_crone', '=', True), ('name', '=', self.name + ' API Data Sync')])
        if ir_crons:
            raise UserError(_("Same model crone job is already exist."))
        else:
            ir_cron_obj.create({
                'name': self.name + ' API Data Sync',
                'model_id': self_model_name.id,
                'user_id': 1,
                'interval_number': 10,
                'interval_type': 'minutes',
                'active': True,
                'code': 'model.update_api_call_data()',
                'numbercall': -1,
                'doall': False,
                'state': 'code',
                'nextcall': nextcall if nextcall else datetime.datetime.now(),
                'is_dynamic_crone': True,
                'effected_model': self.model_id.id,
                'rel_api_config_record': self.id})

    def test_api_connection(self):
        token = False
        if 'auth' in self.url:
            try:
                header = {'content-type': 'application/json'}
                response = requests.request("POST",
                                            str(self.url),
                                            auth=HTTPBasicAuth(
                                                self.username, self.password),
                                            headers=header, verify=False)
                token = response.json()["Token"] or False
            except Exception as e:
                raise UserError(
                    _("API Connection Test Failed! Here is the error:\n%s") % ustr(e))
        try:
            if token:
                headers = {'content-type': 'application/json',
                           'x-auth-token': token}
            else:
                headers = {'content-type': 'application/json'}
            response = requests.get(self.url, headers=headers, verify=False)
            if response.status_code != 200:
                raise UserError(_("Did not received proper response."))
        except Exception as e:
            raise UserError(
                _("API Connection Test Failed! Here is the error:\n%s") % ustr(e))

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("API Connection Test Succeeded!"),
                'message': _("Everything seems properly set up!"),
                'sticky': False,
            }
        }


class IrCron(models.Model):
    _inherit = "ir.cron"

    is_dynamic_crone = fields.Boolean('Is Dynamic Crone?', default=False)
    effected_model = fields.Many2one(
        'ir.model', String="Effected Model", readonly=True)
    rel_api_config_record = fields.Many2one(
        'ils.api.configuration', String="Related API Configuration")

    @api.model
    def _callback(self, cron_name, server_action_id, job_id):
        """ to handle cron thread executionecuted by Odoo."""
        self = self.with_context(cron_id=job_id)
        return super(IrCron, self)._callback(cron_name, server_action_id, job_id)

    # @api.multi
    def method_direct_trigger(self):
        """ to handle manual execution using the button."""
        for rec in self:
            rec = rec.with_context(cron_id=rec.id)
            super(IrCron, rec).method_direct_trigger()
        return True
