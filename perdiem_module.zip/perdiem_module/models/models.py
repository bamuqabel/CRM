# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime

class PerDiem(models.Model):
    _name = 'bunyan.perdiem'
    _rec_name = 'name'
    _description = 'PerDiem'

    name = fields.Char(string="Name", required=True, )
    perdiem_cost = fields.Integer(string="Perdiem Cost", required=False, )


class FlightBooking(models.Model):
    _name = 'flight.booking'
    _inherit = 'flight.booking'

    perdiem_id = fields.Many2one(comodel_name="bunyan.perdiem", string="Per Diem Type", required=False, )
    perdiem_days = fields.Integer(string="Perdiem Days", required=False, )
    payment_mode = fields.Selection(default='company_account')

    def generate_perdiem_expense(self):
        self.ensure_one()
        product_id = self.env.ref('perdiem_module.perdiem_product')
        name = 'Perdiem - ' + self.name_get()[0][1]
        # total_amount = self.perdiem_days * self.perdiem_id.perdiem_cost
        employee = self.employee_id.id
        contract = self.env['hr.contract'].search([('employee_id', '=', employee), ('state', '=', 'open')])
        expense_data = ({
            'employee_id': employee,
            'product_id': product_id.id,
            'product_uom_id': product_id.uom_id.id,
            'date': datetime.today().date(),
            'quantity': self.perdiem_days,
            'unit_amount': self.perdiem_id.perdiem_cost,
            'description': self.description,
            'name': name,
            'analytic_account_id': contract and contract[0].analytic_account_id.id or False,
            'analytic_tag_ids': contract and [(6, 0, contract[0].analytic_tag_ids.ids)] or False,
        })
        expense_id = self.env['hr.expense'].create(expense_data)
        self.expense_ids = [(4, expense_id.id)]
