# -*- coding: utf-8 -*-
# from odoo import http


# class PerdiemModule(http.Controller):
#     @http.route('/perdiem_module/perdiem_module/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/perdiem_module/perdiem_module/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('perdiem_module.listing', {
#             'root': '/perdiem_module/perdiem_module',
#             'objects': http.request.env['perdiem_module.perdiem_module'].search([]),
#         })

#     @http.route('/perdiem_module/perdiem_module/objects/<model("perdiem_module.perdiem_module"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('perdiem_module.object', {
#             'object': obj
#         })
