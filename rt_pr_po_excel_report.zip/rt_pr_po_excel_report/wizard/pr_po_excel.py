from odoo import models, fields, api, _
import calendar
from odoo.exceptions import Warning
import xlsxwriter
from dateutil.relativedelta import relativedelta
import time
import base64, os
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


class PurchaseRequestOrderExcel(models.TransientModel):
    _name = 'purchase.request.order.excel'




    start_date = fields.Date('Start Date',default=fields.Date.today(),required=True)
    end_date = fields.Date('End Date',default=fields.Date.today(),required=True)
    excelfile = fields.Binary('Excel File')
    file_name = fields.Char('File Name')
    excel_flag = fields.Boolean('Show Excel File', default=lambda *a: False)

    def get_data(self):
        self.env.cr.execute('''SELECT prl.id,analytic.name as analytic,
        pr.name as pr_name,pr.date_start as pr_creation_date,prl.estimated_cost as prl_cost,pr.state as pr_status,
        pr.write_date as pr_last_update,agre.name as agreement,
        agre.create_date as agre_date,po.date_order as order_date,po.name as po_name,
        po.create_date as po_creation_date,sup.name as supplier
        FROM purchase_request_line AS prl
        LEFT JOIN purchase_request AS pr ON pr.id=prl.request_id
        LEFT JOIN account_analytic_account AS analytic ON analytic.id=prl.analytic_account_id
        LEFT JOIN purchase_order AS po ON po.id=prl.purchase_id
        LEFT JOIN res_partner AS sup ON sup.id=po.partner_id
        LEFT JOIN purchase_requisition AS agre ON agre.id=po.requisition_id
        WHERE pr.state in ('done') and pr.date_start >= '%s' AND pr.date_start <= '%s' ORDER BY pr.name asc;''' % (
        self.start_date, self.end_date))

        data = self.env.cr.dictfetchall()
        print('dataaaaaaaaaaaaaaaa ', data)
        return data

    def generate_data(self):
        data = self.get_data()

        today = time.strftime(DEFAULT_SERVER_DATETIME_FORMAT).replace(':', '').replace(' ', '_').replace('-', '')
        filename = 'PR_PO_Excel_%s.xlsx' % (today)
        title = 'Purchase Request to Purchase Order Report'

        workbook = xlsxwriter.Workbook('/tmp/%s' % (filename))
        worksheet = workbook.add_worksheet()

        # FORMATING PROPERTIES
        title_format = workbook.add_format({
            'bold': 1,
            'align': 'center',
            'valign': 'vcenter',
            'bg_color': '#A9A9A9',  ##A9A9A9
            'underline': 2,
            'border': 1,
            'size': 14})
        total_format = workbook.add_format({'bold': 1, 'bg_color': '#ccccff', 'top': 1,
                                            'underline': 2, 'size': 10})
        total_format.set_num_format('0.00')

        dateFormat = workbook.add_format({'num_format': 'dd/mm/yyyy',
                                          'size': 10, 'align': 'left', 'valign': 'vcenter'})

        datetimeFormat = workbook.add_format({'num_format': 'dd/mm/yyyy hh:mm:ss',
                                              'size': 10, 'align': 'left', 'valign': 'vcenter'})

        td_left_bold = workbook.add_format({'size': 10, 'align': 'left', 'valign': 'vcenter', 'bold': 1})
        td_left = workbook.add_format({'size': 10, 'align': 'left', 'valign': 'vcenter'})

        float_format = workbook.add_format({'size': 10})
        float_format.set_num_format('0.00')

        greyHeading = workbook.add_format({'bold': 1, 'align': 'left', 'valign': 'vcenter',
                                           'bg_color': '#A9A9A9', 'border': 1, 'size': 10})
        lightblueHeading = workbook.add_format({'bold': 1, 'align': 'left', 'valign': 'vcenter',
                                                'bg_color': '#B0C4DE', 'border': 1, 'size': 10})
        topLINE = workbook.add_format({'top': 6})

        worksheet.set_column('A:A', 15)
        worksheet.set_column('B:B', 15)
        worksheet.set_column('C:C', 10)
        worksheet.set_column('D:D', 10)
        worksheet.set_column('E:E', 10)
        worksheet.set_column('F:F', 10)
        worksheet.set_column('G:G', 10)
        worksheet.set_column('H:H', 10)
        worksheet.set_column('I:I', 10)
        worksheet.set_column('J:J', 10)
        worksheet.set_column('K:K', 10)
        worksheet.set_column('L:L', 10)
        worksheet.set_column('M:M', 10)
        worksheet.set_column('N:N', 10)
        worksheet.set_column('O:O', 10)
        worksheet.set_column('P:P', 10)
        worksheet.set_column('R:R', 10)
        worksheet.set_column('S:S', 10)
        worksheet.set_column('T:T', 10)

        worksheet.set_row(0, 30)

        # REPORT HEADING
        worksheet.merge_range('H1:M1', title, title_format)

        # HEADINGS
        headings = ['Product','Business Unit', 'Buyer Name', 'PR Number', 'PR Creation Date',
                    'PR Amount', 'PR Approval Status', 'PR Aproval Date',
                    'PR Approver name', 'RFQ Number', 'RFQ Creation Date', 'Award Approval Date',
                    'PO Number', 'PO Creation date', 'Supplier Name', 'PO Amount', 'PO Approval Status',
                    'PO Approval Date', 'PO Approver Name', 'PO status']

        row = 2
        col = 0
        for h in headings:
            worksheet.write(row, col, h, greyHeading)
            col += 1

        row += 1
        col = 0

        for element in data:
            po_amount = 0.0
            po_status = 'Open'
            tier_approve = ''
            tier_status = ''
            tier_date = False
            pr_id = self.env['purchase.request.line'].browse(element['id'])
            pol_id = self.env['purchase.order.line'].sudo().search([('order_id','=',pr_id.purchase_id.id),
                                                                    ('product_id','=',pr_id.product_id.id)])
            if pr_id.purchase_id.invoice_status == 'invoiced':
                po_status = 'Closed'
            if pol_id:
                po_amount = pol_id[0].price_subtotal
            for tier in pr_id.purchase_id.review_ids:
                tier_approve = tier[-1].done_by.name
                tier_status = tier[-1].status
                tier_date = tier[-1].reviewed_date
                print('tieeeeeeeeeer =============== ', tier_approve)
            worksheet.write(row, col, pr_id.product_id.display_name, dateFormat)
            worksheet.write(row, col + 1, pr_id.analytic_account_id.display_name, dateFormat)
            worksheet.write(row, col + 2, pr_id.requested_by.name, td_left)
            worksheet.write(row, col + 3, element['pr_name'], td_left)
            worksheet.write(row, col + 4, element['pr_creation_date'], dateFormat)
            worksheet.write(row, col + 5, element['prl_cost'], float_format)
            worksheet.write(row, col + 6, element['pr_status'], td_left)
            worksheet.write(row, col + 7, element['pr_last_update'], dateFormat)
            worksheet.write(row, col + 8, pr_id.assigned_to.name, td_left)
            worksheet.write(row, col + 9, element['agreement'], td_left)
            worksheet.write(row, col + 10, element['agre_date'], dateFormat)
            worksheet.write(row, col + 11, element['order_date'], dateFormat)
            worksheet.write(row, col + 12, element['po_name'], td_left)
            worksheet.write(row, col + 13, element['po_creation_date'], dateFormat)
            worksheet.write(row, col + 14, element['supplier'], td_left)
            worksheet.write(row, col + 15, po_amount, float_format)
            worksheet.write(row, col + 16, tier_status, float_format)
            worksheet.write(row, col + 17, tier_date, dateFormat)
            worksheet.write(row, col + 18, tier_approve, td_left)
            worksheet.write(row, col + 19, po_status, float_format)
            row += 1
            col = 0

        workbook.close()
        # FILE UPLOAD
        tf = open('/tmp/%s' % (filename), 'rb')
        buf = tf.read()
        out = base64.encodestring(buf)
        self.write({'excelfile': out, 'file_name': filename, 'excel_flag': True})
        tf.close()
        os.remove('/tmp/%s' % (filename))
        return {'type': 'ir.actions.act_window',
                'res_model': 'purchase.request.order.excel', 'view_mode': 'form',
                'view_type': 'form', 'res_id': self.id, 'target': 'new'}
