# -*- coding: utf-8 -*-
# from odoo import http


# class RtPrPoReport(http.Controller):
#     @http.route('/rt_pr_po_report/rt_pr_po_report/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/rt_pr_po_report/rt_pr_po_report/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('rt_pr_po_report.listing', {
#             'root': '/rt_pr_po_report/rt_pr_po_report',
#             'objects': http.request.env['rt_pr_po_report.rt_pr_po_report'].search([]),
#         })

#     @http.route('/rt_pr_po_report/rt_pr_po_report/objects/<model("rt_pr_po_report.rt_pr_po_report"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('rt_pr_po_report.object', {
#             'object': obj
#         })
