# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ResPartner(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    street_ar = fields.Char(string="Street (Arabic)", required=False, )
    street2_ar = fields.Char(string="Street2 (Arabic)", required=False, )
    city_ar = fields.Char(string="City (Arabic)", required=False, )
