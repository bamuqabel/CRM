# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanRenewContract(http.Controller):
#     @http.route('/bunyan_renew_contract/bunyan_renew_contract/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_renew_contract/bunyan_renew_contract/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_renew_contract.listing', {
#             'root': '/bunyan_renew_contract/bunyan_renew_contract',
#             'objects': http.request.env['bunyan_renew_contract.bunyan_renew_contract'].search([]),
#         })

#     @http.route('/bunyan_renew_contract/bunyan_renew_contract/objects/<model("bunyan_renew_contract.bunyan_renew_contract"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_renew_contract.object', {
#             'object': obj
#         })
