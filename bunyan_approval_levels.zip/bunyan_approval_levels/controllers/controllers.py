# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanApprovalLevels(http.Controller):
#     @http.route('/bunyan_approval_levels/bunyan_approval_levels/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_approval_levels/bunyan_approval_levels/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_approval_levels.listing', {
#             'root': '/bunyan_approval_levels/bunyan_approval_levels',
#             'objects': http.request.env['bunyan_approval_levels.bunyan_approval_levels'].search([]),
#         })

#     @http.route('/bunyan_approval_levels/bunyan_approval_levels/objects/<model("bunyan_approval_levels.bunyan_approval_levels"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_approval_levels.object', {
#             'object': obj
#         })
