# -*- coding: utf-8 -*-

import json
import requests
from odoo.tools import ustr
from odoo.exceptions import UserError
from odoo import models, fields, api, _
from requests.auth import HTTPBasicAuth


MAP_KEY_WITH_MODEL = {
    'academy': 'ils.academy',
    'batch': 'ils.batch',
    'education': 'ils.education',
    'employer': 'ils.employer',
    'employment': 'ils.employment',
    'enrollment': 'ils.enrollment',
    'modules': 'ils.modules',
    'qualification': 'ils.qualification',
    'room': 'ils.room',
    'semester': 'ils.semester',
    'school': 'ils.school',
    'teacher': 'ils.teacher',
}

class IlsFields(models.Model):
    _name = 'ils.fields'
    _description = 'ILS Fields'

    api_call_id = fields.Many2one('ils.api.configuration', string="Field Id")
    model_field_name = fields.Many2one('ir.model.fields', string="Model Field")
    custom_field_name = fields.Char(string="Custom Field Name")


class ApiConfiguration(models.Model):
    _name = 'ils.api.configuration'
    _description = 'Api Configuration'

    name = fields.Char(String="API Name")
    url = fields.Char(String="API URL")
    username = fields.Char(String="API Username")
    password = fields.Char(String="API Password")
    private_key = fields.Char(String="API Private Key")
    api_key_value = fields.Char(string="API Key Value")
    model_id = fields.Many2one('ir.model', String="API Model", domain=[
                               '|', '|', ('model', '=like', 'ils%'), ('model', '=like', 'res.partner'), ('model', '=like', 'product.template')])
    fields_ids = fields.One2many('ils.fields', 'api_call_id', string="Field Names")

    def update_api_call_data(self):
        cron_id = self.env.context.get('cron_id', False)
        if cron_id:
            cron = self.env['ir.cron'].browse(cron_id)
            effected_model_id = cron.effected_model
            effected_rec_id = cron.rel_api_config_record
            headers = {"Content-Type": 'application/json',
                       "x-out-auth": effected_rec_id.api_key_value}
            if effected_model_id.model == 'product.template':
                model_records = self.env[effected_model_id.model].search([('is_program', '=', True)])
            else:
                model_records = self.env[effected_model_id.model].search([])
            mapping_fields = {field.custom_field_name:field.model_field_name.name for field in effected_rec_id.fields_ids}
            for rec in model_records:
                data_dict = {}
                for field_data in mapping_fields:
                    ir_model_field=self.env['ir.model.fields'].search([('model','=',effected_model_id.model),('name','=',mapping_fields.get(field_data))])
                    if ir_model_field.ttype == 'many2one':
                        data_dict.update({field_data:str(getattr(rec, mapping_fields.get(field_data)).id)})
                    else:
                        data_dict.update({field_data:str(getattr(rec, mapping_fields.get(field_data)))})
                data = json.dumps(data_dict)
                token = requests.post(
                    effected_rec_id.url, headers=headers, data=data)
        return True

    def action_create_schedulers(self):
        ir_cron_obj = self.env['ir.cron']
        model_name = self.model_id.name
        self_model_name = self.env['ir.model'].search(
            [('model', '=like', 'ils.api.configuration')])
        ir_crons = ir_cron_obj.search(
            [('is_dynamic_crone', '=', True), ('name', '=', self.name + ' API Data Sync')])
        if ir_crons:
            raise UserError(_("Same model crone job is already exist."))
        else:
            ir_cron_obj.create({
                'name': self.name + ' API Data Sync',
                'model_id': self_model_name.id,
                'user_id': 1,
                'interval_number': 10,
                'interval_type': 'minutes',
                'active': True,
                'code': 'model.update_api_call_data()',
                'numbercall': -1,
                'doall': False,
                'state': 'code',
                'is_dynamic_crone': True,
                'effected_model': self.model_id.id,
                'rel_api_config_record': self.id})

    def test_api_connection(self):
        token = False
        if 'auth' in self.url:
            try:
                header = {'content-type': 'application/json'}
                response = requests.request("POST",
                                            str(self.url),
                                            auth=HTTPBasicAuth(
                                                self.username, self.password),
                                            headers=header, verify=False)
                token = response.json()["Token"] or False
            except Exception as e:
                raise UserError(
                    _("API Connection Test Failed! Here is the error:\n%s") % ustr(e))
        try:
            if token:
                headers = {'content-type': 'application/json',
                           'x-auth-token': token}
            else:
                headers = {'content-type': 'application/json'}
            response = requests.get(self.url, headers=headers, verify=False)
            if response.status_code != 200:
                raise UserError(_("Did not received proper response."))
        except Exception as e:
            raise UserError(
                _("API Connection Test Failed! Here is the error:\n%s") % ustr(e))

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("API Connection Test Succeeded!"),
                'message': _("Everything seems properly set up!"),
                'sticky': False,
            }
        }


class IrCron(models.Model):
    _inherit = "ir.cron"

    is_dynamic_crone = fields.Boolean('Is Dynamic Crone?', default=False)
    effected_model = fields.Many2one(
        'ir.model', String="Effected Model", readonly=True)
    rel_api_config_record = fields.Many2one(
        'ils.api.configuration', String="Related API Configuration")

    @api.model
    def _callback(self, cron_name, server_action_id, job_id):
        """ to handle cron thread executed by Odoo."""
        self = self.with_context(cron_id=job_id)
        return super(IrCron, self)._callback(cron_name, server_action_id, job_id)

    # @api.multi
    def method_direct_trigger(self):
        """ to handle manual execution using the button."""
        for rec in self:
            rec = rec.with_context(cron_id=rec.id)
            super(IrCron, rec).method_direct_trigger()
        return True
