# -*- coding: utf-8 -*-

from odoo import models, fields, api


class AppraisalType(models.Model):
    _name = 'appraisal.type'
    _description = 'Appraisal Type'

    name = fields.Char(string="Name", required=True, )
    criteria_ids = fields.One2many(comodel_name="appraisal.criteria", inverse_name="appraisal_type_id", string="Criteria", required=False, )
    type = fields.Selection(string="Type", selection=[('annual', 'Annual'), ('probation', 'Probation'), ], )


class AppraisalCriteria(models.Model):
    _name = 'appraisal.criteria'
    _description = 'Appraisal Criteria'
    
    appraisal_type_id = fields.Many2one(comodel_name="appraisal.type", string="Appraisal Type", required=True, )
    name = fields.Char(string="Criteria", required=False, )
    
    
class HRAppraisal(models.Model):
    _name = 'hr.appraisal'
    _inherit = 'hr.appraisal'

    appraisal_type_id = fields.Many2one(comodel_name="appraisal.type", string="Appraisal Type", required=False, )
    appraisal_type = fields.Selection(related='appraisal_type_id.type')
    appraisal_criteria_ids = fields.One2many(comodel_name="employee.appraisal.criteria", inverse_name="appraisal_id",
                                             string="Appraisal", required=False, )
    strengths_technical = fields.Text(string="Technical", required=False, )
    strengths_behavioral = fields.Text(string="Behavioral", required=False, )
    improve_technical = fields.Text(string="Technical", required=False, )
    improve_behavioral = fields.Text(string="Behavioral", required=False, )
    individual_plan = fields.Selection(string="Options", selection=[('enroll', 'Enroll the employee in Mentroship program for six months'),
                                                                    ('success_plan', 'Employee is a part of Succession plan'),
                                                                    ('promotion', 'Promotion'),
                                                                    ('salary_increase', 'Salary Increase'),
                                                                    ('training_course', 'Enroll in training course'),
                                                                    ], default='enroll', )
    individual_plan_justification = fields.Text(string="Justification", required=False, )
    hrm_signature = fields.Binary(string="HRM Signature", )
    employee_signature = fields.Binary(string="Employee Signature", )
    line_manager_signature = fields.Binary(string="Line Manager Signature", )


    @api.onchange('individual_plan')
    def _onchange_individual_plan(self):
        for rec in self:
            rec.individual_plan_justification = ''

    @api.onchange('appraisal_type_id')
    def _onchange_appraisal_type_id(self):
        for rec in self:
            if rec.appraisal_criteria_ids:
                rec.appraisal_criteria_ids = [(5, 0, 0)]
            if rec.appraisal_type_id:
                app_type_vals = []
                for criteria in rec.appraisal_type_id.criteria_ids:
                    app_type_vals.append((0, 0, {'name': criteria.name}))
                rec.appraisal_criteria_ids = app_type_vals


class EmployeeAppraisalCriteria(models.Model):
    _name = 'employee.appraisal.criteria'
    _description = 'Employee Appraisal Criteria'

    name = fields.Char(string="Criteria", required=True, )
    appraisal_id = fields.Many2one(comodel_name="hr.appraisal", string="Employee Appraisal Criteria", required=False, )
    expected_score = fields.Selection(string="Expected Rate", selection=[('1', 'Unsatisfactory'),
                                                                          ('2', 'Need Improvement'),
                                                                          ('3', 'Meet Expectation'),
                                                                          ('4', 'Exceed Expectation')], default='1', )
    actual_score = fields.Selection(string="Actual Rate", selection=[('1', 'Unsatisfactory'), ('2', 'Need Improvement'),
                                                                        ('3', 'Meet Expectation'),
                                                                        ('4', 'Exceed Expectation')], default='1', )
    result = fields.Char(string="Result", compute='_compute_result')

    @api.depends('expected_score', 'actual_score')
    def _compute_result(self):
        for rec in self:
            if rec.expected_score == rec.actual_score:
                rec.result = 'Best Result'
            elif rec.expected_score > rec.actual_score:
                rec.result = 'Need PIP'
            elif rec.expected_score < rec.actual_score:
                rec.result = 'Exceed the required performance'
            else:
                rec.result = ''
