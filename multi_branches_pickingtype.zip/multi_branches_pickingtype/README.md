# multi_branches_pickingtype

Restrict user access to operation types based on the allowed branches.