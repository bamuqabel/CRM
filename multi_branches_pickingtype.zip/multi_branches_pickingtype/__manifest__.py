# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

{
    'name': 'Multi-Branch for Operation Types',
    'version': '1.0',
    'summary': 'Restrict user access to operation types based on the allowed branches.',
    'sequence': 30,
    'description': """
        Restrict user access to operation types based on the allowed branches.
    """,
    'category': 'Inventory',
    'author': 'ILS',
    'website': 'www.ils.com.sa',
    'depends': ['multi_branches'],
    'data': [
        'security/pickingtype_branch_security.xml',
        'security/ir.model.access.csv',
        'views/multi_branches_pickingtype_view.xml'
        ],
    'demo': [],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'OPL-1'
}
