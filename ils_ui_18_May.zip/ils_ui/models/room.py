# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Room(models.Model):
    _name = 'ils.room'
    _description = 'Room'

    name = fields.Char(string='Room Name', required=True)
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy', required=True)
    booked_facility = fields.Boolean(string='booked_facility')
    location = fields.Char(string='Location')
    specific_program = fields.Boolean(string='Specific program?')
    specific_program_id = fields.Many2one('product.template', domain="([('is_program', '=', True)])", string='Specific Program')
    module_room_ids = fields.One2many('ils.module.room', 'room_id', string="Rooms and Capacity")


class ilsModuleRoom(models.Model):
    _name = 'ils.module.room'
    _description = 'ILS Module Room'

    module_id = fields.Many2one(comodel_name='ils.modules', string="Module", required=True)
    room_id = fields.Many2one(comodel_name='ils.room', string="Room", required=True)
    capacity = fields.Integer(string='Capacity', required=True)
    gap_between_class = fields.Float(string="Gap betweem classes (In Minutes)")