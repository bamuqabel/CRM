from odoo import fields,models,api

class UpdateRequestManagerWizard(models.Model):
    _name = 'update.request.manager'

    def update_user_manager(self):
        active_ids = self._context.get('active_ids')
        request_ids = self.env['purchase.request'].browse(active_ids)
        for rec in request_ids:
            if rec.requested_by:
                get_manager = self.env['hr.employee'].search([('user_id', '=', rec.requested_by.id)])
                if get_manager:
                    rec.assigned_to = get_manager.parent_id.user_id.id or False
        return True
