# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import salary_structure
from . import hr_payroll
from . import other_hr_payslip
from . import hr_payslip_export
from . import hr_payslip_run
from . import res_config_setting

