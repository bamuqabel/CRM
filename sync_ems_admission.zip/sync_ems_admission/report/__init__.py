# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from . import report_students_financeial
from . import report_student_financeial
from . import report_admission_analysis
