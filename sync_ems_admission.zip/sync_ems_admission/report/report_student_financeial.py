# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

import time
from odoo import models, fields, api


class SyncEmsAdmissionStudentReport(models.AbstractModel):
    _name = 'report.sync_ems_admission.student_financial_report'
    _inherit = 'report.abstract_report'

    def _get_objects(self,data):
        return data

    def _get_invoice(self,data):
        invoice_ids = self.env['account.invoice'].search([
            ('partner_id', '=', data['partner_id'])])
        invoice_obj = invoice_ids
        return invoice_obj

    @api.model
    def render_html(self, docids, data=None):
        report_obj = self.env['report']
        report_report = report_obj._get_report_from_name('sync_ems_admission.student_financial_report')
        report = self.env['account.invoice'].browse(self.ids)
        docargs = {
            'doc_ids': self.ids,
            'doc_model': report_report.model,
            'docs': report,
            'get_invoice': self._get_invoice(data['form']),
            'get_objects' : self._get_objects(data['form']),
        }
        return report_obj.render('sync_ems_admission.student_financial_report', docargs)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: