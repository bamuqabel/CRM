# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from datetime import datetime
from odoo import models, fields, api


class SyncEmsAdmissionAdmissionReport(models.AbstractModel):
    _name = 'report.sync_ems_admission.admission_analysis_report'
    _inherit = 'report.abstract_report'

    def _get_objects(self,data):
        return data

    def _get_students(self,data):
        res = []
        result_list = []
        from_date = datetime.strptime(data['date_from'], "%d/%m/%Y").date()
        to_date = datetime.strptime(data['date_to'], "%d/%m/%Y").date()
        course_id = data['course_id']
        semester_ids = data['semester_id']
        admission_obj = self.env['admission.admission']

        self.env.cr.execute('select id from admission_admission where admission_date between %s and %s', (from_date, to_date))
        for rec in self.env.cr.fetchall():
            result_list.append(rec[0])
        for semester in semester_ids:
            lst = admission_obj.search([
                ('id', 'in', result_list), ('course_id', '=', course_id),
                ('semester_id', '=', semester)
                ])
            students = lst
            dict = {'semester_name':semester, 'students':students}
            res.append(dict)
        return res

    @api.model
    def render_html(self, docids, data=None):
        report_obj = self.env['report']
        report_report = report_obj._get_report_from_name('sync_ems_admission.admission_analysis_report')
        report = self.env['admission.admission'].browse(self.ids)
        docargs = {
            'doc_ids': self.ids,
            'doc_model': report_report.model,
            'docs': report,
            'get_students': self._get_students(data['form']),
            'get_objects' : self._get_objects(data['form']),
        }
        return report_obj.render('sync_ems_admission.admission_analysis_report', docargs)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: