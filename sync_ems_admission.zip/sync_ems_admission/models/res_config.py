# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class EmsConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    registration_info = fields.Boolean("Send sms when Admission registration completed.", config_parameter='sync_ems_admission.registration_info')
    payment_info = fields.Boolean("Send sms when Admission payment completed.", config_parameter='sync_ems_admission.payment_info')
    invoice_payment_info = fields.Boolean("Send sms when Invoice payment completed.", config_parameter='sync_ems_admission.invoice_payment_info')

    # @api.onchange('module_smsclient')
    # def onchange_sms(self):
    #     if self.module_smsclient:
    #         self.update({
    #             'registration_info': True,
    #             'payment_info': True,
    #             'invoice_payment_info': True,
    #         })

# vim:expandtab:smartindent:tabstop=4:softta,bstop=4:shiftwidth=4:

