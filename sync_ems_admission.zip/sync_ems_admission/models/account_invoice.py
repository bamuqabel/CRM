# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class AccountMove(models.Model):
    _inherit = 'account.move'

    pricelist_id = fields.Many2one('product.pricelist', 'Pricelist')

    # @api.model
    # def create(self, val):
    #     """" create AccountMove """
    #     res = super(AccountMove, self).create(val)
    #     res._onchange_partner_id()
    #     return res

    def action_invoice_paid(self):
        ''' when admission is done than invoice in confirm_paid'''
        super(AccountMove, self).action_invoice_paid()
        for obj in self:
            admissions = self.env['admission.admission'].search([('invoice_id', '=', obj.id)])
            for admission in admissions:
                admission.state = 'done'
                mobile = admission.middle_name and admission.middle_name.mobile or False
                config_obj = self.env['ir.config_parameter'].sudo()
                payment_info = config_obj.get_param('sync_ems_admission.payment_info')
                if mobile and payment_info:
                    admission.with_context({'active_id' : [admission.id]})._message_sms_with_template(
                        template_xmlid='sync_ems_admission.sms_template_data_registration_payment_info',
                        template_fallback=_("Registration Payment Information: %s, %s.") % (admission.middle_name.name, admission.all_total_price),
                        partner_ids=obj.partner_id.ids,
                        put_in_queue=False
                    )
        return True


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    # @api.model
    # def create(self, val):
    #     ''' Creates invoice when admission '''
    #     context = dict(self._context)
    #     res = super(AccountMoveLine, self).create(val)
    #     if context.get('admission'):
    #         res.with_context(context)._onchange_product_id()
    #     return res

    @api.onchange('product_id')
    def _onchange_product_id(self):
        ''' Update the following fields when the product_id is changed '''
        context = dict(self._context)
        super(AccountMoveLine, self)._onchange_product_id()
        if self.product_id and (context.get('admission') or context.get('duration')):
            context.update({'is_school_data': True})
            list_price = self.product_id.with_context(context).price_compute('list_price')
            self.price_unit = list_price.get(self.product_id.id) or False
