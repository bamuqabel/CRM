# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class PreviousAcademicReport(models.Model):
    _name = 'previous.academic.report'
    _description = 'Previous Academic Report'

    name = fields.Char("School Name", required=True)
    semester_id = fields.Many2one('other.standard', string='Standard', required=True)
    division_id = fields.Many2one('other.division', string='Division', required=True)
    admission_id = fields.Many2one('admission.admission', 'Admission')
    description = fields.Text(string="Description")
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')

    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for obj in self:
            if obj.end_date < obj.start_date:
                raise ValidationError(_('start date of batch must be less than end date!'))


class PreviousLanguages(models.Model):
    _name = 'previous.languages'
    _description = 'Previous Languages'

    language = fields.Many2one('student.language', string='Language', required=True)
    academic_id = fields.Many2one('previous.academic.report', string='Previous Academic Report', required=True)
    admission_id = fields.Many2one('admission.admission', 'Admission')
    description = fields.Text(string="Description")


class HealthHealth(models.Model):
    _inherit = 'health.health'

    admission_id = fields.Many2one('admission.admission', 'Admission')


class OtherStandard(models.Model):
    _name = 'other.standard'
    _description = 'Other Standard'

    name = fields.Char("Name", required=True)


class OtherDivision(models.Model):
    _name = 'other.division'
    _description = 'Other Division'

    name = fields.Char("Name", required=True)
