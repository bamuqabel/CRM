# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from . import account_invoice
from . import account_payment
from . import admission
from . import semester
from . import analytic
from . import res_config
from . import product
from . import sale
from . import student
from . import previous_data
