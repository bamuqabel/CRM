# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_done(self):
        '''Generate all purchase order based on selected lines '''
        context = dict(self._context)
        for order in self:
            config_obj = self.env['ir.config_parameter'].sudo()
            invoice_payment_info = config_obj.get_param('sync_ems_admission.invoice_payment_info')
            if order.partner_id.mobile and invoice_payment_info:
                context.update({'active_id' : [order.id], 'name': order.name, 'price': order.amount_total})
                order.with_context(context)._message_sms_with_template(
                    template_xmlid='sync_ems_admission.sms_template_data_payment_info',
                    template_fallback=_("Registration Payment Information: %s, %s.") % (order.name, order.amount_total),
                    partner_ids=order.partner_id.ids,
                    put_in_queue=False
                )
        return super(SaleOrder, self).action_done()


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.model
    def default_get(self, fields):
        res = super(SaleOrderLine, self).default_get(fields)
        self.product_id_change()
        return res

    @api.onchange('product_id')
    def product_id_change(self):
        """
            Set orderline according to product.
        """
        context = dict(self._context)
        if context.get('admission') and self.product_id:
            context.update({
                'admission_date': fields.Date.today(),
                'is_school_data': True,
            })
            list_price = self.product_id.with_context(context).price_compute('list_price')
            self.price_unit = list_price.get(self.product_id.id) or False
        return super(SaleOrderLine, self).product_id_change()
