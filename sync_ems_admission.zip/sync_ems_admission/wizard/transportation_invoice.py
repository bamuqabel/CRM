# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import Warning
import time


class TransportationMakeInvoice(models.TransientModel):
    _name = "transportation.make.invoice"
    _description = "Transportation Make_invoice"

    @api.model
    def _get_active_student(self):
        """
            fetch active student.
        """
        return self._context.get('active_id', False)

    @api.constrains('transport_id')
    def _check_transport(self):
        """
            Check transportation.
        """
        for obj in self:
            if obj.transport_id and obj.transport_id.free_seats <= 0:
                raise ValidationError(_('Please choose another transport. There is no more free seats!'))
        return True

    transportation_type = fields.Selection([('oneway_morning', 'One-way Morning'), ('oneway_evening', 'One-way Evening'), ('two_way', 'Two-Way')], string='Service Type', required=True)
    pickup_drop = fields.Many2one('res.area', string='Area', required=True)
    transport_id = fields.Many2one('transportation.transportation', string='Transport', required=True)
    student_id = fields.Many2one('student.student', string='Student', default=_get_active_student)

    @api.onchange('transportation_type')
    def onchange_service_type(self):
        """
            Set pickup_drop according to transportation.
        """
        self.pickup_drop = False
        self.transport_id = False

    @api.onchange('pickup_drop')
    def onchange_pickup_drop(self):
        ''' Update the following fields when the pickup_drop is changed '''
        res = {'domain': {}}
        transports = []
        stop_ids = []
        transportation_ids = self.env['transportation.transportation'].search([('transportation_type', '=', self.transportation_type)])
        for transport in transportation_ids:
            stop_ids = [stop.pickup_drop.id for stop in transport.stop]
            if self.pickup_drop.id in stop_ids:
                transports.append(transport.id)
        res['domain'].update({'transport_id':[('id', 'in', transports)]})
        self.transport_id = False
        return res

    def make_invoice(self):
        ''' create invoice'''
        res = {}
        invoice_obj = self.env['account.move']
        invoice_line_obj = self.env['account.move.line']
        product_obj = self.env['product.product']
        ctx = dict(self._context)
        for obj in self:
            analytic_account_id = obj.student_id.course_id and obj.student_id.course_id.analytic_account_id or False

            obj.student_id.write({'analytic_account_id': analytic_account_id and analytic_account_id.id})
            ctx.update({
                'admission':'admission',
                'course_id': obj.student_id.course_id and obj.student_id.course_id.id or False,
                'semester_id': obj.student_id.semester_id and obj.student_id.semester_id.id or False,
                'pickup_drop': obj.pickup_drop and obj.pickup_drop.id or False,
                'transport_id': obj.transport_id and obj.transport_id.id or False
            })

            invoice_data = {
                'type': 'out_invoice',
                'partner_id': obj.student_id.partner_id.id,
                'invoice_date': time.strftime('%Y') + '-07-01',
                'invoice_payment_term_id': obj.student_id.course_id.payment_term_id and obj.student_id.course_id.payment_term_id.id or False,
            }
            product_id = product_obj.search([('transport_fee', '=', True), ('company_id', '=', self.env.user.company_id.id)], limit=1)
            if not product_id:
                raise Warning(_('Please first configure transportation fees for %s.') % self.env.user.company_id.name)
            invoice_line_default = {
                'name': product_id.name,
                'analytic_account_id': analytic_account_id and analytic_account_id.id,
                'product_id': product_id and product_id.id,
                'price_unit': product_id and product_id.lst_price,
                'quantity': 1.0,
                'product_uom_id': product_id and product_id.uom_id.id,
                'account_id': product_id and product_id.categ_id.property_account_income_categ_id.id,
            }

            invoice_data.update({'invoice_line_ids' : [(0, 0, invoice_line_default)]})
            invoice_id = invoice_obj.with_context(ctx).create(invoice_data)
            obj.student_id.write({
                'transportation_type': obj.transportation_type,
                'pickup_drop': obj.pickup_drop and obj.pickup_drop.id or False,
                'transport_id': obj.transport_id and obj.transport_id.id or False,
                # 'stop_id': obj.stop_id and obj.stop_id.id or False,
                'transportation_ids': [(0, 0, {
                        'transportation_type': obj.transportation_type,
                        'pickup_drop': obj.pickup_drop and obj.pickup_drop.id or False,
                        'transport_id': obj.transport_id and obj.transport_id.id or False,
                        'invoice_id': invoice_id and invoice_id.id
                    })]
                })

            if ctx.get('open_invoice', False):
                return self.open_invoice(invoice_id.id)
        return {'type': 'ir.actions.act_window_close'}

    def open_invoice(self, invoice_id):
        ''' open a view on one of the given invoice_id '''
        action = self.env.ref('account.action_move_out_invoice_type').read()[0]

        action['context'] = {'type': 'out_invoice'}
        if len([invoice_id]) > 1:
            action['domain'] = [('id', 'in', [invoice_id])]
        elif len([invoice_id]) == 1:
            action['views'] = [(self.env.ref('account.view_move_form').id, 'form')]
            action['res_id'] = invoice_id
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: