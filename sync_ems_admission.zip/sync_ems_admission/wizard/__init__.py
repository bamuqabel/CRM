# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from . import transportation_invoice
from . import student_migration
from . import request_reject_wiz
from . import reset_to_draft_wiz
# from . import wizard_student_financial_report
# from . import wizard_students_financial_report
# from . import wizard_admission_analysis_report