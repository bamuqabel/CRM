# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class ResetToDraft(models.TransientModel):
    """
        Reject Admission Request
    """
    _name = 'reset.draft'
    _description = 'Admission Set To Draft'

    is_missiong_record = fields.Boolean(string='Is Missing Record')

    def reset_to_draft(self):
        context = dict(self.env.context)
        if context.get('active_id') and context.get('active_model') == 'admission.admission':
            # Send Mail
            active_id = self.env['admission.admission'].browse(context['active_id'])
            if active_id:
                if self.is_missiong_record:
                    mail_template_id = self.env.ref('sync_ems_admission.mail_template_for_missing_admission_pending')
                    if mail_template_id:
                        mail_template_id.send_mail(active_id.id, force_send=False, raise_exception=False)
                    active_id._message_sms_with_template(
                        template_xmlid='sync_ems_admission.sms_template_for_missing_admission_pending',
                        template_fallback=_("Missing Record: %s, %s.") % (active_id.middle_name.name, active_id.admission_date),
                        partner_ids=active_id.middle_name and active_id.middle_name.ids,
                        put_in_queue=False
                    )
                active_id.reset_to_draft()
