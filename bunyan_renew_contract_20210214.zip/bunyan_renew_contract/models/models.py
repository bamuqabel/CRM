# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from dateutil.relativedelta import relativedelta


class ContractRenewals(models.Model):
    _name = 'contract.renew'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Contract Renewals'

    name = fields.Char(string="Name", required=True, default=lambda s: s.env['ir.sequence'].next_by_code('contract.renew.sequence'))
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=True, related='expired_contract_id.employee_id')
    state = fields.Selection(string="State", selection=[('new', 'New'), ('hr_approval', 'HR Approved'), ('approved', 'Approved'), ('new_contract_created', 'New Contract Created'), ('refused', 'Refuse')], required=False, default='new')
    # Expired Contract Details
    expired_contract_id = fields.Many2one(comodel_name="hr.contract", string="Expired Contract", required=True, )
    expired_contract_date_start = fields.Date(string="Start Date", related='expired_contract_id.date_start')
    expired_contract_date_end = fields.Date(string="End Date", related='expired_contract_id.date_end')
    expired_structure_type_id = fields.Many2one(comodel_name="hr.payroll.structure.type", related='expired_contract_id.structure_type_id', )
    expired_job_id = fields.Many2one(comodel_name="hr.job", related='expired_contract_id.job_id', )
    # New Contract Details
    new_contract_id = fields.Many2one(comodel_name="hr.contract", string="New Contract", required=False, )
    new_contract_date_start = fields.Date(string="Start Date", )
    new_contract_date_end = fields.Date(string="End Date", )
    new_structure_type_id = fields.Many2one(comodel_name="hr.payroll.structure.type", string="Salary Structure Type", default=lambda s: s.expired_contract_id.structure_type_id.id)
    new_job_id = fields.Many2one(comodel_name="hr.job", string="Job Position", default=lambda s: s.expired_contract_id.job_id.id, )
    ceo_signature = fields.Binary(string="CEO Signature", )

    def create_new_contract(self):
        for rec in self:
            if rec.expired_contract_id:
                rec.new_contract_id = rec.expired_contract_id.copy({"date_start": rec.new_contract_date_start or rec.expired_contract_id.date_start,
                                                                    "date_end": rec.new_contract_date_end,
                                                                    "structure_type_id": rec.new_structure_type_id.id or rec.expired_structure_type_id.id or False,
                                                                    "job_id": rec.new_job_id.id or rec.expired_job_id.id or False})
                rec.new_contract_id.ceo_signature = rec.ceo_signature or False
                if rec.new_contract_id:
                    rec.state = 'new_contract_created'

    def approve_contract_renew(self):
        for rec in self:
            if rec.ceo_signature:
                rec.state = 'approved'
            else:
                raise UserError(_('Please, Sign the document!'))

    def hr_approve_contract_renew(self):
        for rec in self:
            rec.state = 'hr_approval'

    def refuse_contract_renew(self):
        for rec in self:
            rec.state = 'refused'


class HREmployee(models.Model):
    _name = 'hr.employee'
    _inherit = 'hr.employee'

    passport_city = fields.Char(string="Passport Issued City", required=False, )
    passport_city_ar = fields.Char(string="Passport Issued City (Arabic)", required=False, )
    passport_issue_date = fields.Date(string="Passport Issue Date", required=False, default=fields.Date.context_today)


class HRContract(models.Model):
    _name = 'hr.contract'
    _inherit = 'hr.contract'

    hijri_start_date = fields.Char(string="Start Date (Hijri)", required=False, )
    hijri_end_date = fields.Char(string="End Date (Hijri)", required=False, )
    # Signature
    ceo_signature = fields.Binary(string="CEO Signature", )
    employee_signature = fields.Binary(string="Employee Signature", )


class Partner(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    street_ar = fields.Char(string="Street (Arabic)", required=False, )
    street2_ar = fields.Char(string="Street2 (Arabic)", required=False, )
    city_ar = fields.Char(string="City (Arabic)", required=False, )
