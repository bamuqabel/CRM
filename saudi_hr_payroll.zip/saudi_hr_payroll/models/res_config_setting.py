# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    group_group_send_payslip = fields.Boolean('Send Payslip', implied_group='saudi_hr_payroll.group_send_payslip', default=False)