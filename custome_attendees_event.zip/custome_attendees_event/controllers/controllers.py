# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager


class CustomerPortalInherit(CustomerPortal):

	def _prepare_portal_layout_values(self):
		# Overriding the base method for updating the dictionary with new values
		res = super(CustomerPortalInherit, self)._prepare_portal_layout_values()
		partner = request.env.user.partner_id

		event_count = request.env['event.registration'].search_count([('partner_id', '=', partner.id)])

		res.update({
			'event_count': event_count
		})

		return res

	@http.route(['/my/events', '/my/events/page/<int:page>'], type='http', auth="user", website=True)
	def portal_my_events(self, page=1):
		# Dictionary update for events values
		values = self._prepare_portal_layout_values()
		partner = request.env.user.partner_id

		domain = [('partner_id', '=', partner.id)]

		event_count = request.env['event.registration'].search_count(domain)

		archive_groups = self._get_archive_groups('event.registration', domain)

		pager = portal_pager(
			url="/my/events",
			url_args={'date_begin': None, 'date_end': None, 'sortby': None},
			total=event_count,
			page=page,
			step=self._items_per_page
		)

		events = request.env['event.registration'].search(domain, limit=self._items_per_page, offset=pager['offset'])

		values.update({
			'events': events.sudo(),
			'page_name': 'event',
			'pager': pager,
			'archive_groups': archive_groups,
			'default_url': '/my/events',
		})

		return request.render("custome_attendees_event.portal_my_events", values)
