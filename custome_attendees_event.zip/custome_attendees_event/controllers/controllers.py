# -*- coding: utf-8 -*-
# from odoo import http


# class CustomeAttendeesEvent(http.Controller):
#     @http.route('/custome_attendees_event/custome_attendees_event/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/custome_attendees_event/custome_attendees_event/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('custome_attendees_event.listing', {
#             'root': '/custome_attendees_event/custome_attendees_event',
#             'objects': http.request.env['custome_attendees_event.custome_attendees_event'].search([]),
#         })

#     @http.route('/custome_attendees_event/custome_attendees_event/objects/<model("custome_attendees_event.custome_attendees_event"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('custome_attendees_event.object', {
#             'object': obj
#         })
