# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanVacationRequest(http.Controller):
#     @http.route('/bunyan_vacation_request/bunyan_vacation_request/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_vacation_request/bunyan_vacation_request/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_vacation_request.listing', {
#             'root': '/bunyan_vacation_request/bunyan_vacation_request',
#             'objects': http.request.env['bunyan_vacation_request.bunyan_vacation_request'].search([]),
#         })

#     @http.route('/bunyan_vacation_request/bunyan_vacation_request/objects/<model("bunyan_vacation_request.bunyan_vacation_request"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_vacation_request.object', {
#             'object': obj
#         })
