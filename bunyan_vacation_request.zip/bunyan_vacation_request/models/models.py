# -*- coding: utf-8 -*-

from odoo import models, fields, api


class VacationRequest(models.Model):
    _name = 'hr.vacation'
    _inherit = 'hr.vacation'

    is_ticket = fields.Boolean(string="Ticket",  )
    is_advance_salary = fields.Boolean(string="Advance Salary",  )
    is_visa = fields.Boolean(string="VISA",  )
