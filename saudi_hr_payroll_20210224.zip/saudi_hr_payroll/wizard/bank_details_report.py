# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import fields, models, api, _
from io import BytesIO
import xlsxwriter
import base64


class BankDetailsReport(models.TransientModel):
    _name = "bank.details.report"
    _description = "Bank Details Report"

    filename = fields.Char(string='File Name', size=64)
    excel_file = fields.Binary(string='Excel File')

    def print_reports(self):
        values = {}
        report = self
        filename = 'Bank Details Report.xlsx'
        fp = BytesIO()
        workbook = xlsxwriter.Workbook(fp)
        worksheet = workbook.add_worksheet('Bank Details Report')
        company_head = workbook.add_format({
                    'bold': 1,
                    'border': 1,
                    'align': 'center',
                    'valign': 'vcenter',
                    'font_size': 12,
                    'num_format': '#,##0.00',
                    'font_name': 'Times New Roman',
                    'bg_color': '#667C26'})
        detail_head = workbook.add_format({
                    'bold': 1,
                    'border': 1,
                    'align': 'center',
                    'valign': 'vcenter',
                    'font_size': 12,
                    'num_format': '#,##0.00',
                    'font_name': 'Times New Roman',
                    'bg_color': '#98AFC7',
                    'font_color': '#FFFFFF',
        })
        bank_head = workbook.add_format({'bold': 1, 'border': 1, 'align': 'center', 'valign': 'vcenter', 'font_size': 12, 'num_format': '#,##0.00',
                'font_name': 'Times New Roman', 'bg_color': '#FFFF00'})
        details_format = workbook.add_format(
            {'valign': 'vcenter', 'font_size': 12, 'num_format': '#,##0.00', 'font_name': 'Times New Roman'})
        batch_id = False
        if self._context.get('active_id'):
            batch_id = self.env['hr.payslip.run'].search([('id', '=', self._context.get('active_id'))])
            employees = batch_id.slip_ids.filtered(lambda l: l.state == 'done')

        worksheet.merge_range(0, 0, 0, 10, self.env.user.company_id.name, company_head)
        if batch_id:
            worksheet.merge_range(1, 0, 1, 10, batch_id.name, company_head)

        worksheet.write(2, 0, 'Bank Name', detail_head)
        worksheet.write(2, 1, 'Bank Account No.', detail_head)
        worksheet.write(2, 2, 'Net', detail_head)
        worksheet.write(2, 3, 'Remarks', detail_head)
        worksheet.write(2, 4, 'Employee', detail_head)
        worksheet.write(2, 5, 'RP No', detail_head)
        worksheet.write(2, 6, 'Home Address', detail_head)
        worksheet.write(2, 7, 'Basic', detail_head)
        worksheet.write(2, 8, 'Housing', detail_head)
        worksheet.write(2, 9, 'Others', detail_head)
        worksheet.write(2, 10, 'Total Deductions', detail_head),
        first_row = 3
        worksheet.merge_range(3, 0, 3, 10, 'Bank', bank_head)
        all_col_dict = {'bank_name': 0, 'account_no': 1, 'net': 2, 'remark': 3, 'employee': 4, 'rp_no': 5, 'home_address': 6,
                        'basic': 7, 'housing': 8, 'others': 9, 'total_deduction': 10}

        worksheet.set_column(0, 0, 15)
        worksheet.set_column(2, 4, 12)
        worksheet.set_column(5, 6, 15)
        worksheet.set_column(7, 8, 11)
        worksheet.set_column(9, 10, 15)
        worksheet.set_column(11, 11, 25)
        worksheet.freeze_panes(4, 0)
        actual_data_row = 4
        for slip in employees:
            total_deduction = []
            total_others = []
            document_id = self.env['res.documents'].search(['|', ('type_id.code', '=', 'ino'), ('type_id.code', '=', 'nid'),
                                                            ('employee_id', '=', slip.employee_id.id)], limit=1)
            deduction_ids = slip.line_ids.filtered(lambda l: l.category_id.code == 'DED' or l.category_id.parent_id.code == 'DED')
            for deduction in deduction_ids:
                total_deduction.append(abs(deduction.total))
            others_allowance = sum(slip.line_ids.filtered(lambda l: l.category_id.code == 'ALW' or l.category_id.parent_id.code == 'ALW').mapped('total'))
            if slip.line_ids.filtered(lambda l: l.code == 'HRA'):
                others_allowance = others_allowance - slip.line_ids.filtered(lambda l: l.code == 'HRA').mapped('total')[0]
            values.update({
                        'bank_name': slip.employee_id.bank_account_id.bank_id.name if slip.employee_id.bank_account_id.bank_id.name else False or '',
                        'account_no': slip.employee_id.bank_account_id.acc_number or '' ,
                        'net': slip.line_ids.filtered(lambda l: l.code == 'NET').total or '',
                        'remark': '',
                        'employee': slip.employee_id.name or '',
                        'rp_no': document_id.doc_number or '',
                        'home_address': slip.employee_id.address_home_id.street or '' if slip.employee_id.address_home_id else '',
                        'basic': slip.line_ids.filtered(lambda l: l.code == 'BASIC').total or '',
                        'housing': slip.line_ids.filtered(lambda l: l.code == 'HRA').total or '',
                        'others': others_allowance,
                        'total_deduction': sum(total_deduction),
                    })
            for line_dict in values:
                worksheet.write(actual_data_row, all_col_dict[line_dict], values[line_dict], details_format)
            actual_data_row += 1
        workbook.close()
        report.write({'excel_file': base64.encodestring(fp.getvalue()), 'filename': filename})
        fp.close()

        return self.return_wiz_action(report.id)

    def return_wiz_action(self, res_id, context=None):
        """
            Return Admin Reports
        """
        return {
            'name': 'Bank Details Report',
            'view_mode': 'form',
            'res_id': res_id,
            'res_model': 'bank.details.report',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'context': context,
            'target': 'new',
        }
