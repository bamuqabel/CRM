# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _


class SendPayslipMail(models.TransientModel):
    _name = "send.payslip.mail"
    _description = "Send Payslip Mail"

    employee_ids = fields.Many2many('hr.employee', string='Employee')
    email_notified = fields.Boolean('Email', default=False)

    def send_payslip(self):
        payslip_ids = self.env['hr.payslip'].browse(self._context.get('active_ids'))

        send_payslip = payslip_ids.filtered(lambda payslip: payslip.state == 'done' and payslip.employee_id.work_email).mapped(lambda payslip: payslip and payslip.send_payslip())
        email_payslip_ids = payslip_ids.filtered(lambda payslip: not payslip.employee_id.work_email)#payslip.state == 'draft' or
        for payslip in email_payslip_ids:
            if not payslip.employee_id.work_email and payslip.employee_id.id not in self.employee_ids.ids:
                self.employee_ids = [(4, payslip.employee_id.id)]
        if email_payslip_ids:
            self.email_notified = True
            return self.return_wiz_action(self.id)
        else:
            return True

    def return_wiz_action(self, res_id, context=None):
        """
            Return Admin Reports
        """
        return {
            'name': _("Send Payslip Mail"),
            'view_mode': 'form',
            'view_type': 'form',
            'res_model': 'send.payslip.mail',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': context,
            'res_id': res_id,
        }