# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import company_payslip_report
from . import bank_details_report
from . import send_payslip_mail
