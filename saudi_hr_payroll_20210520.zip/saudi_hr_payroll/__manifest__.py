# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': "Middle East Human Resource Payroll",
    'summary': """ Middle East Human Resource Payroll """,
    'description': """ Middle East Human Resource Payroll """,
    'author': 'Synconics Technologies Pvt. Ltd.',
    'website': 'http://www.synconics.com',
    'category': 'Human Resources',
    'version': '1.0',
    'license': 'OPL-1',
    'sequence': 20,
    'depends': [
        'hr_payroll_account',
        'hr_expense_payment',
        'saudi_hr_contract',
        'saudi_hr_leaves_management',
        'res_documents',
    ],
    'data': [
        'security/ir.model.access.csv',
        'security/payroll_security.xml',
        'data/hr_payroll_data.xml',
        'security/ir_rule.xml',
        'views/salary_structure_view.xml',
        'views/other_hr_payslip.xml',
        'views/hr_payroll_view.xml',
        'views/hr_payslip_export_view.xml',
        'views/hr_payslip_run_view.xml',
        'wizard/bank_details_report_view.xml',
        'views/res_config_setting_view.xml',
        'wizard/send_payslip_mail_view.xml',
        'data/send_payslip_template.xml',
        'wizard/company_payslip_report_view.xml',
        'menu.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        # 'demo/hr_employee_demo.xml'
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
