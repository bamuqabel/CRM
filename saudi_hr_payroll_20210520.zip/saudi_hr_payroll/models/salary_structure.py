# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import api, fields, models, _


class HrPayrollStructure(models.Model):
    _inherit = 'hr.payroll.structure'

    use_all_day_lines = fields.Boolean('Use All Day Lines', help='All days display and computed in payslip')

    @api.onchange('use_worked_day_lines')
    def onchange_use_worked_day_lines(self):
        if not self.use_worked_day_lines:
            self.use_all_day_lines = False

    @api.onchange('use_all_day_lines')
    def onchange_use_all_day_lines(self):
        if self.use_all_day_lines:
            self.use_worked_day_lines = True

    def action_update_rule(self):
        if self.use_worked_day_lines:
            for rule in self.rule_ids.search([('code', 'in', ['BASIC', 'GROSS', 'NET']), ('struct_id', '=', self.id)]):
                if self.use_all_day_lines:
                    if rule.code == 'BASIC' and rule.amount_python_compute:
                        rule.amount_python_compute = 'result = (contract.wage * payslip.payment_days)/30'
                    elif rule.code == 'GROSS' and rule.amount_python_compute:
                        rule.amount_python_compute = 'result = categories.BASIC + categories.HRA + categories.TA + categories.OTHER'
                else:
                    if rule.code == 'BASIC' and rule.amount_python_compute:
                        rule.amount_python_compute = 'result = payslip.paid_amount'
                    elif rule.code == 'GROSS' and rule.amount_python_compute:
                        rule.amount_python_compute = 'result = categories.BASIC + categories.ALW'