# Copyright 2017-2018 Tecnativa - Pedro M. Baeza
# Copyright 2018 Brainbean Apps
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from datetime import datetime, time
from odoo import models, fields, api, _

class ProductTemplate(models.Model):
	_inherit = "product.template"

	gender = fields.Boolean(stirng="gender", default=False)
	age = fields.Boolean(stirng="Age", default=False)
	CV = fields.Boolean(stirng="CV", default=False)
	region = fields.Boolean(stirng="Region", default=False)
	level_of_education = fields.Boolean(stirng="Level Of Education", default=False)
	city = fields.Boolean(stirng="City", default=False)
	work_experiance = fields.Boolean(stirng="Work Experiance", default=False)
	grocery_owner = fields.Boolean(stirng="Gricery Owner", default=False)
	national_id = fields.Boolean(stirng="Nationa ID", default=False)
	national_document = fields.Boolean(stirng="Nationa Document", default=False)
	commercial_document = fields.Boolean(stirng="Commercial Record", default=False)
	refcode = fields.Boolean(stirng="Registration App Reference", default=False)
	entrepreneur = fields.Boolean(stirng="New Entrepreneur", default=False)
	job_position = fields.Boolean(string="Job Position", default=False)
	address = fields.Boolean(string="Address", default=False)

	product_academy_id = fields.Many2one('ils.academy', stirng="Academy")