# Copyright 2017-2018 Tecnativa - Pedro M. Baeza
# Copyright 2018 Brainbean Apps
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from datetime import datetime, time
from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'res.partner'

    gender = fields.Selection([
            ('male', 'Male'),
            ('female', 'Female')], stirng="Gender")
    age = fields.Integer(string="Age")
    region = fields.Char(string="Region")
    level_of_education = fields.Char(stirng="Level of Education")
    work_experiance = fields.Char(string="Previous Work Experiance")
    grocery_owner = fields.Selection([('yes','Yes'),('no','No')])
    refcode = fields.Char(stirng="Registration App Reference")
    is_new_entrepreneur = fields.Selection([('yes','Yes'),('no','No')], string="Is New Entrepreneur ?")
    job_position = fields.Char(string="Job Position")
    address = fields.Char(string="Address")


class EventTicket(models.Model):
    _inherit = 'event.event.ticket'

    product_id = fields.Many2one('product.product', string='Product',
        required=True, domain=[("event_ok", "=", True)])