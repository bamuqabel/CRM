# -*- coding: utf-8 -*-
{
    'name': "student Information System Custom event module",
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'website', 'event_sale', 'event','ils_ui'],

    # always loaded
    'data': [
        'views/event_registration_view.xml',
        'views/template.xml',
        'views/product_template.xml',
    ]
}
