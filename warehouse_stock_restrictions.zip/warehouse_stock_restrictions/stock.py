# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import Warning


class ResUsers(models.Model):
    _inherit = 'res.users'

    restrict_locations = fields.Boolean('Restrict Location')

    stock_location_ids = fields.Many2many(
        'stock.location',
        'location_security_stock_location_users',
        'user_id',
        'location_id',
        'Stock Locations')

    stock_location_report_ids = fields.Many2many(
        'stock.location',
        'location_security_stock_location_report_users',
        'user_id',
        'location_id',
        'Stock Locations')

    default_picking_type_ids = fields.Many2many(
        'stock.picking.type', 'stock_picking_type_users_rel',
        'user_id', 'picking_type_id', string='Default Warehouse Operations')


class stock_move(models.Model):
    _inherit = 'stock.move'

    @api.constrains('state', 'location_id', 'location_dest_id')
    def check_user_location_rights(self):
        for stock in self:
            if stock.state == 'draft':
               print('assssssssssss')
               return True
            user_locations = self.env.user.stock_location_ids
            print(user_locations)
            print("Checking access %s" %self.env.user.default_picking_type_ids)
            if self.env.user.restrict_locations:
                message = _(
                    'Invalid Location. You cannot process this move since you do '
                    'not control the location "%s". '
                    'Please contact your Adminstrator.')
                if stock.location_id not in user_locations:
                    raise Warning(message % self.location_id.name)

                elif stock.location_dest_id not in user_locations:
                    raise Warning(message % stock.location_dest_id.name)



class stock_move_line(models.Model):
    _inherit = 'stock.move.line'

    to_usage = fields.Selection(related='location_id.usage')
    from_usage = fields.Selection(related='location_dest_id.usage')