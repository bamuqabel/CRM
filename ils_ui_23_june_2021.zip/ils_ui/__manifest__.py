# -*- coding: utf-8 -*-
{
    'name': "Student Information System (SIS)",

    'summary': """
    """,

    'author': "Innovative Leading Solutions organization",
    'website': "https://www.ils.com.sa/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'contacts', 'stock'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/student.xml',
        'wizard/ils_timesheet_date.xml',
        'wizard/ils_batch_group_confirmation.xml',
        'wizard/ils_timesheet_filter_view.xml',
        'views/assets.xml',
        'views/ir_cron.xml',
        'views/academy.xml',
        'views/product_template_views.xml',
        'views/batch.xml',
        'views/enrollment.xml',
        'views/education.xml',
        'views/employer.xml',
        'views/employment.xml',
        'views/admission_checklist.xml',
        'views/res_partner.xml',
        'views/student.xml',
        'views/sponsor.xml',
        'views/semester_view.xml',
        'views/modules_view.xml',
        'views/room_view.xml',
        'views/teacher_view.xml',
        'views/timetable_view.xml',
        'views/enrollment_student_group.xml',
        'report/timesheet_report.xml',
    ],
    'qweb': [
        'static/src/xml/batch_timesheet.xml'
    ],
    # only loaded in demonstration mode
    'demo': [],
}
