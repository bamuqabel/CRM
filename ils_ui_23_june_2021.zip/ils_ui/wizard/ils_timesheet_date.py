
import datetime
from odoo import api, fields, models


class ilsTimesheetDates(models.TransientModel):
    _name = 'ils.timsheet.dates'
    _description = 'ILS Timesheet Dates'

    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')
    batch_id = fields.Many2one('ils.batch', string='Batch',)

    @api.model
    def default_get(self, fields):
        res = super(ilsTimesheetDates, self).default_get(fields)
        batch_id = self.env['ils.batch'].browse(self.env.context['active_ids']) if self.env.context and self.env.context.get('active_ids') else False
        res.update({'batch_id': batch_id.id})
        return res