# -*- coding: utf-8 -*-

from odoo import models, fields, api


class EnrollmentStudentGroup(models.Model):
    _name = 'ils.enrollment.student.group'
    _description = 'Enrollment Student Group'

    name = fields.Char(String="Name")
    module_id = fields.Many2one('ils.modules', String="Module")
    batch_id = fields.Many2one('ils.batch', String="Batch")
    room_id = fields.Many2one(comodel_name='ils.room', string="Room")
    enroll_student_ids = fields.Many2many('ils.enrollment', 'enrollment_student_group_rel', 'group_id', 'enrollment_id')
    state = fields.Selection(selection=[('draft','Draft'),('confirm','Confirm')], string='Status')
    teacher_ids = fields.Many2many('ils.teacher', 'teacher_student_group_rel', 'group_id', 'teacher_id')
    semester_id = fields.Many2one('ils.semester')
    
    @api.model
    def create(self, vals):
        res = super(EnrollmentStudentGroup, self).create(vals)
        if res.enroll_student_ids:
            for enrollment in res.enroll_student_ids:
                enrollment.write({
                    'enroll_student_ids': [(4, res.id)]
                    })
        return res

    def write(self, vals):
        if  vals and vals.get('enroll_student_ids'):
            before_enroll_student_ids = self.enroll_student_ids.ids
            res = super(EnrollmentStudentGroup, self).write(vals)
            after_enroll_student_ids = self.enroll_student_ids.ids
            removed_enrollments = list(set(before_enroll_student_ids) - set(after_enroll_student_ids))
            if removed_enrollments:
                for enrollment in self.env['ils.enrollment'].browse(removed_enrollments):
                    sql_query = """DELETE
                                FROM enrollment_group_rel
                                WHERE enrollment_id = """ + str(enrollment.id) + """
                                AND group_id = """ + str(self.id) + """
                                """
                    self.env.cr.execute(sql_query)
        else:
            res = super(EnrollmentStudentGroup, self).write(vals)
        return res