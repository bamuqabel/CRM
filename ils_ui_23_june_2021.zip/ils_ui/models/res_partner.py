# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date


class ResPartnerInhert(models.Model):
    _inherit = 'res.partner'

    contact_type = fields.Selection(selection=[('student','Student'),('sponsor','Sponsor')], string='Contact Type')
    first_name = fields.Char(string='First Name')
    father_name = fields.Char(string='Father Name')
    family_name = fields.Char(string='Family Name')
    student_id = fields.Char(string='Student ID', track_visibility='onchange')
    id_num = fields.Char(string='ID Number')
    passport = fields.Char(string='Passport Number')
    dob = fields.Date(string='Date of Birth')
    gender = fields.Selection(selection=[('male','Male'),('female','Female')], string='Gender')
    high_school_gpa = fields.Float(string='High School GPA', required=True, default=0.00)
    attach = fields.Binary(string='Attachments')
    education = fields.One2many(comodel_name='ils.education', inverse_name='student_id', string='Education')
    employment = fields.One2many(comodel_name='ils.employment', inverse_name='student_id', string='Employment')
    admission_checklist = fields.One2many(comodel_name='ils.admission.checklist', inverse_name='student_id', string='Admission Checklist')
    min_num_of_student = fields.Integer(string='Minmum Number of Student')
    invoice_date = fields.Integer(string='Invoicing Date', size=2)
    enrollment_count = fields.Integer(string='Enrollments', compute='_compute_enroll_count')
    enrollment_student_count = fields.Integer(string='Student Enrollments', compute='_compute_enrollment_student_count')
    student_enrollment = fields.One2many(comodel_name='ils.enrollment', inverse_name='student_id', string='Student Enrollment')

    @api.onchange('first_name')
    def first_name_change(self):
        for record in self:
            if record.first_name and self.father_name and self.family_name:
                self.name = record.first_name + " " + self.father_name + " " + self.family_name
            else:
                self.name = record.first_name

    @api.onchange('father_name')
    def father_name_change(self):
        for record in self:
            if record.father_name and self.first_name and self.family_name:
                self.name = self.first_name + " " + record.father_name + " " + self.family_name
            elif record.father_name and self.first_name:
                self.name = self.first_name + " " + record.father_name

    @api.onchange('family_name')
    def family_name_change(self):
        for record in self:
            if record.family_name and self.first_name and self.first_name:
                self.name = self.first_name + " " + self.father_name + " " + record.family_name

    def _compute_enroll_count(self):
        for record in self:
            record.enrollment_count = self.env['ils.enrollment'].search_count(
                [('student_id', '=', record.id)])

    def _cron_generate_student_id(self):
        student_ids = self.env['res.partner'].search([('student_id', '=', False)])
        current_date = date.today()
        for student_id in student_ids:
            enrollment_id = self.env['ils.enrollment'].search([('student_id', '=', student_id.id)], limit=1)
            if enrollment_id:
                code = str(enrollment_id.academy_id.id) + '_sequence_academy'
                sequence_id = self.env['ir.sequence'].search([('code', '=', code)])
                if not sequence_id:
                    seq_id = self.env['ir.sequence'].create({
                    'name': enrollment_id.academy_id.name + ' Sequence',
                    'code': str(enrollment_id.academy_id.id) + '_sequence_academy',
                    'number_next': 1,
                    'number_increment': 1,
                    'use_date_range': True,
                    'padding': 4})
                sequence = self.env['ir.sequence'].next_by_code(code)
                enrollment_id.student_id.student_id = '%s%s%s%s' % (enrollment_id.academy_id.code.upper(), '{:02d}'.format(current_date.month), current_date.strftime("%y"), sequence)

    def _compute_enrollment_student_count(self):
        for record in self:
            record.enrollment_student_count = self.env['ils.enrollment'].search_count(
                [('sponsor_id', '=', record.id)])

    @api.constrains('invoice_date')
    def check_invoice_date(self):
        for record in self:
            if record.invoice_date > 31:
                raise ValidationError('Invoicing Date Can Not > 31')

    # get value for admission_checklist
    @api.model
    def default_get(self, fields):
        res = super(ResPartnerInhert, self).default_get(fields)
        a_checklist_lines = [(5,0,0)]
        a_checklist_rec = self.env['ils.admission.checklist.static'].search([])
        for a_checklist in a_checklist_rec:
            line = (0, 0, {
                'doc': a_checklist.doc,
                'requirement': a_checklist.requirement,
                'status': a_checklist.status,
                'comments': a_checklist.comments,
                'attachment': a_checklist.attachment,
            })
            a_checklist_lines.append(line)
            res.update({
                'admission_checklist': a_checklist_lines
            })
        return res