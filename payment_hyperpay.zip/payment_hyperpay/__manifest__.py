# -*- coding: utf-8 -*-

{
  "name"                 :  "Hyperpay Payment Acquirer",
  "category"             :  "Website",
  "version"              :  "1.0.0",
  "sequence"             :  1,
  "author"               :  "Rightechs Solutions, WSP.",
  "website"              :  "https://www.rightechs.info",
  "description"          :  "Hyperpay Payment Gateway",
  "depends"              :  [
                             'payment',
                             'website_sale',
                            ],
  "data"                 :  [
                             'views/payment_views.xml',
                             'views/payment_hyperpay_templates.xml',
                             'views/website_assets.xml',
                             'data/payment_acquirer_data.xml',
                            ],
  "demo"                 :  [],
  "images"               :  ['static/description/Banner.png'],
  "application"          :  True,
  "installable"          :  True,
  "price"                :  99.0,
  "currency"             :  "EUR",
  "post_init_hook"       :  "create_missing_journal_for_acquirers",
}