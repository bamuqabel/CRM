odoo.define('payment_hyperpay.payment_hyperpay', function (require) {
      "use strict";

      var core = require('web.core');
      var Dialog = require('web.Dialog');
      var publicWidget = require('web.public.widget');
      var ajax = require('web.ajax');

      var qweb = core.qweb;
      var _t = core._t;

      if ($.blockUI) {
        $.blockUI.defaults.css.border = '0';
        $.blockUI.defaults.css["background-color"] = '';
        $.blockUI.defaults.overlayCSS["opacity"] = '0.5';
        $.blockUI.defaults.overlayCSS["z-index"] = '1050';
    }

      var HyperpayPaymentForm = publicWidget.Widget.extend({
      init: function() {
            this.tx_id = $('#hyperpay_tx').val();
            this._initBlockUI(_t("Loading..."));
            this.start();
        },
      start: function() {
            var self = this;
            self._createHyperpayCheckoutId();
        },
      _createHyperpayCheckoutId: function() {
            var self = this;
            ajax.jsonRpc('/payment/hyperpay/checkout/create', 'call', {
                'txId': self.tx_id
            })
            .then(function (result) {
                if (result) {
                    self._renderHyperpayModal(result.checkoutId, result.domain, result.base_url);
                } else {
                      console.log('Error Occured');
                }
            });
        },
      _renderHyperpayModal: function(checkoutId, domain, base_url) {
           var self = this;
           return ajax.loadXML('/payment_hyperpay/static/src/xml/hyperpay.xml', qweb).then(function() {
                 var $modal_html = $(qweb.render('payment_hyperpay.modal'));
                 $modal_html.appendTo($('body')).modal({keyboard: false, backdrop: 'static'});
                 var style_css = '<link rel="stylesheet" href="/payment_hyperpay/static/src/css/hyperpay_style.css" />'
                 var script = '<script src="'+domain+'/v1/paymentWidgets.js?checkoutId='+checkoutId+'"></script>'
                 var hyperpay_script = '<script src="/payment_hyperpay/static/src/js/hyperpay.js"></script>'
                 var shopperResultUrlTag = '<form action="'+base_url+'/payment/hyperpay/result" class="paymentWidgets" data-brands="VISA MASTER AMEX"></form>'
                 var theIframe = document.createElement("iframe");
                 theIframe.id = "hyperpay_iframe";
                 theIframe.style = "display:none";
                 theIframe.src = "/";
                 theIframe.srcdoc = style_css + '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>'+ script + hyperpay_script + shopperResultUrlTag;
                 $('#hyperpay-modal-body')[0].appendChild(theIframe);

           }).catch(function (err) {
                    console.log('component error:', err);
            });

        },
        _initBlockUI: function(message) {
            if ($.blockUI) {
                $.blockUI({
                    'message': '<h2 class="text-white"><img src="/web/static/src/img/spin.png" class="fa-pulse"/>' +
                            '    <br />' + message +
                            '</h2>'
                });
            }
            $("#o_payment_form_pay").attr('disabled', 'disabled');
        },

      });

      new HyperpayPaymentForm();

});
