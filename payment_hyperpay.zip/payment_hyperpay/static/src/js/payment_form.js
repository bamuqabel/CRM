// odoo.define('payment_hyperpay.test', function (require) {
//       "use strict";
//
//       var PaymentForm = require('payment.payment_form');
//       var ajax = require('web.ajax');
//
//       PaymentForm.include({
//
//       /**
//      * @override
//      */
//       payEvent: function(ev){
//             var $checkedRadio = this.$('input[type="radio"]:checked');
//             if ($checkedRadio.length === 1) {
//                   console.log("got one");
//                   var provider = $checkedRadio.data('provider');
//                   if (provider === 'hyperpay') {
//                         $('#o_payment_form_pay').attr('disabled', true);
//                       }
//               }
//             return this._super.apply(this, arguments);
//       },
//       /**
//       *@override
//       */
//       // radioClickEvent: function(ev) {
//       //       var res = this._super.apply(this, arguments);
//       //       $(document).ready(function(){
//       //       var txId = $('#hyperpay_tx');
//       //       if (txId.length !== 0){
//       //             var txId_val = txId.val();
//       //             ajax.jsonRpc("/payment/hyperpay/checkout/create",'call',{'txId':txId_val}).then(function(response){
//       //                   var theIframe = document.createElement("iframe");
//       //                   theIframe.id = "hyperpay_iframe";
//       //                   theIframe.style = "width:100%; height:21em; border:none;"
//       //                   theIframe.srcdoc = response['style_css'] + response['scriptTag'] + response['shopperResultUrlTag'];
//       //                   $('.hyperpay_loader').remove();
//       //                   $('#hyperpay_payment_acq')[0].appendChild(theIframe);
//       //             });
//       //       }
//       // });
//       //       return res;
//       // },
//
//       /**
//      * @override
//      */
//       //  updateNewPaymentDisplayStatus: function () {
//       //       var $checkedRadio = this.$('input[type="radio"]:checked');
//       //       if ($checkedRadio.length !== 1) {
//       //           return;
//       //       }
//       //       var provider = $checkedRadio.data('provider');
//       //       if (provider === 'hyperpay') {
//       //             $('#hyperpay_payment_acq').removeClass('d-none');
//       //             $('#o_payment_form_pay').click();
//       //             $('#o_payment_form_pay').css('display','none');
//       //     }else{
//       //           $('form[provider="hyperpay"]').remove();
//       //           $('#hyperpay_iframe').remove();
//       //           $('#o_payment_form_pay').css('display','');
//       //           if(!$('#hyperpay_payment_acq').hasClass('d-none')){
//       //                 $('#hyperpay_payment_acq').addClass('d-none');
//       //                 location.reload(true);
//       //           }
//       //           // location.reload(true);
//       //     }
//       //       return this._super.apply(this, arguments);
//       //    }
//       });
//
// });
