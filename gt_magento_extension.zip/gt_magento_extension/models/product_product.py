# -*- coding: utf-8 -*-
###############################################################################
#                                                                             #
#    Globalteckz                                                              #
#    Copyright (C) 2013-Today Globalteckz (http://www.globalteckz.com)        #
#                                                                             #
#    This program is free software: you can redistribute it and/or modify     #
#    it under the terms of the GNU Affero General Public License as           #
#    published by the Free Software Foundation, either version 3 of the       #
#    License, or (at your option) any later version.                          #
#                                                                             #
#    This program is distributed in the hope that it will be useful,          #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of           #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            #
#    GNU Affero General Public License for more details.                      #
#                                                                             #
#    You should have received a copy of the GNU Affero General Public License #
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.    #
#                                                                             #   
###############################################################################

from odoo import models, fields, api,_
import requests
import json
import os
import io
import base64
import time
from odoo.exceptions import UserError
import logging
logger = logging.getLogger('product')

class GtMagentoStore(models.Model):
    _inherit= 'gt.magento.store'
    _description = 'Magento Store'


    def GtImportMagentoCarrier(self):
        # try:
        self.magento_instance_id.generate_token()
        token = self.magento_instance_id.token
        token = token.replace('"', " ")
        auth_token = "Bearer " + token.strip()
        auth_token = auth_token.replace("'", '"')
        headers = {
            'authorization': auth_token
        }
        url = str(
            self.magento_instance_id.location) + "/rest/V1/shipments?searchCriteria[filterGroups][0][filters][0][field]=store_id& searchCriteria[filterGroups][0][filters][0][value]=%s& searchCriteria[filterGroups][0][filters][0][conditionType]=eq" % (
              self.store_id,)
        response = requests.request("GET", url, headers=headers)
        items = response.json().get("items")
        print("items+++++++++++++++", items)
        print("no of pick", len(items))
        if items:
            for shipment_list in items:
                if shipment_list.get('tracks'):
                    for carrier_id in shipment_list.get('tracks'):
                        product_id = self.env['product.product'].search([('name','=',carrier_id['title']),('type','=','service')])
                        if not product_id:
                            carrier_product_id=self.env['product.product'].create({'name':carrier_id['title'],'type':'service'})
                        print("carrier_id['title']===",carrier_id['title'])
                        delivery_id =self.env['delivery.carrier'].search([('name', '=', carrier_id['title'])])
                        if not delivery_id:
                            self.env['delivery.carrier'].create({'name':carrier_id['title'],'product_id':carrier_product_id.id,'magento_code':carrier_id['carrier_code']})
        return True



class GtMagentoInstance(models.Model):
    _inherit='gt.magento.instance'
    _description = "GT Magento Instance"
    _rec_name = "name"




    def GtImportMagentoSimpleProduct(self):
        print("self.from_id===",self.from_id)
        product_obj = self.env['product.product']
        store_obj = self.env['gt.magento.store']
        website_obj = self.env['gt.magento.website']
        self.generate_token()
        token=self.token
        token=token.replace('"'," ")
        auth_token="Bearer "+token.strip()
        auth_token=auth_token.replace("'",'"')
        headers = {
            'authorization':auth_token,
            'content-type': "application/json",
            'cache-control': "no-cache",
            }
        url=str(self.location)+"/rest/V1/products?searchCriteria[filterGroups][0][filters][0][field]=type_id& searchCriteria[filterGroups][0][filters][0][value]=simple& searchCriteria[filterGroups][0][filters][0][conditionType]=eq&searchCriteria[filterGroups][1][filters][0][field]=entity_id&searchCriteria[filterGroups][1][filters][0][value]="+str(self.from_id)+"&searchCriteria[filterGroups][1][filters][0][conditionType]=gteq"
        response = requests.request("GET",url, headers=headers)
        print ("url++++++++",url)
        response = requests.request("GET",url, headers=headers,)
        print ("response+++++++++",response)
        # print ("json.loads(response.text)+++++++++",json.loads(response.text))
        product_list=json.loads(response.text)
        # print ("product_list+++++++++",product_list)
        print ("create_simple_products+++++++111",requests.session().close())
        print ("product_list['items']_______product_list['items']_________",product_list['items'])
        for products in product_list['items']:
            print("=====products======",products)
            print("=====sku======",str(products['sku']))
            if '/' in str(products['sku']):
                prod_sku =products['sku'].replace('/','%2F')
                url = str(self.location) + "/rest/V1/products/"+prod_sku
            else:
                url=str(self.location)+"/rest/V1/products/"+str(products['sku'])
                print("else----url====",url)
            response = requests.request("GET",url, headers=headers)
            print("response====",response)
            each_product=json.loads(response.text)
            print("each_product===",each_product)
            print("create_simple_products+++++++2222", requests.session().close())
            # print("each_product+++++++2222",each_product)
            for attributes in each_product.get('custom_attributes'):
                if attributes.get('attribute_code') == 'website_ids':
                    for website in attributes.get('value'):
                        website_id = website_obj.search([('website_id','=',website),('magento_instance_id','=',self.id)])
                        store_ids = store_obj.search([('website_id','=',website_id.id),('magento_instance_id','=',self.id)])
                        for store_id in store_ids:
                            product_obj.create_simple_products(self,headers,products['sku'],store_id,website_id)
        return True

    def GtImportMagentoConfigurableProduct(self):
        product_obj = self.env['product.product']
        store_obj = self.env['gt.magento.store']
        website_obj = self.env['gt.magento.website']
        self.generate_token()
        token=self.token
        token=token.replace('"'," ")
        auth_token="Bearer "+token.strip()
        auth_token=auth_token.replace("'",'"')
        headers = {
            'authorization':auth_token,
            'content-type': "application/json",
            'cache-control': "no-cache",
            }
        url=str(self.location)+"/rest/V1/products?searchCriteria[filterGroups][0][filters][0][field]=type_id& searchCriteria[filterGroups][0][filters][0][value]=configurable& searchCriteria[filterGroups][0][filters][0][conditionType]=eq&searchCriteria[filterGroups][1][filters][0][field]=entity_id&searchCriteria[filterGroups][1][filters][0][value]="+str(self.config_prod_from_id)+"&searchCriteria[filterGroups][1][filters][0][conditionType]=gteq"
        response = requests.request("GET",url, headers=headers, stream=True)
        print("response====",response)
        product_list=json.loads(response.text)
        print("product_list['items']===",product_list['items'])
        for products in product_list['items']:
            url=str(self.location)+"/rest/V1/products/"+str(products['sku'])
            response = requests.request("GET",url, headers=headers, stream=True)
            each_product=json.loads(response.text)
#            print ("each_product.get('custom_attributes')+",each_product)
#            print ("each_product.get('custom_attributes')+",each_product.get('extension_attributes'))
#            print ("website_iddddssssss",each_product.get('extension_attributes').get('website_ids'))
#             if 'extension_attributes' in each_product:
#                 extenstion_attributes = each_product.get('extension_attributes')
#                 print ("extenstion_attributes++++++=",extenstion_attributes)
#                 if 'website_ids' in extenstion_attributes:
#                     website_ids = extenstion_attributes.get('website_ids')
#                     print ("website_ids++++++++",website_ids)
            for attributes in each_product.get('custom_attributes'):
                print ("attributes+++++++++++++",attributes)
                if attributes.get('attribute_code') == 'website_ids':
                    for website_id in attributes.get('value'):
                        print ("website_id++++++++++",website_id)
                        website_id = website_obj.search([('website_id','=',website_id),('magento_instance_id','=',self.id)])
                        store_ids = store_obj.search([('website_id','=',website_id.id),('magento_instance_id','=',self.id)])
                        for store_id in store_ids:
                            product_obj.create_configurable_magento_products(self,headers,products['sku'],store_id,website_id)
            self._cr.commit()
        return True

class ProductProduct(models.Model):
    _inherit='product.product'


    def create_configurable_magento_products(self,instance,headers,sku,store_id,website_id):
        attribute_obj =self.env['gt.product.attributes']
        att_set_obj=self.env['gt.product.attribute.set']
        prod_att_option_obj=self.env['gt.product.attribute.options']
        prod_att_obj = self.env['product.attribute']
        prod_att_val_obj = self.env['product.attribute.value']
        prod_temp_att_val_obj = self.env['product.template.attribute.value']
        prod_tmp_obj = self.env['product.template']
        url=str(instance.location)+"/rest/"+str(store_id.code)+"/V1/products/"+str(sku)
        response = requests.request("GET",url, headers=headers)
        each_product=json.loads(response.text)
        attributes =[]
        variant_list = []
        attribute_values={}
        attributes_name = []
        instance_ids = []
        product_id=prod_tmp_obj.search([('magento_sku','=',str(sku))])
        if not product_id:
            if each_product.get('extension_attributes',False):
                if each_product['extension_attributes'].get('configurable_product_options',False):
                    for option in each_product['extension_attributes'].get('configurable_product_options'):
                        attribute_mag_ids = attribute_obj.search([('magento_id','=',option.get('attribute_id')),('referential_id','=',instance.id)])
                        print ("attribute_mag_ids+++++++++++++++++",attribute_mag_ids)
                        print ("option.get('attribute_id')+9++++++",option.get('attribute_id'))
                        if attribute_mag_ids:
                            attribute_ids = prod_att_obj.search([('name','=',attribute_mag_ids.attribute_code)])
                            print ("attribute_ids++++++++++++++",attribute_ids)
                            if attribute_ids:
                                print ("attribute_ids++++++++++",attribute_ids)
                                attribute = attribute_ids[0]
                            else:
                                attribute = prod_att_obj.create({'name':attribute_mag_ids.attribute_code,'create_variant':'always'})
                                print ("attributes++++++++++++++++",attribute)
                        # print ("attribute+++++++++++++++++",attribute_ids)
                        if attribute.id not in attributes:
                            attributes.append(attribute.id)
                            attributes_name.append(attribute.name)
                        for values in option.get('values'):
                            prod_opt_ids = prod_att_option_obj.search([('value','=',values.get('value_index')),('referential_id','=',instance.id)])
                            if prod_opt_ids:
                                mage_val_id =  prod_opt_ids[0]
                            else:
                                print ("empty attributes meansa attributes not imported before"),

                            att_value_ids = prod_att_val_obj.search([('name','=',mage_val_id.label),('attribute_id','=',attribute.id)])
                            if not att_value_ids:
                                attribute_val_id = prod_att_val_obj.create({'attribute_id':attribute.id, 'name':prod_opt_ids[0].label})
                            else:
                                attribute_val_id = att_value_ids[0]
                            if attribute_values.get(attribute.id, False):
                                attribute_values.get(attribute.id).append(attribute_val_id.id)
                            else:
                                attribute_values.update({attribute.id: [attribute_val_id.id]})
            if attributes:
                for att_line in attribute_values.keys():
                    variant_list.append((0,0,{'attribute_id':att_line,'value_ids':[(6, 0, attribute_values.get(att_line))]}))
            if len(self.magento_instance_ids) > 0:
                for old_instance_id in self.magento_instance_ids:
                    instance_ids.append(old_instance_id.id)
            if instance.id not in instance_ids:
                instance_ids.append(instance.id)
            product_tmp_vals={  'default_code':str(sku),
                                'name':str(each_product.get('name')),
                                'lst_price':each_product.get('price'),
                                'magento_id':str(each_product.get('id')),
                                'attribute_line_ids':variant_list or False,
                                'type':'product',
                                'magento_template':True,
                                'magento_exported':True,
                                'magento_sku': str(sku),
                                'magento_instance_ids':[(6,0,instance_ids)]
                             }
            product_tmp_ids = prod_tmp_obj.search([('default_code','=',str(sku))])
            print ("product_tmp_id++++++++finding product in system",product_tmp_ids)
            if not product_tmp_ids:
                product_tmp_id = prod_tmp_obj.create(product_tmp_vals)
                print ("product_tmp_id++++++product created in system",product_tmp_id)
            else:
                product_tmp_id = product_tmp_ids
                print ("product_tmp_id++++++product available in system",product_tmp_id)
            # self._cr.commit()
            url=instance.location+"/rest/V1/configurable-products/"+str(product_tmp_id.magento_sku)+"/children" 
            response = requests.request("GET",url, headers=headers)
            child_product_list=json.loads(response.text)
            for child_product in child_product_list:
                value_id_list = []
                for att_name in attributes_name:
                    print ("att_name_+++++++",att_name)
                    for child in child_product.get('custom_attributes'):
                        print ("child++++++++",child)
                        if child.get('attribute_code') == att_name:
                            print ("child.get('attribute_code')+++++++",child.get('attribute_code'))
                            attribute_idss = prod_att_obj.search([('name','=',child.get('attribute_code'))])
                            print ("attribute_idss_+++++++++",attribute_idss)
                            if attribute_idss:
                                print ("attribute_idss+++++++++",attribute_idss)
                                print ("child.get('value')+++++",child.get('value'))
                                value_id = prod_att_option_obj.search([('value','=',child.get('value')),('attribute_name','=',child.get('attribute_code')),('referential_id','=',instance.id)])
                                print ("value_id++++++++++",value_id)
                                if value_id:
                                    att_value_idss = prod_temp_att_val_obj.search([('name','=',str(value_id.label)),('attribute_id','=',attribute_idss.id),('product_tmpl_id','=',product_tmp_id.id)])
                                    print ("att_value_idss+++++++++",att_value_idss)
                                    if att_value_idss:
                                        value_id_list.append(att_value_idss.id)
                product_product = self.search([('magento_id','=',str(each_product.get('id')))])
                print ("product_product+++++++",product_product)
                if product_product:
                    for product_ids in product_product:
                        attribute_list = []
                        for att_idss in product_ids.product_template_attribute_value_ids:
                            print ("att_idss+++++++++",att_idss,att_idss.name)
                            attribute_list.append(att_idss.id)
                        print ("attribute_list___++++++",attribute_list)
                        print ("value_id_list_________",value_id_list)
                        if sorted(attribute_list, key=int) == sorted(value_id_list, key=int):
                            print ("updating variant")
                            product_ids.update_variant(child_product['sku'],instance,product_ids,headers,store_id,website_id)
                    # self._cr.commit()
        else:
            if each_product['extension_attributes'].get('configurable_product_links',False):
                for option in each_product['extension_attributes'].get('configurable_product_links'):
                    product_id = self.search([('magento_id','=',str(option))])
                    if product_id:
                        product_id.update_variant(product_id.default_code,instance,product_id,headers,store_id,website_id)
        instance.write({'config_prod_from_id': str(each_product.get('id'))})
        print("config___product______id____________",instance.config_prod_from_id,str(each_product.get('id')))
        self._cr.commit()                  
        return True

    def create_simple_products(self,instance,headers,sku,store_id,website_id):
        multi_instance = self.env['gt.magento.product.multi']
        attribute_obj = self.env['gt.product.attributes']
        product_obj = self.env['product.product']
        prod_att_option_obj = self.env['gt.product.attribute.options']
        categ_id = []
        line_categ = []
        store_ids = []
        website_ids = []
        instance_ids = []
        car_model = []
        car_make = []
        os_ver = []
        internal_memory = []
        processor_core = []
        processor_model = []
        blutooth = []
        steering = []
        video_in = []
        video_out = []
        audio_inp = []
        audio_out = []
        sd_card_slot = []
        mobile_mirror = []
        support_camera = []
        support_obd = []
        suport = []
        canbus = []
        prospeed = []
        wifi = []
        navigate = []
        warranty_year = []
        os = []
        scr_size = []
        screen_resolution = []
        ram = []
        ext_mry_support = []
        dvd_player = []
        usb_port = []
        radio = []
        stu_yr=[]
        rm_model=[]
        sim_model=[]
        com_acces=[]
        prod_desc_eng=[]
        prod_desc_arab=[]
        attach = []
        att_set_obj = self.env['gt.product.attribute.set']
        if '/' in str(sku):
            prod_sku = str(sku).replace('/', '%2F')
            print("prod_sku====", prod_sku)
            url= str(instance.location) + "/rest/" + str(store_id.code) + "/V1/products/" + prod_sku
            print("url====",url)
        else:
            url=str(instance.location)+"/rest/"+str(store_id.code)+"/V1/products/" + str(sku)
            print("url====",url)
        response = requests.request("GET",url, headers=headers)
        each_product=json.loads(response.text)
        # print ("create_simple_products+++++++",response.close())
        att_ids=att_set_obj.search([('code','=',each_product.get('attribute_set_id')),('magento_instance_id','=',instance.id)])
        if len(self.store_ids) > 0:
            for old_store_id in self.store_ids:
                store_ids.append(old_store_id)
        if len(self.website_ids) > 0:
            for old_website_id in self.website_ids:
                website_ids.append(old_website_id)
        if len(self.magento_instance_ids) > 0:
            for old_instance_id in self.magento_instance_ids:
                instance_ids.append(old_instance_id.id)
        if store_id.id not in store_ids:
            store_ids.append(store_id.id)
        if website_id.id not in website_ids:
            website_ids.append(website_id.id)
        if instance.id not in instance_ids:
            instance_ids.append(instance.id)
        if att_ids:
            att_id=att_ids.id
        else:
            att_id=False
        print("each_product__________",each_product)
        for attributes_child in each_product.get('custom_attributes'):
            if attributes_child['attribute_code']=='category_ids':
                categ_id = attributes_child['value']
                for each_category in categ_id:
                    prod_cat_obj=self.env['product.category']
                    cat_ids=prod_cat_obj.search([('magento_id','=',each_category),('magento_instance_id','=',instance.id),('shop_id','=',store_id.id)])
                    if cat_ids:
                        line_categ.append(cat_ids.id)

            # for extra fields

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'suitable_car_make'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'suitable_car_make':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                car_make_ids = self.env['car.make'].search([('name', '=', option_id.label)])
                print("car_make_ids====",car_make_ids)
                car_make.append(car_make_ids.id)
                if not car_make_ids:
                    car_make_ids = self.env['car.make'].create({'name': option_id.label or ''})
                    print("car_make_ids====1111",car_make_ids)
                    car_make.append(car_make_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'suitable_car'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'suitable_car':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                car_model_ids = self.env['car.model'].search([('name', '=', option_id.label)])
                car_model.append(car_model_ids.id)
                if not car_model_ids:
                    car_model_ids = self.env['car.model'].create({'name': option_id.label or ''})
                    print("car_model_ids===",car_model_ids.name)
                    car_model.append(car_model_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'suitable_year'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'suitable_year':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value':attributes_child['value'],'label': attributes_child['value'],'attribute_id':status_id.id,
                         'referential_id':instance.id})
                stu_yr_ids = self.env['suitable.years'].search([('name', '=', option_id.label)])
                stu_yr.append(stu_yr_ids.id)
                if not stu_yr_ids:
                    stu_yr_ids = self.env['suitable.years'].create({'name': option_id.label or ''})
                    stu_yr.append(stu_yr_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'wifi'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'wifi':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                wifi_ids = self.env['wifi'].search([('name', '=', option_id.label)])
                wifi.append(wifi_ids.id)
                if not wifi_ids:
                    wifi_ids = self.env['wifi'].create({'name': option_id.label or ''})
                    wifi.append(wifi_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'gps'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'gps':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                navi_gation_ids = self.env['navi.gation'].search([('name', '=', option_id.label)])
                navigate.append(navi_gation_ids.id)
                if not navi_gation_ids:
                    navi_gation_ids = self.env['navi.gation'].create({'name': option_id.label or ''})
                    navigate.append(navi_gation_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'description'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'description':
                description_eng = attributes_child['value']


            status_id = attribute_obj.search(
                [('attribute_code', '=', 'warranty'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'warranty':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====",option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                warranty_year_ids = self.env['warranty.years'].search([('name', '=', option_id.label)])
                warranty_year.append(warranty_year_ids.id)
                if not warranty_year_ids:
                    warranty_year_ids =self.env['warranty.years'].create({'name':option_id.label or ''})
                    warranty_year.append(warranty_year_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'operating_system'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'operating_system':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                os_ids = self.env['operating.system'].search([('name', '=', option_id.label)])
                os.append(os_ids.id)
                if not os_ids:
                    os_ids = self.env['operating.system'].create({'name': option_id.label or ''})
                    os.append(os_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'operating_system_version'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'operating_system_version':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                os_ver_ids = self.env['os.version'].search([('name', '=', option_id.label)])
                os_ver.append(os_ver_ids.id)
                if not os_ver_ids:
                    os_ver_ids = self.env['os.version'].create({'name': option_id.label or ''})
                    os_ver.append(os_ver_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'screen_size'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'screen_size':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'], 'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                scr_size_ids = self.env['screen.size'].search([('name', '=', option_id.label)])
                scr_size.append(scr_size_ids.id)
                if not scr_size_ids:
                    scr_size_ids = self.env['screen.size'].create({'name': option_id.label or ''})
                    scr_size.append(scr_size_ids.id)
            #
            status_id = attribute_obj.search(
                [('attribute_code', '=', 'tft_resolution'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'tft_resolution':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                screen_resolution_ids = self.env['screen.resolution'].search([('name', '=', option_id.label)])
                screen_resolution.append(screen_resolution_ids.id)
                if not screen_resolution_ids:
                    screen_resolution_ids = self.env['screen.resolution'].create({'name': option_id.label or ''})
                    screen_resolution.append(screen_resolution_ids.id)
            #
            status_id = attribute_obj.search(
                [('attribute_code', '=', 'memory_flash'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'memory_flash':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                internal_memory_ids = self.env['internal.memory'].search([('name', '=', option_id.label)])
                internal_memory.append(internal_memory_ids.id)
                if not internal_memory_ids:
                    internal_memory_ids = self.env['internal.memory'].create({'name': option_id.label or ''})
                    internal_memory.append(internal_memory_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'memory_ram'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'memory_ram':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                ram_ids = self.env['ram'].search([('name', '=', option_id.label)])
                ram.append(ram_ids.id)
                if not ram_ids:
                    ram_ids = self.env['ram'].create({'name': option_id.label or ''})
                    ram.append(ram_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'memory_external'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'memory_external':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                ext_mry_support_ids = self.env['external.memory'].search([('name', '=', option_id.label)])
                ext_mry_support.append(ext_mry_support_ids.id)
                if not ext_mry_support_ids:
                    ext_mry_support_ids = self.env['external.memory'].create({'name': option_id.label or ''})
                    ext_mry_support.append(ext_mry_support_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'cpu_brand'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'cpu_brand':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value':attributes_child['value'],'label': attributes_child['value'],'attribute_id':status_id.id,
                         'referential_id':instance.id})
                processor_core_id = self.env['processor.core'].search([('name', '=', option_id.label)])
                processor_core.append(processor_core_id.id)
                if not processor_core_id:
                    processor_core_id = self.env['processor.core'].create({'name': option_id.label or ''})
                    processor_core.append(processor_core_id.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'cpu_brand'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'cpu_brand':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value':attributes_child['value'],'label': attributes_child['value'],'attribute_id':status_id.id,
                         'referential_id':instance.id})
                processor_model_id = self.env['processor.model'].search([('name', '=', option_id.label)])
                processor_model.append(processor_model_id.id)
                if not processor_model_id:
                    processor_model_id = self.env['processor.model'].create({'name': option_id.label or ''})
                    processor_model.append(processor_model_id.id)



            status_id = attribute_obj.search(
                [('attribute_code', '=', 'fm_am'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'fm_am':
                radio_id = attributes_child['value']
                if radio_id=='1':
                    radio=True
                else:
                    radio = False

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'bluetooth_hands_free'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'bluetooth_hands_free':
                radio_id = attributes_child['value']
                if radio_id == '1':
                    blutooth = True
                else:
                    blutooth = False

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'video_input'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'video_input':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                video_inputs = self.env['video.input'].search([('name', '=', option_id.label)])
                video_in.append(video_inputs.id)
                if not video_inputs:
                    video_inputs = self.env['video.input'].create({'name': option_id.label or ''})
                    video_in.append(video_inputs.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'video_output'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'video_output':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                video_outputs = self.env['video.output'].search([('name', '=', option_id.label)])
                video_out.append(video_outputs.id)
                if not video_outputs:
                    video_outputs = self.env['video.output'].create({'name': option_id.label or ''})
                    video_out.append(video_outputs.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'audio_input'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'audio_input':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                audio_inputs = self.env['audio.input'].search([('name', '=', option_id.label)])
                audio_inp.append(audio_inputs.id)
                if not audio_inputs:
                    audio_inputs = self.env['audio.input'].create({'name': option_id.label or ''})
                    audio_inp.append(audio_inputs.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'audio_output'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'audio_output':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                audio_outputs = self.env['audio.output'].search([('name', '=', option_id.label)])
                audio_out.append(audio_outputs.id)
                if not audio_outputs:
                    audio_outputs = self.env['audio.output'].create({'name': option_id.label or ''})
                    audio_out.append(audio_outputs.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'dvd_player'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'dvd_player':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                dvd_player_ids = self.env['dvd.player'].search([('name', '=', option_id.label)])
                dvd_player.append(dvd_player_ids.id)
                if not dvd_player_ids:
                    dvd_player_ids = self.env['dvd.player'].create({'name': option_id.label or ''})
                    dvd_player.append(dvd_player_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'usb_sd'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'usb_sd':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                usb_port_ids = self.env['usb.port'].search([('name', '=', option_id.label)])
                usb_port.append(usb_port_ids.id)
                if not usb_port_ids:
                    usb_port_ids = self.env['usb.port'].create({'name': option_id.label or ''})
                    usb_port.append(usb_port_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'usb_sd'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'usb_sd':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                sd_card_slot_ids = self.env['sd.card.slot'].search([('name', '=', option_id.label)])
                sd_card_slot.append(sd_card_slot_ids.id)
                if not sd_card_slot_ids:
                    sd_card_slot_ids = self.env['sd.card.slot'].create({'name': option_id.label or ''})
                    sd_card_slot.append(sd_card_slot_ids.id)


            status_id = attribute_obj.search(
                [('attribute_code', '=', 'mirror_link'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'mirror_link':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                mobile_mirror_ids = self.env['mobile.mirror.link'].search([('name', '=', option_id.label)])
                mobile_mirror.append(mobile_mirror_ids.id)
                if not mobile_mirror_ids:
                    mobile_mirror_ids = self.env['mobile.mirror.link'].create({'name': option_id.label or ''})
                    mobile_mirror.append(mobile_mirror_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'steering_wheel_control'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'steering_wheel_control':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                steering_ids = self.env['steering.control'].search([('name', '=', option_id.label)])
                steering.append(steering_ids.id)
                if not steering_ids:
                    steering_ids = self.env['steering.control'].create({'name': option_id.label or ''})
                    steering.append(steering_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'rear_front_camera'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'rear_front_camera':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                support_camera_ids = self.env['support.camera'].search([('name', '=', option_id.label)])
                support_camera.append(support_camera_ids.id)
                if not support_camera_ids:
                    support_camera_ids = self.env['support.camera'].create({'name': option_id.label or ''})
                    support_camera.append(support_camera_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'obd2'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'obd2':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                support_obd_ids = self.env['support.obd'].search([('name', '=', option_id.label)])
                support_obd.append(support_obd_ids.id)
                if not support_obd_ids:
                    support_obd_ids = self.env['support.obd'].create({'name': option_id.label or ''})
                    support_obd.append(support_obd_ids.id)

            status_id = attribute_obj.search([('attribute_code', '=', 'tpms'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'tpms':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                suport_ids = self.env['canbus'].search([('name', '=', option_id.label)])
                print("suport_ids====",suport_ids)
                suport.append(suport_ids.id)
                if not suport_ids:
                    suport_ids = self.env['canbus'].create({'name': option_id.label or ''})
                    suport.append(suport_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'canbus'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'canbus':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                canbus_ids = self.env['suport.tpms'].search([('name', '=', option_id.label)])
                canbus.append(canbus_ids.id)
                if not canbus_ids:
                    canbus_ids = self.env['suport.tpms'].create({'name': option_id.label or ''})
                    canbus.append(canbus_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'productattachment'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'productattachment':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value':attributes_child['value'],'label': attributes_child['value'],'attribute_id':status_id.id,
                         'referential_id':instance.id})
                attach_ids = self.env['product.attachment'].search([('name', '=', option_id.label)])
                attach.append(attach_ids.id)
                print("pppp=====",attach_ids)
                if not attach_ids:
                    attach_ids = self.env['product.attachment'].create({'name': option_id.label or ''})
                    print("attach_ids=====attach_ids", attach_ids.id)
                    attach.append(attach_ids.id)

            # status_id = attribute_obj.search(
            #     [('attribute_code', '=', 'productattachment'), ('referential_id', '=', instance.id)])
            # if attributes_child['attribute_code'] == 'productattachment':
            #     option_id = prod_att_option_obj.search(
            #         [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
            #          ('referential_id', '=', instance.id)])
            #     attachments = self.env['ir.attachment'].search([('name', '=', option_id.label)])
            #     print("attachment_ids===",attachments)
            #     if not attachments:
            #         attachments = self.env['ir.attachment'].create({'name': option_id.label or ''})
            #         print("______attachment_ids___________",attachments)

            # status_id = attribute_obj.search(
            #     [('attribute_code', '=', 'cpu_speed'), ('referential_id', '=', instance.id)])
            if each_product.get('sku'):
                # option_id = prod_att_option_obj.search(
                #     [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                #      ('referential_id', '=', instance.id)])
                rm_model_ids = self.env['rm.model'].search([('name', '=',each_product.get('sku'))])
                print("rm_model_ids====111",rm_model_ids)
                rm_model.append(rm_model_ids.id)
                if not rm_model_ids:
                    rm_model_ids = self.env['rm.model'].create({'name': each_product.get('sku') or ''})
                    print("rm_model_ids======2222",rm_model_ids)
                    rm_model.append(rm_model_ids.id)

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'cpu_speed'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'cpu_speed':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})
                prospeed_ids = self.env['processor.speed'].search([('name', '=', option_id.label)])
                prospeed.append(prospeed_ids.id)
                if not prospeed_ids:
                    prospeed_ids = self.env['processor.speed'].create({'name': option_id.label or ''})
                    prospeed.append(prospeed_ids.id)

            if each_product.get('product_links'):
                for option in each_product.get('product_links'):
                    if option.get('link_type')=='related':
                        product_ids = self.env['product.product'].search([('default_code','=',option.get('linked_product_sku'))])
                        if product_ids:
                            similar_id = self.env['similar.model'].search([('product_id','=',product_ids[0].id)])
                            sim_model.append(similar_id.id)
                            print("product_ids=====",product_ids,similar_id)
                            if not similar_id:
                                similar_id=self.env['similar.model'].create({'product_id': product_ids[0].id})
                                sim_model.append(similar_id.id)
                        if not product_ids:
                            continue

            if each_product.get('product_links'):
                for option in each_product.get('product_links'):
                    if option.get('link_type') == 'crosssell':
                        product_ids = self.env['product.product'].search([('default_code','=',option.get('linked_product_sku'))])
                        print("product_ids====",product_ids)
                        if product_ids:
                            com_acces_ids = self.env['compatible.accessories'].search([('news_product_id','=',product_ids[0].id)])
                            com_acces = com_acces_ids.news_product_id
                            print("product_ids=====",product_ids,com_acces_ids)
                            if not com_acces_ids:
                                com_acces_ids=self.env['compatible.accessories'].create({'news_product_id': product_ids[0].id})
                                com_acces = com_acces_ids.news_product_id
                        if not product_ids:
                            continue

            status_id = attribute_obj.search(
                [('attribute_code', '=', 'website_ids'), ('referential_id', '=', instance.id)])
            if attributes_child['attribute_code'] == 'website_ids':
                option_id = prod_att_option_obj.search(
                    [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
                     ('referential_id', '=', instance.id)])
                print("option_id====", option_id)
                if not option_id:
                    option_id = prod_att_option_obj.create({
                        'value': attributes_child['value'],
                        'label': attributes_child['value'],
                        'attribute_id': status_id.id,
                        'referential_id': instance.id})


            #
            # status_id = attribute_obj.search(
            #     [('attribute_code', '=', 'cpu_speed'), ('referential_id', '=', instance.id)])
            # if attributes_child['attribute_code'] == 'cpu_speed':
            #     option_id = prod_att_option_obj.search(
            #         [('value', '=', attributes_child['value']), ('attribute_id', '=', status_id.id),
            #          ('referential_id', '=', instance.id)])
            #     prospeed_ids = self.env['processor.speed'].search([('name', '=', option_id.label)])
            #     prospeed.append(prospeed_ids.id)
            #     print("pppp=====", prospeed_ids)
            #     if not prospeed_ids:
            #         prospeed_ids = self.env['processor.speed'].create({'name': option_id.label or ''})
            #         prospeed.append(prospeed_ids.id)
        vals = {'name':each_product.get('name'),
                'default_code':sku,
                'magento_id':each_product['id'],
                'attribute_set':att_id,
                'magento_product':True,
                'product_type':each_product.get('type_id'),
                'type':'product',
                'lst_price':each_product.get('price'),
                'prod_category_id':[(6,0,line_categ)],
                'website_ids':[(6,0,website_ids)],
                'store_ids':[(6,0,store_ids)],
                'exported_magento': True,
                'car_make_id': car_make[0] if car_make else False,
                'car_model_id': car_model[0] if car_model else False,
                'stu_yr_id': stu_yr[0] if stu_yr else False,
                'os_ver_id': os_ver[0] if os_ver else False,
                'internal_memory_id': internal_memory[0] if internal_memory else False,
                'processor_core_id': processor_core[0] if processor_core else False,
                'processor_model_id': processor_model[0] if processor_model else False,
                'blutooth': blutooth or False,
                'steering_id': steering[0] if steering else False,
                'video_input': video_in[0] if video_in else False,
                'video_output': video_out[0] if video_out else False,
                'audio_input': audio_inp[0] if audio_inp else False,
                'audio_output': audio_out[0] if audio_out else False,
                'sd_card_slot_id': sd_card_slot[0] if sd_card_slot else False,
                'mobile_mirror_id': mobile_mirror[0] if mobile_mirror else False,
                'support_camera_id': support_camera[0] if support_camera else False,
                'support_obd_id': support_obd[0] if support_obd else False,
                'suport_id': suport[0] if suport else False,
                'canbus_id': canbus[0] if canbus else False,
                'processor_speed_id': prospeed[0] if prospeed else False,
                # 'attachment_ids': [(6,0,attachments)],
                'wifi_id':wifi[0] if wifi else False,
                'navi_gation_id':navigate[0] if navigate else False,
                'warnty_yr_id':warranty_year[0] if warranty_year else False,
                'os_id':os[0] if os else False,
                'screen_size_id':scr_size[0] if scr_size else False,
                'screen_resolution_id':screen_resolution[0] if screen_resolution else False,
                'ram_id':ram[0] if ram else False,
                'ext_mry_support':ext_mry_support[0] if ext_mry_support else False,
                'dvd_player_id':dvd_player[0] if dvd_player else False,
                'usb_port_id':usb_port[0] if usb_port else False,
                'model_id':rm_model[0] if rm_model else False,
                'similar_id':sim_model[0] if sim_model else False,
                # 'compatible_id':com_acces[0] if com_acces else False,
                'news_product_id':com_acces[0].id if com_acces else False,
                'product_attachment':attach[0] if attach else False,
                'desc_eng':description_eng or  '',
                'radio':radio or False,
                'magento_instance_ids':[(6,0,instance_ids)]}
        product_id=self.search([('magento_id','=',each_product['id'])])
        if product_id:
            print ("writign the final variant product",product_id.write(vals))
            self.create_update_attributes(each_product,instance,product_id,store_id,website_id)

        else:
            product_id = self.create(vals)
            self.create_update_attributes(each_product,instance,product_id,store_id,website_id)
        self._cr.commit()
        instance_id = multi_instance.search([('magento_id','=',each_product['id']),('gt_magento_instance_id','=',instance.id),('gt_magento_exported','=',True),('product_id','=',product_id.id)])
        if not instance_id:
            instance_id = multi_instance.create({'magento_id':each_product['id'],'gt_magento_instance_id':instance.id,'gt_magento_exported':True,'product_id':product_id.id})
        prods_id = []
        for prod_id in product_id.gt_magento_product_ids:
            prods_id.append(prod_id.id)
        if instance_id.id not in prods_id:
            prods_id.append(instance_id.id)
        product_id.write({'gt_magento_product_ids':[(6,0,prods_id)]})
        instance.write({'from_id': each_product['id']})
        return product_id


    def update_variant(self,sku,instance,product_ids,headers,store_id,website_id):
        att_set_obj = self.env['gt.product.attribute.set']
        multi_instance = self.env['gt.magento.product.multi']
        categ_id = []
        line_categ = []
        store_ids = []
        website_ids = []
        instance_ids = []
        print ("str(sku)+++++++++++++++++",str(sku))
        print ("store_id.code++++++++++++",store_id.code)
        # add the code for walid project start
        if '/' in str(sku):
            prod_sku = str(sku).replace('/', '%2F')
            print("prod_sku====",prod_sku)
            url = instance.location+"/rest/"+str(store_id.code)+"/V1/products/"+prod_sku
        else:
            url = instance.location+"/rest/"+str(store_id.code)+"/V1/products/"+str(sku)
        # end
      # commented by krishna for walid
        # url=instance.location+"/rest/"+str(store_id.code)+"/V1/products/"+str(sku)
        print("url===",url)
        response = requests.request("GET",url, headers=headers)
        print ("response++++++++++++",response)
        each_list=json.loads(response.text)
        print ("each_list++++++++++++++++",each_list)
        self.create_update_attributes(each_list,instance,product_ids,store_id,website_id)
        if len(self.store_ids) > 0:
            for old_store_id in self.store_ids:
                store_ids.append(old_store_id.id)
        if len(self.website_ids) > 0:
            for old_website_id in self.website_ids:
                website_ids.append(old_website_id.id)
        if len(self.magento_instance_ids) > 0:
            for old_instance_id in self.magento_instance_ids:
                instance_ids.append(old_instance_id.id)
        if store_id.id not in store_ids:
            store_ids.append(store_id.id)
        if website_id.id not in website_ids:
            website_ids.append(website_id.id)
        if instance.id not in instance_ids:
            instance_ids.append(instance.id)
        att_ids=att_set_obj.search([('code','=',each_list.get('attribute_set_id')),('magento_instance_id','=',instance.id)])
        if att_ids:
            att_id=att_ids.id
        else:
            att_id=False
        if each_list.get('custom_attributes'):
            for attributes_child in each_list.get('custom_attributes'):
                if attributes_child['attribute_code']=='category_ids':
                    categ_id = attributes_child['value']  
                    for each_category in categ_id:
                        prod_cat_obj=self.env['product.category']
                        cat_ids=prod_cat_obj.search([('magento_id','=',each_category),('magento_instance_id','=',instance.id),('shop_id','=',store_id.id)])
                        if cat_ids:
                            line_categ.append(cat_ids.id)
        instance_id = multi_instance.search([('magento_id','=',each_list['id']),('gt_magento_instance_id','=',instance.id),('gt_magento_exported','=',True),('product_id','=',product_ids.id)])
        if not instance_id:
            instance_id = multi_instance.create({'magento_id':each_list['id'],'gt_magento_instance_id':instance.id,'gt_magento_exported':True,'product_id':product_ids.id})
        prods_id = []
        for prod_id in product_ids.gt_magento_product_ids:
            prods_id.append(prod_id.id)
        if instance_id.id not in prods_id:
            prods_id.append(instance_id.id)
        vals = {'default_code':sku,'magento_id':each_list['id'],
                'attribute_set':att_id,
                'magento_instance_ids':[(6,0,instance_ids)],
                'magento_product':True,
                'product_type':each_list.get('type_id'),
                'type':'product',
                'lst_price':each_list.get('price'),
                'prod_category_id':[(6,0,line_categ)],
                'website_ids':[(6,0,website_ids)],
                'store_ids':[(6,0,store_ids)],
                'exported_magento': True,
                'gt_magento_product_ids':[(6,0,prods_id)]}
        print ("writign the final variant product",product_ids.write(vals))
        return True

    def create_simple_product_vals(self, store_id, instance_id):
        select_global = self.env["product.attribute.selection.gl"]
        select_website = self.env["product.attribute.selection.wb"]
        select_store = self.env["product.attribute.selection.sw"]

        multi_global = self.env["product.attribute.multiselect.gl"]
        multi_website = self.env["product.attribute.multiselect.wb"]
        multi_store = self.env["product.attribute.multiselect.sw"]

        text_global = self.env["product.attribute.txt.gl"]
        text_website = self.env["product.attribute.txt.wb"]
        text_store = self.env["product.attribute.txt.sw"]

        float_global = self.env["product.attribute.flt.gl"]
        float_website = self.env["product.attribute.flt.wb"]
        float_store = self.env["product.attribute.flt.sw"]

        date_global = self.env["product.attribute.dte.gl"]
        date_website = self.env["product.attribute.dte.wb"]
        date_store = self.env["product.attribute.dte.sw"]

        ml_gl = []
        ml_wb = []
        ml_sw = []
        custom_options = []
        tier_price = []
        categ = []
        option_value = []
        select_global_ids = select_global.search(
            [('gl_sel_att_idc', '=', self.id), ('gl_sel_mag_inst_id', '=', instance_id.id)])
        for glb_ids in select_global_ids:
            custom_options.append({"attributeCode": str(glb_ids.gl_sel_att_id.attribute_code),
                                   "value": str(glb_ids.gl_sel_att_opt_id.value)})
        multi_global_ids = multi_global.search(
            [('gl_mul_att_idc', '=', self.id), ('gl_mul_mag_inst_id', '=', instance_id.id)])
        for multi_ids in multi_global_ids:
            for option in multi_ids.gl_mul_att_opt_id:
                ml_gl.append(option.value)
            custom_options.append({"attributeCode": str(multi_ids.gl_mul_att_id.attribute_code), "value": ml_gl})
        # text_global_ids = text_global.search(
        #     [('gl_txt_att_idc', '=', self.id), ('gl_txt_mag_inst_id', '=', instance_id.id)])
        # for tx_ids in text_global_ids:
        #     custom_options.append(
        #         {"attributeCode": str(tx_ids.gl_txt_att_id.attribute_code), "value": str(tx_ids.gl_txt_att_opt)})
        float_global_ids = float_global.search(
            [('gl_flt_att_idc', '=', self.id), ('gl_flt_mag_inst_id', '=', instance_id.id)])
        for fl_ids in float_global_ids:
            custom_options.append(
                {"attributeCode": str(fl_ids.gl_flt_att_id.attribute_code), "value": str(fl_ids.gl_flt_att_opt)})
        date_global_ids = date_global.search(
            [('gl_dte_att_idc', '=', self.id), ('gl_dte_mag_inst_id', '=', instance_id.id)])
        for dt_ids in date_global_ids:
            custom_options.append(
                {"attributeCode": str(dt_ids.gl_dte_att_id.attribute_code), "value": str(dt_ids.gl_dte_att_opt)})
        select_website_ids = select_website.search(
            [('wb_sel_att_idc', '=', self.id), ('wb_sel_mag_inst_id', '=', instance_id.id),
             ('wb_sel_mag_web_id', '=', store_id.website_id.id)])
        for gl_wb_ids in select_website_ids:
            custom_options.append({"attributeCode": str(gl_wb_ids.wb_sel_att_id.attribute_code),
                                   "value": str(gl_wb_ids.wb_sel_att_opt_id.value)})
        multi_website_ids = multi_website.search(
            [('wb_mul_att_idc', '=', self.id), ('wb_mul_mag_inst_id', '=', instance_id.id),
             ('wb_mul_mag_web_id', '=', store_id.website_id.id)])
        for ml_wb_ids in multi_website_ids:
            for option in ml_wb_ids.wb_mul_att_opt_id:
                ml_wb.append(option.value)
            custom_options.append({"attributeCode": str(ml_wb_ids.wb_mul_att_id.attribute_code), "value": ml_wb})
        text_website_ids = text_website.search(
            [('wb_txt_att_idc', '=', self.id), ('wb_txt_mag_inst_id', '=', instance_id.id),
             ('wb_txt_mag_web_id', '=', store_id.website_id.id)])
        for tx_wb_ids in text_website_ids:
            custom_options.append(
                {"attributeCode": str(tx_wb_ids.wb_txt_att_id.attribute_code), "value": str(tx_wb_ids.wb_txt_att_opt)})
        float_website_ids = float_website.search(
            [('wb_flt_att_idc', '=', self.id), ('wb_flt_mag_inst_id', '=', instance_id.id),
             ('wb_flt_mag_web_id', '=', store_id.website_id.id)])
        for fl_wb_ids in float_website_ids:
            custom_options.append(
                {"attributeCode": str(fl_wb_ids.wb_flt_att_id.attribute_code), "value": str(fl_wb_ids.wb_flt_att_opt)})
        date_website_ids = date_website.search(
            [('wb_dte_att_idc', '=', self.id), ('wb_dte_mag_inst_id', '=', instance_id.id),
             ('wb_dte_mag_web_id', '=', store_id.website_id.id)])
        for dt_wb_ids in date_website_ids:
            custom_options.append(
                {"attributeCode": str(dt_wb_ids.wb_dte_att_id.attribute_code), "value": str(dt_wb_ids.wb_dte_att_opt)})

        select_store_ids = select_store.search(
            [('sw_sel_att_idc', '=', self.id), ('sw_sel_mag_inst_id', '=', instance_id.id),
             ('sw_sel_mag_str_id', '=', store_id.id)])
        for gl_sw_ids in select_store_ids:
            custom_options.append({"attributeCode": str(gl_sw_ids.sw_sel_att_id.attribute_code),
                                   "value": str(gl_sw_ids.sw_sel_att_opt_id.value)})
        multi_store_ids = multi_store.search(
            [('sw_mul_att_idc', '=', self.id), ('sw_mul_mag_inst_id', '=', instance_id.id),
             ('sw_mul_mag_str_id', '=', store_id.id)])
        for ml_sw_ids in multi_store_ids:
            for option in ml_sw_ids.sw_mul_att_opt_id:
                ml_sw.append(option.value)
            custom_options.append({"attributeCode": str(ml_sw_ids.sw_mul_att_id.attribute_code), "value": ml_sw})
        text_store_ids = text_store.search(
            [('sw_txt_att_idc', '=', self.id), ('sw_txt_mag_inst_id', '=', instance_id.id),
             ('sw_txt_mag_str_id', '=', store_id.id)])
        for tx_sw_ids in text_store_ids:
            custom_options.append(
                {"attributeCode": str(tx_sw_ids.sw_txt_att_id.attribute_code), "value": str(tx_sw_ids.sw_txt_att_opt)})
        float_store_ids = float_store.search(
            [('sw_flt_att_idc', '=', self.id), ('sw_flt_mag_inst_id', '=', instance_id.id),
             ('sw_flt_mag_str_id', '=', store_id.id)])
        for fl_sw_ids in float_store_ids:
            custom_options.append(
                {"attributeCode": str(fl_sw_ids.sw_flt_att_id.attribute_code), "value": str(fl_sw_ids.sw_flt_att_opt)})
        date_store_ids = date_store.search(
            [('sw_dte_att_idc', '=', self.id), ('sw_dte_mag_inst_id', '=', instance_id.id),
             ('sw_dte_mag_str_id', '=', store_id.website_id.id)])
        for dt_sw_ids in date_store_ids:
            custom_options.append(
                {"attributeCode": str(dt_sw_ids.sw_dte_att_id.attribute_code), "value": str(dt_sw_ids.sw_dte_att_opt)})
        # print ('custom_options+++++++++++',custom_options)
        for category in self.prod_category_id:
            if instance_id == category.magento_instance_id:
                categ.append(category.magento_id)
        if categ:
            custom_options.append({"attributeCode": 'category_ids', "value": categ})
        return custom_options

    def GtUpdateMagentoProducts(self):
        select_website = self.env["product.attribute.selection.wb"]
        select_store = self.env["product.attribute.selection.sw"]
        multi_ids = self.env['gt.magento.product.multi']
        attribute_obj =self.env['gt.product.attributes']
        prod_att_option_obj = self.env['gt.product.attribute.options']
        if self.product_type == 'simple':
            for instance_id in self.magento_instance_ids:
                instance_id.generate_token()
                token=instance_id.token
                token=token.replace('"'," ")
                auth_token="Bearer "+token.strip()
                auth_token=auth_token.replace("'",'"')
                headers = {
                    'authorization':auth_token,
                    'content-type': "application/json",
                    'cache-control': "no-cache",
                    }
                for website_id in self.website_ids:
                    if instance_id == website_id.magento_instance_id:
                        for store_id in self.store_ids:
                            if store_id.website_id == website_id:
                                print ("store_id++++++++",store_id.name)
                                print ("website_id++++++",website_id.name)
                                print ("store_id++++++++",store_id.website_id)
                                print ("website_id++++++",website_id)
                                custom_options = self.create_simple_product_vals(store_id,instance_id)
                                status = ''
                                visibility = ''
                                product_custom_option = []
                                status_id = attribute_obj.search([('attribute_code','=','status'),('referential_id','=',instance_id.id)])
                                if status_id:
                                    select_website_id = select_website.search([('wb_sel_att_id','=',status_id.id),('wb_sel_att_idc','=',self.id),('wb_sel_mag_web_id','=',website_id.id),('wb_sel_mag_inst_id','=',instance_id.id)])
                                    if select_website_id:
                                        status = select_website_id.wb_sel_att_opt_id.value
                                visibility_id = attribute_obj.search([('attribute_code','=','visibility'),('referential_id','=',instance_id.id)])
                                if visibility_id:
                                    select_store_id = select_store.search([('sw_sel_att_id','=',visibility_id.id),('sw_sel_att_idc','=',self.id),('sw_sel_mag_str_id','=',store_id.id),('sw_sel_mag_inst_id','=',instance_id.id)])
                                    if select_store_id:
                                        visibility = select_store_id.sw_sel_att_opt_id.value
                                multi_id = multi_ids.search([('gt_magento_instance_id','=',instance_id.id),('gt_magento_exported','=',True),('product_id','=',self.id)])

                                #here we have start to work on the extra fields

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'suitable_car_make'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.car_make_id.name:
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'suitable_car_make',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'suitable_car'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),
                                     ('label', '=', self.car_model_id.name)])
                                print("option_id=====", option_id)
                                if self.car_model_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.car_model_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'suitable_car',
                                                                              "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.car_model_id.name, 'label': self.car_model_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'suitable_car',
                                                                      "value": self.car_model_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'suitable_year'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),
                                     ('label', '=', self.stu_yr_id.name)])
                                print("option_id====", option_id)
                                if option_id:
                                    for opt in option_id:
                                        if self.stu_yr_id:
                                            if opt.label == self.stu_yr_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'suitable_year',
                                                                              "value": car_make})
                                else:
                                    option_id = prod_att_option_obj.create({
                                        'value': self.stu_yr_id.name, 'label': self.stu_yr_id.name,
                                        'attribute_id': car_make_id.id,
                                        'referential_id': instance_id.id})
                                    print("option_id====lllll", option_id)
                                    product_custom_option.append({"attribute_code": 'suitable_year',
                                                                  "value": self.stu_yr_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'warranty'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if self.warnty_yr_id:
                                            if opt.label == self.warnty_yr_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'warranty',
                                                                              "value": car_make})
                                # else:
                                #     option_id = prod_att_option_obj.create({
                                #         'value': self.warnty_yr_id.id, 'label': self.warnty_yr_id.name,
                                #         'attribute_id': car_make_id.id,
                                #         'referential_id': instance_id.id})
                                #     print("option_id====lllll", option_id)
                                #     product_custom_option.append({"attribute_code": 'warranty',
                                #                                   "value": self.warnty_yr_id.id})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'operating_system'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.os_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'operating_system',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'operating_system_version'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.os_ver_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'operating_system_version',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'screen_size'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),
                                     ('label', '=', self.screen_size_id.name)])
                                print("=========", option_id)
                                if option_id:
                                    for opt in option_id:
                                        if self.screen_size_id:
                                            if opt.label == self.screen_size_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'screen_size',
                                                                              "value": car_make})
                                else:
                                    option_id = prod_att_option_obj.create({
                                        'value': self.screen_size_id.name, 'label': self.screen_size_id.name,
                                        'attribute_id': car_make_id.id,
                                        'referential_id': instance_id.id})
                                    print("option_id====lllll", option_id)
                                    product_custom_option.append({"attribute_code": 'screen_size',
                                                                  "value": self.screen_size_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'tft_resolution'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.screen_resolution_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'tft_resolution',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'memory_flash'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.internal_memory_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'memory_flash',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'memory_ram'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.ram_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'memory_ram',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'cpu_brand'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),
                                     ('label', '=', self.processor_core_id.name)])
                                if self.processor_core_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.processor_core_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                              "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.processor_core_id.name, 'label': self.processor_core_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                      "value": self.processor_core_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'cpu_brand'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),
                                     ('label', '=', self.processor_model_id.name)])

                                if self.processor_model_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.processor_model_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                              "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.processor_model_id.name,
                                            'label': self.processor_model_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                      "value": self.processor_model_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'cpu_speed'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),
                                     ('label', '=', self.processor_speed_id.name)])
                                if self.processor_speed_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.processor_speed_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'cpu_speed',
                                                                              "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.processor_speed_id.name,
                                            'label': self.processor_speed_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'cpu_speed',
                                                                      "value": self.processor_speed_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'wifi'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.wifi_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'wifi',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'gps'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.navi_gation_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'gps',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'dvd_player'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.dvd_player_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'dvd_player',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'usb_sd'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.sd_card_slot_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'usb_sd',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'usb_sd'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.usb_port_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'usb_sd',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'mirror_link'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.mobile_mirror_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'mirror_link',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'steering_wheel_control'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.steering_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'steering_wheel_control',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'rear_front_camera'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.support_camera_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'rear_front_camera',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'obd2'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.support_obd_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'obd2',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'tpms'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.suport_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'tpms',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'canbus'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.canbus_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'canbus',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'memory_external'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.ext_mry_support.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'memory_external',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'video_input'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.video_input.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'video_input',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'video_output'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.video_output.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'video_output',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'audio_input'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.audio_input.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'audio_input',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'audio_output'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.audio_output.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'audio_output',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'fm_am'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                print("option_id=======", option_id)
                                if option_id:
                                    for opt in option_id:
                                        if self.radio == True:
                                            if opt.value == '1':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'fm_am',
                                                                              "value": car_make})
                                        if self.radio == False:
                                            if opt.value == '0':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'fm_am',
                                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'bluetooth_hands_free'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                print("option_id========1111", option_id)
                                print("option_id========1111", self.blutooth)

                                if option_id:
                                    for opt in option_id:
                                        if self.blutooth == True:
                                            if opt.value == '1':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'bluetooth_hands_free',
                                                                              "value": car_make})
                                        if self.blutooth == False:
                                            if opt.value == '0':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'bluetooth_hands_free',
                                                                              "value": car_make})

                                new = []
                                if self.website_ids:
                                    for web in self.website_ids:
                                        new_webs = self.env['gt.magento.website'].search(
                                            [('name', '=', web.name)])
                                        new.append(str(new_webs.website_id))
                                    product_custom_option.append({"attribute_code": 'website_ids',
                                                                  "value": new})
                                if self.desc_eng:
                                    new_desc = self.desc_eng
                                    product_custom_option.append({"attribute_code": 'description',
                                                                  "value": new_desc})
                                rm_model=''
                                if self.model_id:
                                    rm_model = self.model_id.name
                                    # product_custom_option.append({"sku": rm_model})

                                if multi_id:
                                    vals =  {
                                    "product": {
                                    "id": str(multi_id.magento_id),
                                    "sku": str(self.default_code),
                                    "name": str(self.name),
                                    "attributeSetId": self.attribute_set.code,
                                    "price": self.lst_price,
                                    "status": status or 1,
                                    "visibility": visibility or 4,
                                    "type_id":str(self.product_type),
                                    "sku":rm_model + str(self.name),
                                    #"tierPrices":tier_price,
                                    "customAttributes":custom_options,
                                    "custom_attributes": product_custom_option,
                                            }
                                        }
                                    print ("vals+++++++++++++",vals)
                                    url=str(instance_id.location)+"rest/"+ str(store_id.code) +"/V1/products/"+str(self.default_code)
                                    print ("url++++++++++++++++",url)
                                    productload= str(vals)
                                    productload=productload.replace("'",'"')
                                    productload=str(productload)
                                    response = requests.request("PUT",url,data=productload, headers=headers)
                                    print ("response++++++++++++++",response)
                                    each_response=json.loads(response.text)
                                    print ("each_response++++++++++",each_response)
                                self._cr.commit()
        return True


    def GtExportMagentoProducts(self):
        multi_instance = self.env['gt.magento.product.multi']
        select_website = self.env["product.attribute.selection.wb"]
        select_store = self.env["product.attribute.selection.sw"]
        attribute_obj =self.env['gt.product.attributes']
        prod_att_option_obj = self.env['gt.product.attribute.options']
        if self.product_type == 'simple':
            for instance_id in self.magento_instance_ids:
                instance_id.generate_token()
                token=instance_id.token
                token=token.replace('"'," ")
                auth_token="Bearer "+token.strip()
                auth_token=auth_token.replace("'",'"')
                headers = {
                    'authorization':auth_token,
                    'content-type': "application/json",
                    'cache-control': "no-cache",
                    }
                for website_id in self.website_ids:
                    if instance_id == website_id.magento_instance_id:
                        for store_id in self.store_ids:
                            if store_id.website_id == website_id:
                                print ("store_id++++++++",store_id.name)
                                print ("website_id++++++",website_id.name)
                                custom_options = self.create_simple_product_vals(store_id,instance_id)
                                status = ''
                                visibility = ''
                                car_make=''
                                product_custom_option = []
                                status_id = attribute_obj.search([('attribute_code','=','status'),('referential_id','=',instance_id.id)])
                                if status_id:
                                    select_website_id = select_website.search([('wb_sel_att_id','=',status_id.id),('wb_sel_att_idc','=',self.id),('wb_sel_mag_web_id','=',website_id.id),('wb_sel_mag_inst_id','=',instance_id.id)])
                                    if select_website_id:
                                        status = select_website_id.wb_sel_att_opt_id.value
                                visibility_id = attribute_obj.search([('attribute_code','=','visibility'),('referential_id','=',instance_id.id)])
                                if visibility_id:
                                    select_store_id = select_store.search([('sw_sel_att_id','=',visibility_id.id),('sw_sel_att_idc','=',self.id),('sw_sel_mag_str_id','=',store_id.id),('sw_sel_mag_inst_id','=',instance_id.id)])
                                    if select_store_id:
                                        visibility = select_store_id.sw_sel_att_opt_id.value
                                visibility_id = attribute_obj.search(
                                    [('attribute_code', '=', 'visibility'), ('referential_id', '=', instance_id.id)])

                               ### code for extra product fields

                                    # car_make_id = attribute_obj.search(
                                    #     [('attribute_code', '=', 'suitable_car_make'),
                                    #      ('referential_id', '=', instance_id.id)])
                                    # print("car_make_id====", car_make_id)
                                    # option_id = prod_att_option_obj.search(
                                    #     [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                    # for opt in option_id:
                                    #     if opt.label == self.car_make_id.name:
                                    #         car_make = opt.value
                                    # product_custom_option.append({"attribute_code": 'suitable_car_make',
                                    #                               "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'suitable_car_make'), ('referential_id', '=', instance_id.id)])
                                print("car_make_id====",car_make_id)
                                option_id = prod_att_option_obj.search([('attribute_id', '=', car_make_id.id),('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label==self.car_make_id.name:
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code":'suitable_car_make',
                                                           "value":car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'suitable_car'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),('label','=',self.car_model_id.name)])
                                print("option_id=====",option_id)
                                if self.car_model_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.car_model_id.name:
                                                print("opt====",opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'suitable_car',
                                                                          "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                             'value': self.car_model_id.name, 'label': self.car_model_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'suitable_car',
                                                                      "value": self.car_model_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'suitable_year'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),('label','=',self.stu_yr_id.name)])
                                print("option_id====",option_id)
                                if option_id:
                                    for opt in option_id:
                                        if self.stu_yr_id:
                                            if opt.label == self.stu_yr_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'suitable_year',
                                                              "value": car_make})
                                else:
                                    option_id = prod_att_option_obj.create({
                                         'value': self.stu_yr_id.name, 'label': self.stu_yr_id.name,
                                        'attribute_id': car_make_id.id,
                                        'referential_id': instance_id.id})
                                    print("option_id====lllll", option_id)
                                    product_custom_option.append({"attribute_code": 'suitable_year',
                                                                  "value": self.stu_yr_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'warranty'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if self.warnty_yr_id:
                                            if opt.label == self.warnty_yr_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'warranty',
                                                                "value": car_make})
                                # else:
                                #     option_id = prod_att_option_obj.create({
                                #         'value': self.warnty_yr_id.id, 'label': self.warnty_yr_id.name,
                                #         'attribute_id': car_make_id.id,
                                #         'referential_id': instance_id.id})
                                #     print("option_id====lllll", option_id)
                                #     product_custom_option.append({"attribute_code": 'warranty',
                                #                                   "value": self.warnty_yr_id.id})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'operating_system'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.os_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'operating_system',
                                                              "value": car_make})


                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'operating_system_version'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id),('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.os_ver_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'operating_system_version',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'screen_size'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id),('referential_id', '=', instance_id.id),('label','=',self.screen_size_id.name)])
                                print("=========",option_id)
                                if option_id:
                                    for opt in option_id:
                                        if self.screen_size_id:
                                            if opt.label == self.screen_size_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'screen_size',
                                                              "value": car_make})
                                else:
                                    option_id = prod_att_option_obj.create({
                                        'value': self.screen_size_id.name, 'label': self.screen_size_id.name,
                                        'attribute_id': car_make_id.id,
                                        'referential_id': instance_id.id})
                                    print("option_id====lllll", option_id)
                                    product_custom_option.append({"attribute_code": 'screen_size',
                                                                  "value": self.screen_size_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'tft_resolution'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.screen_resolution_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'tft_resolution',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'memory_flash'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.internal_memory_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'memory_flash',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'memory_ram'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.ram_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'memory_ram',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'cpu_brand'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),('label','=',self.processor_core_id.name)])
                                if self.processor_core_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.processor_core_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                  "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.processor_core_id.name, 'label': self.processor_core_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                      "value": self.processor_core_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'cpu_brand'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),('label','=',self.processor_model_id.name)])

                                if self.processor_model_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.processor_model_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                      "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.processor_model_id.name, 'label': self.processor_model_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'cpu_brand',
                                                                      "value": self.processor_model_id.name})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'cpu_speed'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id),('label','=',self.processor_speed_id.name)])
                                if self.processor_speed_id.name:
                                    if option_id:
                                        for opt in option_id:
                                            if opt.label == self.processor_speed_id.name:
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'cpu_speed',
                                                                      "value": car_make})
                                    else:
                                        option_id = prod_att_option_obj.create({
                                            'value': self.processor_speed_id.name, 'label': self.processor_speed_id.name,
                                            'attribute_id': car_make_id.id,
                                            'referential_id': instance_id.id})
                                        print("option_id====lllll", option_id)
                                        product_custom_option.append({"attribute_code": 'cpu_speed',
                                                                      "value": self.processor_speed_id.name})


                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'wifi'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.wifi_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'wifi',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'gps'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.navi_gation_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'gps',
                                                                      "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'dvd_player'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.dvd_player_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'dvd_player',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'usb_sd'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.sd_card_slot_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'usb_sd',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'usb_sd'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                for opt in option_id:
                                    if opt.label == self.usb_port_id.name:
                                        print("opt====", opt)
                                        car_make = opt.value
                                        product_custom_option.append({"attribute_code": 'usb_sd',
                                                              "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'mirror_link'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.mobile_mirror_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'mirror_link',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'steering_wheel_control'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.steering_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'steering_wheel_control',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'rear_front_camera'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.support_camera_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'rear_front_camera',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'obd2'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.support_obd_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'obd2',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'tpms'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.suport_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'tpms',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'canbus'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.canbus_id.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'canbus',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'memory_external'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.ext_mry_support.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'memory_external',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'video_input'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.video_input.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'video_input',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'video_output'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.video_output.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'video_output',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'audio_input'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.audio_input.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'audio_input',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'audio_output'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                if option_id:
                                    for opt in option_id:
                                        if opt.label == self.audio_output.name:
                                            print("opt====", opt)
                                            car_make = opt.value
                                            product_custom_option.append({"attribute_code": 'audio_output',
                                                                  "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'fm_am'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                print("option_id=======",option_id)
                                if option_id:
                                    for opt in option_id:
                                        if self.radio == True:
                                            if opt.value == '1':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'fm_am',
                                                                              "value": car_make})
                                        if self.radio == False:
                                            if opt.value == '0':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'fm_am',
                                                                          "value": car_make})

                                car_make_id = attribute_obj.search(
                                    [('attribute_code', '=', 'bluetooth_hands_free'),
                                     ('referential_id', '=', instance_id.id)])
                                print("car_make_id====", car_make_id)
                                option_id = prod_att_option_obj.search(
                                    [('attribute_id', '=', car_make_id.id),('referential_id', '=', instance_id.id)])
                                print("option_id========1111",option_id)
                                print("option_id========1111",self.blutooth)

                                if option_id:
                                    for opt in option_id:
                                        if self.blutooth == True:
                                            if opt.value == '1':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'bluetooth_hands_free',
                                                                              "value": car_make})
                                        if self.blutooth == False:
                                            if opt.value == '0':
                                                print("opt====", opt)
                                                car_make = opt.value
                                                product_custom_option.append({"attribute_code": 'bluetooth_hands_free',
                                                                              "value": car_make})

                                new=[]
                                if self.website_ids:
                                    for web in self.website_ids:
                                        new_webs = self.env['gt.magento.website'].search(
                                            [('name', '=', web.name)])
                                        new.append(str(new_webs.website_id))
                                    product_custom_option.append({"attribute_code": 'website_ids',
                                                          "value": new})
                                if self.desc_eng:
                                    new_desc = self.desc_eng
                                    product_custom_option.append({"attribute_code": 'description',
                                                                  "value":new_desc})


                                # car_make_id = attribute_obj.search(
                                #     [('attribute_code', '=', 'productattachment'),
                                #      ('referential_id', '=', instance_id.id)])
                                # print("car_make_id====", car_make_id)
                                # option_id = prod_att_option_obj.search(
                                #     [('attribute_id', '=', car_make_id.id), ('referential_id', '=', instance_id.id)])
                                # if option_id:
                                #     for opt in option_id:
                                #         if opt.label == self.product_attachment.name:
                                #             print("opt====", opt)
                                #             car_make = opt.value
                                #             product_custom_option.append({"attribute_code": 'productattachment',
                                #                                           "value": car_make})

                                vals =  {
                                "product": {
                                "id": 0,
                                "sku": str(self.default_code),
                                "name": str(self.name),
                                "attributeSetId": 4,
                                "price": self.lst_price,
                                "status":  status or 1,
                                "visibility": visibility or 4,
                                "type_id":str(self.product_type),
                                #"tierPrices":tier_price,
                                "customAttributes":custom_options,
                                "custom_attributes":product_custom_option,
                                        }
                                    }
                                print("vals====",vals)
                                url=str(instance_id.location)+"/rest/V1/products/"
                                productload= str(vals)
                                print("productload====,productload")
                                productload=productload.replace("'",'"')
                                productload=str(productload)
                                print("productload=====",productload)
                                response = requests.request("POST",url,data=productload, headers=headers)
                                print("response======",response)
                                if str(response.status_code)=="200":
                                    each_response=json.loads(response.text)
                                    print ("each_response++++++++++",each_response)
                                    product_id = multi_instance.search([('magento_id','=',each_response['id']),('gt_magento_instance_id','=',instance_id.id),('gt_magento_exported','=',True),('product_id','=',self.id)])
                                    if not product_id:
                                        product_id = multi_instance.create({'magento_id':each_response['id'],'gt_magento_instance_id':instance_id.id,'gt_magento_exported':True,'product_id':self.id})
                                    prods_id = []
                                    for prod_id in self.gt_magento_product_ids:
                                        prods_id.append(prod_id.id)
                                    if product_id.id not in prods_id:
                                        prods_id.append(product_id.id)
                                    self.write({'gt_magento_product_ids':[(6,0,prods_id)]})
            self.write({'exported_magento':True})
            self._cr.commit()
        return True

class SaleOrder(models.Model):
    _inherit='sale.order'

    order_status = fields.Char(string='Order Status',readonly=True)
