# -*- coding: utf-8 -*-
###############################################################################
#                                                                             #
#    Globalteckz                                                              #
#    Copyright (C) 2013-Today Globalteckz (http://www.globalteckz.com)        #
#                                                                             #
#    This program is free software: you can redistribute it and/or modify     #
#    it under the terms of the GNU Affero General Public License as           #
#    published by the Free Software Foundation, either version 3 of the       #
#    License, or (at your option) any later version.                          #
#                                                                             #
#    This program is distributed in the hope that it will be useful,          #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of           #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            #
#    GNU Affero General Public License for more details.                      #
#                                                                             #
#    You should have received a copy of the GNU Affero General Public License #
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.    #
#                                                                             #   
###############################################################################

from odoo import models, fields, api,_
import os
import io
import base64
import time
from odoo.exceptions import UserError


class RmModel(models.Model):
    _name = 'rm.model'

    name=fields.Char('Model Name')

class CarMake(models.Model):
    _name = 'car.make'

    name=fields.Char('Model Name')

class CarModel(models.Model):
    _name = 'car.model'

    name=fields.Char('Model Name')

class SuitableYears(models.Model):
    _name = 'suitable.years'

    name=fields.Char('Model Name')

class WarrantyYears(models.Model):
    _name = 'warranty.years'

    name=fields.Char('Model Name')

class OperatingSystem(models.Model):
    _name = 'operating.system'

    name=fields.Char('Model Name')

class OSVersion(models.Model):
    _name = 'os.version'

    name=fields.Char('Version Name')

class ScreenSize(models.Model):
    _name = 'screen.size'

    name=fields.Char('Model Name')

class ScreenResolution(models.Model):
    _name = 'screen.resolution'

    name=fields.Char('Model Name')

class InternalMemory(models.Model):
    _name = 'internal.memory'

    name=fields.Char('Model Name')

class RAM(models.Model):
    _name = 'ram'

    name=fields.Char('Model Name')

class ProcessorCore(models.Model):
    _name = 'processor.core'

    name=fields.Char('Model Name')

class ProcessorModel(models.Model):
    _name = 'processor.model'

    name=fields.Char('Model Name')

class ProcessorSpeed(models.Model):
    _name = 'processor.speed'

    name=fields.Char('Model Name')

class Wifi(models.Model):
    _name = 'wifi'

    name=fields.Char('Model Name')

class DVDPlayer(models.Model):
    _name = 'dvd.player'

    name=fields.Char('Model Name')

class SdCardSlot(models.Model):
    _name = 'sd.card.slot'

    name=fields.Char('Model Name')

class USBPort(models.Model):
    _name = 'usb.port'

    name=fields.Char('Model Name')

class MobileMirrorLink(models.Model):
    _name = 'mobile.mirror.link'

    name=fields.Char('Model Name')

class SteeringControl(models.Model):
    _name = 'steering.control'

    name=fields.Char('Model Name')

class SupportCamera(models.Model):
    _name = 'support.camera'

    name=fields.Char('Model Name')

class SupportOBD(models.Model):
    _name = 'support.obd'

    name=fields.Char('Model Name')

class SupportTPMS(models.Model):
    _name = 'suport.tpms'

    name=fields.Char('Model Name')

class Canbus(models.Model):
    _name = 'canbus'

    name=fields.Char('Model Name')

class SimilarModel(models.Model):
    _name = 'similar.model'

    name = fields.Char('Model Name')
    product_id=fields.Many2one('product.product',string='Product Template')

class CompatibleAccessories(models.Model):
    _name = 'compatible.accessories'

    name=fields.Char('Model Name')
    news_product_id = fields.Many2one('product.product', string='Product Template')
class ExternalMemory(models.Model):
    _name = 'external.memory'

    name=fields.Char('Model Name')

class VideoInput(models.Model):
    _name = 'video.input'

    name=fields.Char('Model Name')

class VideoOutput(models.Model):
    _name = 'video.output'

    name=fields.Char('Model Name')

class AudioInput(models.Model):
    _name = 'audio.input'

    name=fields.Char('Model Name')

class AudioOutput(models.Model):
    _name = 'audio.output'

    name=fields.Char('Model Name')

class NaviGation(models.Model):
    _name = 'navi.gation'

    name=fields.Char('Model Name')

class AudioOutput(models.Model):
    _name='product.attachment'

    name=fields.Char(string='Product Attachment')

class ProductTemplate(models.Model):
    _inherit = "product.template"

    model_id = fields.Many2one('rm.model', string="RM Model")
    car_make_id = fields.Many2one('car.make', string="Car Make")
    car_model_id = fields.Many2one('car.model', string="Car Model")
    stu_yr_id = fields.Many2one('suitable.years', string="Suitable Years")
    warnty_yr_id = fields.Many2one('warranty.years', string="Warranty Years")
    os_id = fields.Many2one('operating.system', string="Operating System")
    os_ver_id = fields.Many2one('os.version', string="O.S Version")
    screen_size_id = fields.Many2one('screen.size', string="Screen Size")
    screen_resolution_id = fields.Many2one('screen.resolution', string="Screen Resolution")
    internal_memory_id = fields.Many2one('internal.memory', string="Internal Memory")
    ram_id = fields.Many2one('ram', string="RAM")
    processor_core_id = fields.Many2one('processor.core', string="Processor Core")
    processor_model_id = fields.Many2one('processor.model', string="Processor Model")
    processor_speed_id = fields.Many2one('processor.speed', string="Processor Speed")
    wifi_id = fields.Many2one('wifi', string="Wifi")
    dvd_player_id = fields.Many2one('dvd.player', string="DVD Player")
    sd_card_slot_id = fields.Many2one('sd.card.slot', string="SD Card Slot")
    usb_port_id = fields.Many2one('usb.port', string="USB Port")
    mobile_mirror_id = fields.Many2one('mobile.mirror.link', string="Mobile Mirror Link")
    steering_id = fields.Many2one('steering.control', string="Steering Control")
    support_camera_id = fields.Many2one('support.camera', string="Support Camera")
    support_obd_id = fields.Many2one('support.obd', string="Support OBD")
    suport_id = fields.Many2one('suport.tpms', string="Support TPMS")
    canbus_id = fields.Many2one('canbus', string="Canbus")
    similar_id = fields.Many2one('similar.model', string="Similar Model")
    product_id = fields.Many2one('product.product',related='similar_id.product_id', string="Similar Model")
    prod_id = fields.Many2one('product.product', string="Similar Model")
    compatible_id = fields.Many2one('compatible.accessories', string="Compatible Accessories")
    news_product_id = fields.Many2one('product.product',realted='compatible_id.news_product_id',string="Compatible Accessories",readonly=True)
    navigation = fields.Text(string="Navigation")
    ext_mry_support = fields.Many2one('external.memory',string="External Memory Support")
    radio = fields.Boolean(string="Radio")
    video_input = fields.Many2one('video.input',string="Video Input")
    video_output = fields.Many2one('video.output',string="Video Output")
    audio_input = fields.Many2one('audio.input',string="Audio Input")
    audio_output = fields.Many2one('audio.output',string="Audio Output")
    blutooth = fields.Boolean(string="Bluetooth")
    desc_eng = fields.Text('Product Description/English/Arabic')
    desc_arb = fields.Html('Product Description/Arabic')
    params_store = fields.Binary(string='Params storage')
    manual_attached = fields.Many2many(
        'ir.attachment', 'attachment',string='User Manual Attachment')
    attachment_ids = fields.Many2many(
        'ir.attachment', 'attachment_id',string='Attachments')
    attachment_id = fields.Many2one('ir.attachment', string='Attachment')
    product_attachment = fields.Many2one('product.attachment', string="Product Attachment")
    navi_gation_id = fields.Many2one('navi.gation', string="Navigation")

    @api.onchange('attachment_ids')
    def _get_size(self):
        for attach_id in self.attachment_ids:
            greater_id = []
            dt_size = attach_id.datas
            bytes = ((len(dt_size) * 3) / 4)
            print("bytes===",bytes)
            a = str(attach_id.id).split('=')[1]
            b = a.replace('>', '')
            c = int(b)
            print ('_______A____________',a, type(a))
            print('_______B____________', b, type(b))
            print('_______C____________', c, type(c))
            # d = self.env['ir.attachment'].browse(c)
            # print('_______D____________', d, type(d))
            if bytes > 1000000:
                greater_id.append(c)
            print("greater_id===",greater_id)
            if greater_id:
                new_ids = self.env['ir.attachment'].browse(greater_id)
                new_ids.unlink()
                # raise UserError(_('PLease Select The Below The 1MB File'))
            # else:
            #     d.unlink()

class ProductProduct(models.Model):
    _inherit = "product.product"

    attachment_id = fields.Many2one('ir.attachment', string='Attachment')

    @api.onchange('attachment_ids')
    def _get_size(self):
        for attach_id in self.attachment_ids:
            greater_id = []
            dt_size = attach_id.datas
            bytes = ((len(dt_size) * 3) / 4)
            print("bytes===", bytes)
            a = str(attach_id.id).split('=')[1]
            b = a.replace('>', '')
            c = int(b)
            print('_______A____________', a, type(a))
            print('_______B____________', b, type(b))
            print('_______C____________', c, type(c))
            # d = self.env['ir.attachment'].browse(c)
            # print('_______D____________', d, type(d))
            if bytes > 1000000:
                greater_id.append(c)
            print("greater_id===", greater_id)
            if greater_id:
                new_ids = self.env['ir.attachment'].browse(greater_id)
                new_ids.unlink()
                # raise UserError(_('PLease Select The Below The 1MB File'))