# -*- coding: utf-8 -*-
###############################################################################
#                                                                             #
#    Globalteckz                                                              #
#    Copyright (C) 2013-Today Globalteckz (http://www.globalteckz.com)        #
#                                                                             # 
#    This program is free software: you can redistribute it and/or modify     #
#    it under the terms of the GNU Affero General Public License as           #
#    published by the Free Software Foundation, either version 3 of the       #
#    License, or (at your option) any later version.                          #
#                                                                             #
#    This program is distributed in the hope that it will be useful,          #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of           #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            # 
#    GNU Affero General Public License for more details.                      #
#                                                                             #
#    You should have received a copy of the GNU Affero General Public License #
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.    #
#                                                                             #
###############################################################################


{
    'name': 'Magento 2 Odoo-13 extension',
    'version': '13.0.0.1',
    'category': 'Generic Modules',
    'sequence': 1,
    'author': 'globalteckz',
    'website': 'http://www.globalteckz.com',
    'summary': '',
    'description': """

Magento Odoo Connector
=========================

This  Module  Connect Odoo with Magento and synchronise Data. 
--------------------------------------------------------------------------


Some of the feature of the module:
--------------------------------------------

    1. synchronise all the catalog categories to Magento.
    
    2. synchronise all the catalog products to Magento.

    3. synchronise all the Attributes and Values.
    
    4. synchronise all the order(Invoice, shipping) Status to Odoo.
    
    5. Import Magento Regions.
    
    6. synchronise inventory of catalog products.
    
This module works very well with latest version of magento 2.0* and Odoo 11.0
------------------------------------------------------------------------------
    """,
    'depends': ['globalteckz_magento_2','product_images_olbs'],
    'data': [
          #  'security/gt_magento_security.xml',
           'security/ir.model.access.csv',
            'views/gt_magento_shop_view.xml',
           'views/prodcuct_view.xml',
            ],
    'application': True,
    'installable': True,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
