# -*- coding: utf-8 -*-

from odoo import models, fields, api


class EventRegistrationInherit(models.Model):
    _inherit = 'event.registration'

    job_position = fields.Char(string='Job Position')
    address = fields.Char(string='Address')


class EventInherit(models.Model):
	_inherit = 'event.event'

	has_no_time_limit = fields.Boolean(string='Has no time limit')