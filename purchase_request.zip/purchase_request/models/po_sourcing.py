from odoo import models, fields


class PurchaseSourcing(models.Model):
    _name = 'purchase.sourcing'

    name = fields.Char('Name', required=1)
