# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _

class StudentStudent(models.Model):
    _inherit = 'student.student'

    transportation_type =  fields.Selection([('oneway_morning','One-way Morning'), ('oneway_evening','One-way Evening'),
                                            ('two_way','Two-Way')], string='Service Type', readonly=True)
    transport_id =  fields.Many2one('transportation.transportation', string='Transport', readonly=True)
    pickup_drop = fields.Many2one('res.area', string='Area', readonly=True)
    transportation_ids = fields.One2many('student.transportation', 'student_id', string='Transportation History', readonly=True)
    countrys_id = fields.Many2one('res.country', 'Nationality (Country)', tracking=True)
    acceptance_test_ids = fields.One2many('acceptance.test', 'student_id', string="Acceptance Tests")
    temporary = fields.Char(string="Temporary")
    final = fields.Char(string="Final")
    attachment_file = fields.Binary(string="File")

    @api.onchange('transportation_type')
    def onchange_service_type(self):
        """
            Set pickup_drop according to transportation.
        """
        if not self.transportation_type:
            self.pickup_drop = False
            self.transport_id = False

    @api.onchange('pickup_drop')
    def onchange_pickup_drop(self):
        """
            Set transportation according to pickup_drop.
        """
        transportation_obj = self.env['transportation.transportation']
        transports = []
        stop_ids = []
        if not self.transportation_type:
            self.pickup_drop = False
            self.transport_id = False
        transportation_ids = transportation_obj.search([('transportation_type', '=', self.transportation_type)])
        for transport in transportation_ids:
            stop_ids = [stop.pickup_drop.id for stop in transport.stop]
            if self.pickup_drop.id in stop_ids:
                transports.append(transport.id)
        self.transport_id = False
        return {'domain': {'transport_id': [('id', 'in', transports)]}}


class TransportationHistory(models.Model):
    _name = 'student.transportation'
    _description = "Student Transportation History"
    _order = 'create_date DESC'

    create_date = fields.Datetime(string='Creation Date')
    transportation_type = fields.Selection([('oneway_morning','One-way Morning'),('oneway_evening','One-way Evening'),('two_way','Two-Way')], string='Service Type', required=True)
    pickup_drop = fields.Many2one('res.area', string='Area', required=True)
    transport_id = fields.Many2one('transportation.transportation', string='Transport', required=True)
    student_id = fields.Many2one('student.student', string='Student')
    invoice_id = fields.Many2one('account.move', string='Invoice')
    invoice_state = fields.Selection(related='invoice_id.state',
        selection=[
        ('draft','Draft'),
        ('proforma','Pro-forma'),
        ('proforma2','Pro-forma'),
        ('open','Open'),
        ('paid','Paid'),
        ('cancel','Cancelled'),
        ], string='Invoice Status',
        help=' * The \'Draft\' status is used when a user is encoding a new and unconfirmed Invoice. \
        \n* The \'Pro-forma\' when invoice is in Pro-forma status,invoice does not have an invoice number. \
        \n* The \'Open\' status is used when user create invoice,a invoice number is generated.Its in open status till user does not pay invoice. \
        \n* The \'Paid\' status is set automatically when the invoice is paid. Its related journal entries may or may not be reconciled. \
        \n* The \'Cancelled\' status is used when user cancel invoice.')

    def action_view_invoice(self):
        ''' open a view on one of the given invoice_id '''
        self.ensure_one()
        action = self.env.ref('account.action_move_out_invoice_type').read()[0]

        if len(self.invoice_id.ids) > 1:
            action['domain'] = [('id', 'in', self.invoice_id.ids)]
        elif len(self.invoice_id) == 1:
            action['views'] = [(self.env.ref('account.view_move_form').id, 'form')]
            action['res_id'] = self.invoice_id.id
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action


class StudentParent(models.Model):
    _inherit = 'student.parent'

    admission_id = fields.Many2one('admission.admission', 'Admission')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: