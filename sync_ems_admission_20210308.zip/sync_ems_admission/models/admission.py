# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, Warning
from datetime import timedelta
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT


class Education(models.Model):
    _name = 'education.education'
    _description = 'Education'

    name = fields.Char(string="Name")

class AcceptanceTest(models.Model):
    _name = 'acceptance.test'
    _description = "Acceptance Test"

    admission_id = fields.Many2one('admission.admission')
    student_id = fields.Many2one('student.student')
    subject = fields.Char(string="Subject")
    mark = fields.Char(string="Mark")
    remark = fields.Char(string="Remark")

class AdmissionAdmission(models.Model):
    _name = 'admission.admission'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _order = "application_number desc"
    _description = 'Admission Details'

    @api.depends('semester_price', 'transportation_price', 'hostel_price', 'library_price')
    def _total_price(self):
        """ get the total price """
        self.all_total_price = self.semester_price + self.transportation_price + self.hostel_price + self.library_price

    @api.model
    def _default_user(self):
        return self.env.user.id

    @api.model
    def _default_user_dep(self):
        """ get the user department """
        user = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1)
        department = user and user.department_id.id or False
        return department

    def _compute_fees(self):
        for rec in self:
            rec.invo_count = 0
            rec.pick_count = 0
            rec.so_fees_count = 0
            if rec.partner_id:
                invoice_ids = self.env['account.move'].search([('partner_id', '=', rec.partner_id.id), ('type', 'in', ['out_invoice', 'in_invoice', 'in_refund', 'out_refund'])]).ids
                rec.invo_count = invoice_ids and len(invoice_ids) or False
                picking_ids = self.env['stock.picking'].search([('partner_id', '=', rec.partner_id.id)]).ids
                rec.pick_count = picking_ids and len(picking_ids) or False
                sale_ids = self.env['sale.order'].search([('partner_id', '=', rec.partner_id.id), ('fee', '=', True)]).ids
                rec.so_fees_count = sale_ids and len(sale_ids) or False

    middle_name = fields.Many2one('res.partner', string='Middle Name', track_visibility="onchange", required=True, domain="[('is_parent', '=', True)]")
    name = fields.Char(size=128, string='First Name', track_visibility="onchange", required=True)
    last_name = fields.Char(size=128, string='Last Name', required=True)
    title = fields.Many2one('res.partner.title', 'Title', readonly=False)
    application_number = fields.Char(size=16, string='Application Number', track_visibility="onchange", required=True, copy=False, default='/')
    admission_date = fields.Date(string='Admission Date', required=True, track_visibility="onchange", readonly=False, copy=False, default=fields.Date.today())
    application_date = fields.Date(string='Application Date', required=True, copy=False, default=fields.Date.today())
    photo = fields.Binary(string='Photo', readonly=False)
    birth_date = fields.Date(string='Birth Date', required=True, track_visibility="onchange",  readonly=False)
    place_birth = fields.Char("Place of birth")
    street = fields.Char(size=256, string='Street', readonly=False)
    street2 = fields.Char(size=256, string='Street2', readonly=False)
    city = fields.Char(size=64, string='City', readonly=False)
    zip = fields.Char(size=8, string='Zip', readonly=False)
    state_id = fields.Many2one('res.country.state', string='States', readonly=False)
    country_id = fields.Many2one('res.country', string='Country', track_visibility="onchange",  readonly=False)
    phone = fields.Char(size=16, string='Phone', readonly=False)
    # mobile = fields.Char(size=16, string='Mobile', readonly=False)
    email = fields.Char(size=256, string='Email', readonly=False, track_visibility="onchange")
    personal_email = fields.Char(size=256, string='Personal Email', readonly=False)
    religion_id = fields.Many2one('religion.religion', string='Religion', readonly=False, track_visibility="onchange")
    # prev_institute = fields.Char(size=256, string='Previous Institute', readonly=False)
    # prev_course = fields.Char(size=256, string='Previous Course', readonly=False)
    # prev_result = fields.Char(size=256, string='Previous Result', readonly=False)
    gender = fields.Selection([('m', 'Male'), ('f', 'Female'), ('o', 'Other')], string='Gender', track_visibility="onchange", required=True)
    enrollment_no = fields.Char('Enrollment No', size=14, required=True, track_visibility="onchange", default='/', copy=False)
    user_id = fields.Many2one('res.users', 'Registration By', readonly=False, track_visibility="onchange", default=_default_user)
    reg_department = fields.Many2one('hr.department', 'Registration Department', readonly=False, track_visibility="onchange", default=_default_user_dep)
    fees = fields.Float(string='Fees', track_visibility="onchange", help="This fees is total of all products which are marked as admission product.")
    due_date = fields.Date(string='Due Date', readonly=False, track_visibility="onchange")
    pricelist_id = fields.Many2one('product.pricelist', 'Pricelist', track_visibility="onchange", readonly=False)
    course_id = fields.Many2one('course.course', string='Course', track_visibility="onchange", required=True)
    batch_id = fields.Many2one('batch.batch', string='Batch', track_visibility="onchange", required=True)
    semester_id = fields.Many2one('semester.semester', string='Standards', track_visibility="onchange", required=True)
    division_id = fields.Many2one('division.division', string='Division', track_visibility="onchange", readonly=False)
    stage_id = fields.Many2one('stage.stage', 'Stage', required=True, track_visibility="onchange", readonly=False)
    state = fields.Selection([
            ('draft', 'Draft'),
            ('pending', 'Pending'),
            ('initial_acceptance', 'Initial Acceptance'),
            ('academic_acceptance' ,'Academic Acceptance'),
            # ('confirm', 'Confirm'),
            ('proceed_payment', 'Proceed Payment'),
            ('done', 'Done') ,
            ('reject', 'Rejected'),
            ('cancel', 'Cancel')], string='State', default='draft', required=True, track_visibility="onchange")
    product_id = fields.Many2one('product.product', 'Product', track_visibility="onchange")
    # product_ids = fields.One2many('product.product', 'admission_id', 'Product')
    family_business = fields.Char(size=256, string='Family Business', readonly=False)
    family_income = fields.Float(string='Family Income', readonly=False)
    student_id = fields.Many2one('student.student', track_visibility="onchange", string='Students')
    mobile = fields.Char(size=12, string='Parent Mobile', track_visibility="onchange", states={'done': [('readonly', True)]})
    pickup_drop = fields.Many2one('res.area', 'Area', readonly=False, track_visibility="onchange")
    transportation_type = fields.Selection([('oneway_morning', 'One-way Morning'), ('oneway_evening', 'One-way Evening'), ('two_way', 'Two-Way')], track_visibility="onchange", string='Service Type', readonly=False)
    transport_id = fields.Many2one('transportation.transportation', 'Transport', track_visibility="onchange", readonly=False)
    #to do
    delivery_id = fields.Many2one('stock.picking', 'Delivery')
    invoice_id = fields.Many2one('account.move', 'Invoice')
    is_hostel = fields.Boolean('Hostel Required', readonly=False, help="Select this when we provide Hostel service to new student.")
    is_library = fields.Boolean('Library Required', readonly=False, help="Select this when we provide Hostel service to new student.")

    is_transportation = fields.Boolean('Transportation Required ?', readonly=False, track_visibility="onchange", help="Select this when we provide transport service to new student.")
    transportation_price = fields.Float('Transportation Price', readonly=False, track_visibility="onchange", default=0.0)
    semester_price = fields.Float('Semester Price', default=0.0, readonly=False, track_visibility="onchange")
    #to do
    hostel_price = fields.Float('Hostel Price', default=0.0, readonly=False)
    library_price = fields.Float('Library Price', default=0.0, readonly=False)
    library_deposit = fields.Float('Library Deposit', default=0.0, readonly=False)

    all_total_price = fields.Float(string='Total', compute='_total_price')
    is_user = fields.Boolean(string="Need To Create A Student User ?", track_visibility="onchange", readonly=False)
    partner_id = fields.Many2one(string='partner', track_visibility="onchange", related="student_id.partner_id")
    school_id = fields.Many2one('school.school', string='School Level', track_visibility="onchange",  readonly=False, default=lambda self: self.env.user.school_id)
    institute_id = fields.Many2one('res.company', string="Institute", track_visibility="onchange", readonly=False, domain="[('is_institute','=',True)]", default=lambda self: self.env.user.company_id)
    # Student’s general information
    parent_ids = fields.One2many('student.parent', 'admission_id' , string='Parents', readonly=False)

    f_id = fields.Char("Father Id Number", track_visibility="onchange", states={'done': [('readonly', True)]})
    # Student’s social data
    student_live = fields.Text("With whom student lives", readonly=False)
    is_parent_died = fields.Selection([('both', 'Both'), ('father', 'Father'), ('mother', 'Mother')], string="Is one of the parents died",  readonly=False)
    f_education = fields.Many2one("education.education", string="Father Education", readonly=False)
    m_education = fields.Many2one("education.education", string="Mother Education", readonly=False)
    total_fmember = fields.Integer('Total Family Members', size=3,  readonly=False)
    position_stud = fields.Selection([
            ('1', '1'),
            ('2', '2'),
            ('3', '3'),
            ('4', '4') ,
            ('5', '5'),
            ('6', '6'),
            ('7', '7'),
            ('8', '8'),
            ('9', '9')], string="Position of student in sequence",
          )
    # Learning difficulty
    is_fail = fields.Boolean(string="Did the student fail in any of the class?",  readonly=False)
    is_difficulty_subject = fields.Boolean(string="Does the student find any difficulty to learn a particular subject?",  readonly=False)
    is_out_talent = fields.Boolean(string="Is there outstanding talent for the student",  readonly=False)
    prev_academic_ids = fields.One2many('previous.academic.report', 'admission_id', string='Previous Academic Report',  readonly=False)
    prev_language_ids = fields.One2many('previous.languages', 'admission_id', string='Previous Languages',  readonly=False)
    # Health Information
    health_lines = fields.One2many('health.health', 'admission_id', string='Health',  readonly=False)
    countrys_id = fields.Many2one('res.country', 'Nationality (Country)', tracking=True,  readonly=False)
    # Student’s Books
    book_id = fields.Many2one('student.book', string="Books", track_visibility="onchange",  readonly=False)
    pick_count = fields.Integer(default=0, string='picking Count', compute=_compute_fees, copy=False)
    invo_count = fields.Integer(default=0, string='Invoice Count', compute=_compute_fees, copy=False)
    so_fees_count = fields.Integer(default=0, string='Fees Count', compute=_compute_fees, copy=False)
    reject_reason = fields.Text(string='Reject Reason', copy=False)
    is_parent_login = fields.Boolean(string="Is Login User", default=False, copy=False)
    parent_user_id = fields.Many2one('res.users', string="Parent User", copy=False)
    resp_user_id = fields.Many2one('res.users', string="Responsible Person", track_visibility="onchange", copy=False)
    acceptance_test_ids = fields.One2many('acceptance.test', 'admission_id', string="Acceptance Tests", required=True)
    temporary = fields.Char(string="Temporary")
    final = fields.Char(string="Final")
    attachment_file = fields.Binary(string="File")

    @api.model
    def create(self, vals):
        vals['is_user'] = True
        res = super(AdmissionAdmission, self).create(vals)
        if res.resp_user_id:
            res.message_subscribe(partner_ids=res.resp_user_id.partner_id.ids)
        return res

    def write(self, vals):
        for rec in self:
            if vals.get('resp_user_id') and vals['resp_user_id'] != rec.env.user.id:
                user = self.env['res.users'].browse(vals['resp_user_id'])
                rec.message_subscribe(partner_ids=[user.partner_id.id])
        return super(AdmissionAdmission, self).write(vals)

    @api.depends('name','application_number')
    def name_get(self):
        result = []
        for record in self:
            name = record.name or False
            if record.application_number:
                name = ''.join([name, ' [', record.application_number, ']'])
            result.append((record.id, name))
        return result

    @api.constrains('birth_date')
    def check_birth_date(self):
        if self.birth_date:
            if self.birth_date >= fields.Date.today():
                raise ValidationError(_('Birthdate must be less than current date!'))

    @api.onchange('transportation_type')
    def onchange_transportation_type(self):
        """
            Set transportation according to transportation type.
        """
        res = {}
        self.transport_id = False
        self.pickup_drop = False
        if self.transportation_type:
            res = {'domain': {'transport_id': [('transportation_type', '=', self.transportation_type)]}}
        return res

    def unlink(self):
        ''' remove record'''
        for rec in self:
            if rec.state != 'draft':
                raise Warning(_('You cannot remove the record in this state!'))
        return super(AdmissionAdmission, self).unlink()

    def copy(self, default=None):
        self.ensure_one()
        application_number = self.env['ir.sequence'].next_by_code('admission.admission')
        default = dict(default or {}, application_number=application_number)
        return super(AdmissionAdmission, self).copy(default)

    def _get_admission_product(self):
        ''' consider the transportation '''
        product_obj = self.env['product.product']
        products = product_obj.search([('include_in_admission', '=', True)]).ids
        # We will not consider transportation product here as we will calculate for that in onchange_transport_id method
        result = product_obj.search([('transport_fee', '=', True), ('include_in_admission', '=', False)])

        for rec in result:
            if rec.id in products:
                products.remove(rec.id)
        book_products = [self.book_id and self.book_id.id]
        if self.book_id:
            products.extend([self.book_id.product_id.id])
        products = self.env['product.product'].browse(products)
        return products

    @api.onchange('school_id')
    def onchange_school_id(self):
        """
            Set course according to stage.
        """
        institutes = []
        self.institute_id = False
        self.stage_id = False
        school_ids = False
        if self.school_id:
            school_ids = self.school_id.ids
            self.institute_id = self.school_id.institute_id.id
            institutes = self.institute_id.ids
        return {'domain':{'institute_id': [('id', 'in', institutes)], 'stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        """
            Set course according to stage.
        """
        self.course_id = False

    @api.onchange('course_id')
    def onchange_course_id(self):
        """
            Set batch according to course.
        """
        self.batch_id = False
        self.semester_id = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        """
            Set stage semester to batch.
        """
        semesters = []
        self.semester_id = False
        if self.batch_id:
            semesters = self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids
        return {'domain':{'semester_id': [('id', 'in', semesters)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        ''' Update the following fields when the semester_id is changed '''
        context = dict(self._context)
        self.division_id = False
        if not self.semester_id or not self.batch_id:
            self.division_id = False
            self.semester_price = 0.0
        class_ids = False

        if self.semester_id:
            divisions = self.semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.batch_id.id).mapped('division_ids')
            class_ids = divisions.filtered(lambda x: x.division_id and x.no_of_students < x.division_id.student_capacity).mapped('division_id').ids
            self.division_id = class_ids and class_ids[0]
            if self.course_id:
                product_ids = self._get_admission_product()
                if product_ids:
                    total_price = 0.0
                    context = {
                        'course_id': self.course_id.id or False,
                        'semester_id': self.semester_id.id or False,
                        'admission_date': self.admission_date or False,
                        'is_school_data': True,
                        'school_id': self.school_id.id
                        }
                    price_dict = product_ids.with_context(context).price_compute('list_price')
                    total_price = sum(price_dict.values())
                    self.semester_price = total_price
                    # self.division_id = False
        return {'domain':{'division_id': [('id', 'in', class_ids)]}}

    @api.onchange('is_transportation')
    def onchange_is_transportation(self):
        """
            Set transportation according to transportation.
        """
        self.transport_id = False
        self.pickup_drop = False
        self.transportation_type = False
        self.transport_price = 0.0

    @api.onchange('pickup_drop')
    def onchange_pickup_drop(self):
        """
            Set stop, transportation according to pickup_drop.
        """
        transport_ids = []
        transportation_obj = self.env['transportation.transportation']
        if not self.transportation_type:
            self.pickup_drop = False
            self.transport_id = False
        transportation_ids = transportation_obj.search([('transportation_type', '=', self.transportation_type)])
        for transport in transportation_ids:
            stop_ids = [stop.pickup_drop.id for stop in transport.stop] or []
            if self.pickup_drop.id in stop_ids:
                transport_ids.append(transport.id)
        self.transport_id = False
        return {'domain': {'transport_id':[('id', 'in', transport_ids)]}}

    @api.onchange('transport_id')
    def onchange_transport_id(self):
        """
            Set products according to transport.
        """
        context = dict(self._context)
        product_obj = self.env['product.product']
        product_id = product_obj.search([('transport_fee', '=', True)], limit=1)
        price = 0.0
        self.transportation_price = 0.0
        if self.transport_id:
            if not product_id:
                raise Warning(_('Please first configure transportation fees product.'))
            transport_product_id = product_id
            context = {
                'is_transportation': self.is_transportation,
                'pickup_drop': self.pickup_drop.id or False,
                'transport_id': self.transport_id.id or False,
                'admission_date': self.admission_date,
                'is_school_data': True,
                'school_id': self.school_id.id
            }
            if transport_product_id:
                price_dict = transport_product_id.with_context(context).price_compute('list_price')
                transport_price = sum(price_dict.values())
                self.transportation_price = transport_price

    # @api.constrains('mobile')
    # def _check_mobile_number(self):
    #     for obj in self:
    #         if obj.mobile and len(obj.mobile) != 12:
    #             raise ValidationError(_('Invalid Mobile Number! It must be of 12 digits!'))
    #     return True

    # @api.constrains('admission_date')
    # def _check_admission_date(self):
    #     for obj in self:
    #         if obj.admission_date < obj.batch_id.start_date or obj.admission_date > obj.batch_id.end_date:
    #             raise ValidationError(_('Selected Admission Date must be in range of batch start and end date!'))
    #     return True

    @api.constrains('admission_date', 'application_date')
    def _check_aplication_date(self):
        for obj in self:
            if obj.application_date > obj.admission_date:
                raise ValidationError(_('Application Date must be less then Admission Date!'))
        return True

    @api.constrains('transport_id')
    def _check_transport(self):
        for obj in self:
            if obj.transport_id and obj.transport_id.free_seats <= 0 :
                raise ValidationError(_('Please choose another transport. There is no more free seats!'))
        return True

    @api.onchange('division_id')
    def onchange_div_id(self):
        self.book_id = False
        if self.division_id and self.semester_id and self.batch_id and self.course_id and self.stage_id:
            book = self.env['student.book'].search([('division_id', '=', self.division_id.id),
            ('semester_id', '=', self.semester_id.id), ('batch_id', '=', self.batch_id.id),
            ('course_id', '=', self.course_id.id)], limit=1)
            self.book_id = book and book.id

    @api.onchange('middle_name')
    def onchange_middle_name(self):
        self.is_parent_login = False
        self.parent_user_id = False
        self.user_id = False
        if self.middle_name:
            self.mobile = self.middle_name.mobile
            self.email = self.middle_name.email
            if self.middle_name.user_id:
                self.is_parent_login = True
                self.parent_user_id = self.middle_name.user_id.id
                self.user_id = self.middle_name.user_id.id
        else:
            return {
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'res.partner',
                'views': [(False, 'form')],
                'view_id': False,
                'target': 'new',
            }

    def create_parent_login(self):
        self.ensure_one()
        if self.middle_name and self.middle_name.user_id:
            self.is_parent_login = True
            self.parent_user_id = self.middle_name.user_id.id
            self.user_id = self.middle_name.user_id.id
        elif self.middle_name and not self.is_parent_login and not self.parent_user_id  and not self.middle_name.user_id:
            # Create Parent User Creation code
            parent_group_id = self.env.ref('sync_ems.group_parent').id
            portal_id = self.env.ref('base.group_portal').id
            value = {
                'partner_id': self.middle_name.id,
                'name': self.middle_name.name,
                'login': self.middle_name.email,
                'email': self.middle_name.email,
                'company_id': self.institute_id.id,
                'company_ids': [(6, 0, self.institute_id.ids)],
                'school_id': self.school_id.id,
                'allowed_school_ids': [(6, 0, self.school_id.ids)]
             }
            if self.middle_name.is_parent:
                value.update({'groups_id': [(6, 0, [parent_group_id, portal_id])]})

            user_id = self.env['res.users'].sudo().search([('partner_id', '=', self.middle_name.id)], limit=1)
            if not user_id:
                user_id = self.env['res.users'].sudo().create(value)
            else:
                user_id.sudo().write({
                    'company_ids': [(4, self.institute_id.id)],
                    'allowed_school_ids': [(4, self.school_id.id)],
                })
            try:
                user_id.with_context(create_user=True).sudo().action_reset_password()
            except:
                pass
            self.is_parent_login = True
            self.parent_user_id = user_id.id
            self.user_id = user_id.id
            self.middle_name.user_id = user_id.id
        if self.is_parent_login and self.parent_user_id:
            mail_template_id = self.env.ref('sync_ems_admission.mail_template_for_login_admission_user')
            # Mail For Login User Appliction
            if mail_template_id:
                mail_template_id.sudo().send_mail(self.id, force_send=False, raise_exception=False)
            # Send MSG For Login User Appliction
            self.sudo()._message_sms_with_template(
                template_xmlid='sync_ems_admission.sms_template_for_login_admission_user',
                template_fallback=_("SMS for Login User: %s, %s.") % (self.middle_name.name, self.admission_date),
                partner_ids=self.middle_name and self.middle_name.ids,
                put_in_queue=False
            )

    def submit(self):
        self.ensure_one()
        if self.application_number == _('/') or not self.application_number:
            application_number = self.env['ir.sequence'].next_by_code('admission.admission') or _('/')
            self.sudo().write({'application_number': application_number})
        mail_template_id = self.env.ref('sync_ems_admission.submit_admission_request_send_email')
        # Mail For Submit Appliction
        if mail_template_id:
            mail_template_id.sudo().send_mail(self.id, force_send=False, raise_exception=False)
        # Send MSG For Submit Appliction
        self.sudo()._message_sms_with_template(
            template_xmlid='sync_ems_admission.sms_template_for_admission_submit',
            template_fallback=_("Appliction for Submit: %s, %s.") % (self.middle_name.name, self.admission_date),
            partner_ids=self.middle_name and self.middle_name.ids,
            put_in_queue=False
        )
        return self.sudo().write({'state': 'pending'})

    def confirm_rejected(self):
        self.ensure_one()
        return self.write({'state': 'reject'})

    def confirm_cancel(self):
        self.ensure_one()
        return self.write({'state': 'cancel'})

    def reset_to_draft(self):
        self.ensure_one()
        return self.write({'state': 'draft'})

    def initial_acceptance(self):
        self.ensure_one()
        return self.write({'state': 'initial_acceptance'})

    def academic_acceptance(self):
        self.ensure_one()
        if not self.acceptance_test_ids:
            raise ValidationError(_('Acceptance Tests cannnot be empty'))
        enrollment_no = self.enrollment_no
        if enrollment_no == '/':
            enrollment_no = self.env['ir.sequence'].next_by_code('enrollment.number')
        mail_template_id = self.env.ref('sync_ems_admission.initial_acceptance_admission_send_email')
        # Mail For Submit Appliction
        if mail_template_id:
            mail_template_id.send_mail(self.id, force_send=True, raise_exception=False)
        # Send MSG For Submit Appliction
        self._message_sms_with_template(
            template_xmlid='sync_ems_admission.sms_template_for_admission_initial_acceptance',
            template_fallback=_("Application for Initial Acceptance: %s, %s.") % (self.middle_name.name, self.admission_date),
            partner_ids=self.middle_name and self.middle_name.ids,
            put_in_queue=False
        )
        return self.write({'state': 'academic_acceptance', 'enrollment_no': enrollment_no})

    def proceed_payment(self):
        self.ensure_one()
        if not self.acceptance_test_ids:
            raise ValidationError(_('Acceptance Tests cannnot be empty'))
        return self.write({'state': 'proceed_payment'})

    def paid(self):
        self.ensure_one()
        # Send MSG For Payment Appliction
        self._message_sms_with_template(
            template_xmlid='sync_ems_admission.sms_template_data_registration_payment_info',
            template_fallback=_("Registration Payment Information: %s, %s.") % (self.middle_name.name, self.admission_date),
            partner_ids=self.middle_name and self.middle_name.ids,
            put_in_queue=False
        )
        return self.action_payment_send()#self.write({'state': 'done'})

    def action_payment_send(self):
        ''' Opens a wizard to compose an email, with relevant mail template loaded by default '''
        self.ensure_one()
        template_id = self.env.ref('sync_ems_admission.mail_template_data_registration_payment_info')
        # template_id = self._find_mail_template()
        lang = self.env.context.get('lang')
        if template_id.lang:
            lang = template_id._render_template(template_id.lang, 'admission.admission', self.ids[0])
        ctx = {
            'default_model': 'admission.admission',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id.id),
            'default_template_id': template_id and template_id.id,
            'default_composition_mode': 'comment',
            'custom_layout': "mail.mail_notification_paynow",
            'force_email': True,
        }
        self.write({'state': 'done'})
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def open_student(self):
        self.ensure_one()
        action = self.env.ref('sync_ems.act_open_student_view').read()[0]

        if len(self.student_id.ids) > 1:
            action['domain'] = [('id', 'in', self.student_id.ids)]
        elif len(self.student_id) == 1:
            action['views'] = [(self.env.ref('sync_ems.view_student_student_form').id, 'form')]
            action['res_id'] = self.student_id.id
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def _get_date_planned(self, company_id, product, application_date):
        """
            get sale order data planned.
        """
        # start_date = self.env['sale.order'].date_to_datetime(self.application_date)
        date_planned = application_date + timedelta(days=product.sale_delay)
        date_planned = (date_planned - timedelta(days=company_id.security_lead)).strftime(DEFAULT_SERVER_DATE_FORMAT)
        return date_planned

    def action_view_invoice(self):
        ''' open a view on one of the given partner_id '''
        action = self.env.ref('account.action_move_out_invoice_type').read()[0]
        partner_id = self.student_id and self.student_id.partner_id.id or False
        action['domain'] = [('type', 'in', ['out_invoice', 'in_invoice', 'in_refund', 'out_refund'])]
        invoice_ids = self.env['account.move'].search([('partner_id', '=', partner_id)]).ids
        if len(invoice_ids) > 1:
            action['domain'] = [('type', 'in', ['out_invoice', 'in_invoice', 'in_refund', 'out_refund']), ('id', 'in', invoice_ids)]
        elif len(invoice_ids) == 1:
            action['views'] = [(self.env.ref('account.view_move_form').id, 'form')]
            action['res_id'] = invoice_ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def action_view_picking(self):
        ''' open a view on one of the given partner_id '''
        action = self.env.ref('stock.action_picking_tree_all').read()[0]
        partner_id = self.student_id and self.student_id.partner_id.id or False

        picking_ids = self.env['stock.picking'].search([('partner_id', '=', partner_id)]).ids
        if len(picking_ids) > 1:
            action['domain'] = [('id', 'in', picking_ids)]
        elif len(picking_ids) == 1:
            action['views'] = [(self.env.ref('stock.view_picking_form').id, 'form')]
            action['res_id'] = picking_ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def action_view_so_fees(self):
        ''' open a view on one of the given partner_id '''
        action = self.env.ref('sync_ems.action_quotations_fees').read()[0]
        partner_id = self.student_id and self.student_id.partner_id.id or False
        sale_ids = self.env['sale.order'].search([('partner_id', '=', partner_id), ('fee', '=', True)]).ids
        if len(sale_ids) > 1:
            action['domain'] = [('id', 'in', sale_ids)]
        elif len(sale_ids) == 1:
            action['views'] = [(self.env.ref('sync_ems.fee_view_order_form').id, 'form')]
            action['res_id'] = sale_ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def proceed_fee(self):
        """
            Set fees Process.
        """
        if not self.acceptance_test_ids:
            raise ValidationError(_('Acceptance Tests cannnot be empty'))
        context = dict(self._context)
        student_obj = self.env['student.student']
        for rec in self:
            relationship = self.env.ref('sync_ems.studeent_relationship_father')
            vals = {
                'title': rec.title and rec.title.id or False,
                'first_name': rec.name or False,
                'middle_name': rec.middle_name and rec.middle_name.id or False,
                'last_name': rec.last_name,
                'birth_date':rec.birth_date,
                'gender': rec.gender,
                'stage_id': rec.stage_id and rec.stage_id.id or False,
                'course_id': rec.course_id and rec.course_id.id or False,
                'batch_id': rec.batch_id and rec.batch_id.id or False,
                'semester_id': rec.semester_id and rec.semester_id.id or False,
                'division_id': rec.division_id and rec.division_id.id or False,
                'religion': rec.religion_id and rec.religion_id.id or False,
                'photo': rec.photo or False,
                'enrollment_no': rec.enrollment_no or False,
                'type': 'contact',
                'street': rec.street or False,
                'street2': rec.street2 or False,
                'phone': rec.phone or False,
                'mobile': rec.mobile or False,
                'zip': rec.zip or False,
                'city': rec.city or False,
                'email':rec.email or False,
                'personal_email':rec.personal_email or False,
                'country_id': rec.country_id and rec.country_id.id or False,
                'state_id': rec.state_id and rec.state_id.id or False,
                'institute_id': rec.institute_id and rec.institute_id.id or False,
                'pickup_drop': rec.pickup_drop and rec.pickup_drop.id or False,
                'transportation_type': rec.transportation_type,
                'transport_id': rec.transport_id and rec.transport_id.id or False,
                'parent_ids': [(6, 0, rec.parent_ids and rec.parent_ids.ids)],
                'health_lines': [(6, 0, rec.health_lines and rec.health_lines.ids)],
                'countrys_id': rec.countrys_id and rec.countrys_id.id,
                'school_id': rec.school_id and rec.school_id.id,
                'admission_date': rec.admission_date,
                'book_id': rec.book_id.id,
                'acceptance_test_ids': [(6, 0, rec.acceptance_test_ids and rec.acceptance_test_ids.ids)],
                'temporary':rec.temporary or False,
                'final':rec.final or False,
                'attachment_file':rec.attachment_file or False
            }
            # -- Code commented for elective subjects update --
            if rec.semester_id and rec.semester_id.semester_history_ids:
                # subjects = rec.semester_id.semester_history_ids.mapped('subject_ids').filtered(lambda l: l.subject_type == 'elective' and not l.is_extra_subject).ids
                extra_subjects = rec.semester_id.semester_history_ids.mapped('subject_ids').filtered(lambda l: l.is_extra_subject).ids
                vals.update({
                    # 'optional_subject_ids': subjects,
                    'extra_subject_ids': extra_subjects
                })

            # if rec.is_hostel:
            #     vals.update({
            #         'duration': rec.duration or False,
            #         'discharge_date': rec.discharge_date,
            #         'hostel_id': rec.hostel_id and rec.hostel_id.id or False,
            #         'building_id': rec.building_id and rec.building_id.id or False,
            #         'section_id': rec.section_id and rec.section_id.id or False,
            #         'floor_id': rec.floor_id and rec.floor_id.id or False,
            #         'room_id': rec.room_id and rec.room_id.id or False,
            #         })

            # if rec.is_library:
            #     vals.update({
            #         'library_duration': rec.library_duration or False,
            #         'member_type_id': rec.member_type_id and rec.member_type_id.id or False,
            #         'regi_from': rec.regi_from or False,
            #         'regi_to': rec.regi_to or False
            #         })

            # Creating Student Record
            new_student = False
            if not rec.student_id:
                new_student = student_obj.with_context({'is_student': True, 'is_user': rec.is_user, 'library_user': rec.is_library, 'enrollment_no': rec.enrollment_no}).create(vals)
                rec.student_id = new_student and new_student.id
            else:
                rec.student_id.write(vals)
            # if rec.is_hostel:
            #     vals = {
            #         'firstname': rec.name or False,
            #         'middlename': rec.middle_name and rec.middle_name.name or False,
            #         'lastname': rec.last_name,
            #         'birthdate':rec.birth_date,
            #         'gender': rec.gender,
            #         'institute': rec.stage_id.institute_id and rec.stage_id.institute_id.name or False,
            #         'course': rec.course_id and rec.course_id.name or False,
            #         'batch': rec.batch_id and rec.batch_id.name or False,
            #         'semester': rec.semester_id and rec.semester_id.name or False,
            #         'division_id': rec.section_id and rec.section_id.id or False,
            #         'partner_ids': new_student.partner_id and new_student.partner_id.id or False,
            #         'related_user': new_student.user_id and new_student.user_id.id or False,
            #         'photo': rec.photo or False,
            #         'registration_no': rec.enrollment_no or False,
            #         'fees': rec.fees,
            #         'street': rec.street or False,
            #         'street2': rec.street2 or False,
            #         'phone': rec.phone or False,
            #         'mobile': rec.mobile or False,
            #         'email': rec.email or False,
            #         'zip': rec.zip or False,
            #         'city': rec.city or False,
            #         'nationality': rec.country_id and rec.country_id.id or False,
            #         'country_id': rec.country_id and rec.country_id.id or False,
            #         'state_id': rec.state_id and rec.state_id.id or False,
            #         'discharge_date': rec.discharge_date,
            #         'admission_date': rec.admission_date,
            #         'hostel_id': rec.hostel_id and rec.hostel_id.id or False,
            #         'building_id': rec.building_id and rec.building_id.id or False,
            #         'division_id': rec.section_id and rec.section_id.id or False,
            #         'floor_id': rec.floor_id and rec.floor_id.id or False,
            #         'room_id': rec.room_id and rec.room_id.id or False,
            #         }
            #     member_id = rec.env['member.information'].with_context({'is_member': True}).create(vals)
            #     if member_id:
            #         new_student.is_member = True
            # if rec.is_library:
            #     vals = {
            #         'firstname': rec.name or False,
            #         'middlename': rec.middle_name and rec.middle_name.name or False,
            #         'lastname': rec.last_name or False,
            #         'membership_no': rec.enrollment_no or False,
            #         'image': rec.photo,
            #         'mobile': rec.mobile or False,
            #         'title': rec.title and rec.title.id or False,
            #         'gender' :rec.gender or False,
            #         'birthdate' :rec.birth_date or False,
            #         'member_fees':rec.library_price or False,
            #         'nationality' :rec.country_id and rec.country_id.id or False,
            #         'partner_id': new_student.partner_id and new_student.partner_id.id or False,
            #         'street' :rec.street or False,
            #         'street2':rec.street2 or False,
            #         'city' :rec.city or False,
            #         'zip' :rec.zip or False,
            #         'state_id' :rec.state_id and rec.state_id.id or False,
            #         'country_id' :rec.country_id and rec.country_id.id or False,
            #         'phone':rec.phone or False,
            #         'contact' :rec.phone or False,
            #         'email':rec.email or False,
            #         'type_id': rec.member_type_id and rec.member_type_id.id or False,
            #         'regi_from': rec.regi_from or False,
            #         'regi_to' : rec.regi_to or False,
            #         'duration':rec.library_duration or False,
            #         'company_id' : rec.stage_id.institute_id and rec.stage_id.institute_id.id or False,
            #         'library_subscriber': True
            #         }
            #     library_member_id = rec.env['library.member'].with_context({'is_student': True}).create(vals)
            #     if library_member_id:
            #         new_student.library_member_id = library_member_id.id

            analytic_parent = new_student and new_student.course_id and new_student.course_id.analytic_account_id or False

            if not rec.student_id:
                new_student.write({'analytic_account_id': analytic_parent and analytic_parent.id})
                rec.partner_id = new_student and new_student.partner_id.id or False
            else:
                rec.partner_id = rec.student_id and rec.student_id.id or False
                if rec.student_id.analytic_account_id:
                    analytic_parent = rec.student_id.analytic_account_id.id
                else:
                    rec.student_id.analytic_account_id = analytic_parent and analytic_parent.id
            if rec.student_id and rec.student_id.user_id:
                mail_template_id = self.env.ref('sync_ems_admission.mail_template_for_login_student_user')
                # Mail For Login User Appliction
                if mail_template_id:
                    mail_template_id.sudo().send_mail(rec.id, force_send=False, raise_exception=False)
                # Send MSG For Login User Appliction
                self.sudo()._message_sms_with_template(
                    template_xmlid='sync_ems_admission.sms_template_for_login_admission_student_user',
                    template_fallback=_("SMS for Student Login User: %s, %s.") % (rec.middle_name.name, rec.admission_date),
                    partner_ids=rec.middle_name and rec.middle_name.ids,
                    put_in_queue=False
                )

            context.update({
                'admission':'admission',
                'course_id': rec.course_id and rec.course_id.id or False,
                'semester_id': rec.semester_id and rec.semester_id.id or False,
                'admission_date': rec.admission_date,
                'pickup_drop': rec.pickup_drop and rec.pickup_drop.id or False,
                'transport_id': rec.transport_id and rec.transport_id.id or False,
                'is_school_data': True,
                'school_id': rec.school_id and rec.school_id.id or False,
            })
            # # if rec.is_hostel:
            # #     context.update({'duration':rec.duration or False})
            products = rec._get_admission_product()

            form_view = self.env.ref('sync_ems.fee_view_order_form')
            tree_view = self.env.ref('sync_ems.view_fee_quotation_tree')
            context.update({'partner_id': rec.student_id and rec.student_id.partner_id.id or False})
            if products:
                context.update({'products': products.ids})
            value = {
                'view_mode': 'form',
                'res_model': 'sale.order',
                'view_id': False,
                'views': [(form_view and form_view.id or False, 'form'),
                          (tree_view and tree_view.id or False, 'tree')],
                'type': 'ir.actions.act_window',
                'target': 'current',
                'nodestroy': True,
                'context': context,
            }
            return value
