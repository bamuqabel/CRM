# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class AccountAnalyticAccount(models.Model):
    _inherit = 'account.analytic.account'

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        ''' Returns a list name containing id, name'''
        context = dict(self._context)
        args = args or []
        if context.get('is_student', False):
            if not context.get('partner_id', True):
                args[args.index([i for i in args if i[0]=='partner_id'][0])][1] = '!='
            student_ids = self.env['student.student'].search([])
            analytic_ids = []
            for student in student_ids:
                if student.analytic_account_id:
                    analytic_ids.append(student.analytic_account_id.id)
            args.append(('id', 'in', analytic_ids))
        return super(AccountAnalyticAccount, self)._name_search(name=name, args=args, operator=operator, limit=limit, name_get_uid=name_get_uid)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: