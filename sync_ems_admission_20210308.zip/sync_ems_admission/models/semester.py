# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


class SemesterHistory(models.Model):
    _inherit = 'semester.history'
    _description = 'Semester History'

    payment_term_id = fields.Many2one('account.payment.term', string='Payment Term')
