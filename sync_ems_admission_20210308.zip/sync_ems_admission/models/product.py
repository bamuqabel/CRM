# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _


# class ProductTemplate(models.Model):
#     _inherit = "product.template"

#     def price_compute(self, price_type, uom=False, currency=False, company=False):
#         # TDE FIXME: delegate to template or not ? fields are reencoded here ...
#         # compatibility about context keys used a bit everywhere in the code
#         context = dict(self._context)
#         fiscalyear_obj = self.env['account.fiscalyear']
#         product_price_obj = self.env['product.product.price']
#         fee_price_obj = self.env['product.product.fee.price']
#         area_obj = self.env['res.area']
#         transport_obj = self.env['transportation.transportation']

#         if context.get('is_school_data', False):
#             if not uom and context.get('uom'):
#                 uom = self.env['uom.uom'].browse(context['uom'])
#             if not currency and context.get('currency'):
#                 currency = self.env['res.currency'].browse(context['currency'])

#             templates = self
#             if price_type == 'standard_price':
#                 # standard_price field can only be seen by users in base.group_user
#                 # Thus, in order to compute the sale price from the cost for users not in this group
#                 # We fetch the standard price as the superuser
#                 templates = self.with_context(force_company=company and company.id or context.get('force_company', self.env.company.id)).sudo()
#             if not company:
#                 if context.get('force_company'):
#                     company = self.env['res.company'].browse(context['force_company'])
#                 else:
#                     company = self.env.company
#             date = context.get('date') or fields.Date.today()

#             prices = dict.fromkeys(self.ids, 0.0)
#             for template in templates:
#                 prices[template.id] = template[price_type] or 0.0
#                 # yes, there can be attribute values for product template if it's not a variant YET
#                 # (see field product.attribute create_variant)
#                 if context.get('admission'):
#                     if template.other_fee:
#                         current_date = context.get('admission_date')
#                         fiscal_year = fiscalyear_obj.search([('start_date', '<=', current_date), ('end_date', '>=', current_date)], limit=1)
#                         if fiscal_year and template:
#                             fee_ids = template.fee_ids.filtered(lambda x: x.product_id.id == template.id and x.fiscalyear_id.id == fiscal_year.id)
#                             fees = fee_ids.mapped('fee_price_ids')
#                             if course_id and semester_id and school_id:
#                                 fee_prices = fees.filtered(lambda x: x.course_id.id == course_id and x.semester_id.id == semester_id and x.school_id.id == school_id).mapped('fee')
#                                 prices[template.id] = fee_prices and max(fee_prices) or template.list_price
#                             else:
#                                 prices[template.id] = template.list_price
#                         # fiscal_year = fiscalyear_obj.search([('start_date', '<=', current_date), ('end_date', '>=', current_date)], limit=1)
#                         # product_price_id = product_price_obj.search([('product_id', '=', template.id), ('fiscalyear_id', '=', fiscal_year.id)], limit=1)
#                         # if product_price_id:
#                         #     course_id = context.get('course_id', False)
#                         #     semester_id = context.get('semester_id', False)
#                         #     school_id = context.get('school_id', False)
#                         #     fee_domain = [
#                         #         ('product_price_id', '=', product_price_id.id),
#                         #         ('course_id', '=', course_id),
#                         #         ('semester_id', '=', semester_id),
#                         #         ('school_id', '=', school_id)
#                         #     ]
#                         #     fee_price_id = fee_price_obj.search(fee_domain, limit=1)
#                         #     prices[template.id] = fee_price_id and fee_price_id.fee or 0.0
#                     elif template.transport_fee:
#                         student_id = self.env['student.student'].search([('partner_id', '=', context.get('partner_id', False))], limit=1)
#                         if student_id:
#                             transportation_cost = student_id.transport_id and student_id.transport_id.cost or 0.0
#                             if student_id.pickup_drop:
#                                 stop_id = self.env['stop.stop'].search([('pickup_drop', '=', student_id.pickup_drop.id)], limit=1)
#                                 transportation_cost = stop_id and stop_id.cost
#                             prices[template.id] = transportation_cost or template[price_type]  or 0.0
#                         elif context.get('pickup_drop', False) and context.get('transport_id', False):
#                             pickup_id = area_obj.browse(context.get('pickup_drop'))
#                             transport_id = transport_obj.browse(context.get('transport_id'))
#                             transportation_cost = transport_id and transport_id.cost
#                             if pickup_id:
#                                 stop_id = self.env['stop.stop'].search([('pickup_drop', '=', pickup_id.id)], limit=1)
#                                 transportation_cost = stop_id and stop_id.cost
#                             prices[template.id] = transportation_cost or template[price_type]
#                 if price_type == 'list_price' and context.get('current_attributes_price_extra'):
#                     # we have a list of price_extra that comes from the attribute values, we need to sum all that
#                     prices[template.id] += sum(context.get('current_attributes_price_extra'))

#                 if uom:
#                     prices[template.id] = template.uom_id._compute_price(prices[template.id], uom)

#                 # Convert from current user company currency to asked one
#                 # This is right cause a field cannot be in more than one currency
#                 if currency:
#                     prices[template.id] = template.currency_id._convert(prices[template.id], currency, company, date)

#             return prices
#         else:
#             return super(ProductTemplate, self).price_compute(price_type=price_type, uom=uom, currency=currency, company=company)


class ProductProduct(models.Model):
    _inherit = 'product.product'

    fee_ids = fields.One2many('product.product.price', 'product_id', 'Fees')
    other_fee = fields.Boolean('Other Fee', default=False)
    transport_fee = fields.Boolean('Transportation Fee', default=False)
    include_in_admission = fields.Boolean('Include in Admission', default=False)
    include_in_delivery = fields.Boolean('Include in Delivery')
    include_in_migration = fields.Boolean('Include in Migration')
    admission_id = fields.Many2one('admission.admission', 'Admission')
    is_admission_flag = fields.Boolean(string='Admission Flag')

    @api.model
    def create(self, vals):
        """ create transport_fee """
        if vals.get('other_fee', False) or vals.get('transport_fee', False):
            vals.update({'type': 'service'})
        return super(ProductProduct, self).create(vals)

    def write(self, vals):
        """ If updating transport_fee . """
        if vals.get('other_fee', False) or vals.get('transport_fee', False):
            vals.update({'type': 'service'})
        return super(ProductProduct, self).write(vals)

    @api.onchange('other_fee')
    def onchange_other_fee(self):
        """
            Set service according to other_fee.
        """
        if not self.other_fee and not self.transport_fee:
            self.include_in_admission = False
        if self.other_fee:
            self.type = 'service'
            self.transport_fee = False

    @api.onchange('transport_fee')
    def onchange_transport_fee(self):
        """
            Set other_fee according to transport_fee.
        """
        if not self.other_fee and not self.transport_fee:
            self.include_in_admission = False
        if self.transport_fee:
            uom_id = self.env['uom.uom'].search([('name', '=', 'Month(s)')], limit=1)
            self.uom_id = uom_id and uom_id.id or False
            self.type = 'service'
            self.other_fee = False

    def price_compute(self, price_type, uom=False, currency=False, company=False):
        # TDE FIXME: delegate to template or not ? fields are reencoded here ...
        # compatibility about context keys used a bit everywhere in the code
        context = dict(self._context)
        fiscalyear_obj = self.env['account.fiscalyear']
        product_price_obj = self.env['product.product.price']
        fee_price_obj = self.env['product.product.fee.price']
        area_obj = self.env['res.area']
        transport_obj = self.env['transportation.transportation']

        if context.get('is_school_data', False):
            if not uom and self._context.get('uom'):
                uom = self.env['uom.uom'].browse(self._context['uom'])
            if not currency and self._context.get('currency'):
                currency = self.env['res.currency'].browse(self._context['currency'])

            products = self
            if price_type == 'standard_price':
                # standard_price field can only be seen by users in base.group_user
                # Thus, in order to compute the sale price from the cost for users not in this group
                # We fetch the standard price as the superuser
                products = self.with_context(force_company=company and company.id or self._context.get('force_company', self.env.company.id)).sudo()

            prices = dict.fromkeys(self.ids, 0.0)
            course_id = context.get('course_id', False)
            semester_id = context.get('semester_id', False)
            school_id = context.get('school_id', False)
            for product in products:
                prices[product.id] = product[price_type] or 0.0
                if product.other_fee:
                    current_date = context.get('admission_date')
                    fiscal_year = fiscalyear_obj.search([('start_date', '<=', current_date), ('end_date', '>=', current_date)], limit=1)
                    if fiscal_year and product:
                        fee_ids = product.fee_ids.filtered(lambda x: x.product_id.id == product.id and x.fiscalyear_id.id == fiscal_year.id)
                        fees = fee_ids.mapped('fee_price_ids')
                        if course_id and semester_id and school_id:
                            fee_prices = self.env['product.product.fee.price'].sudo().search([('id', 'in', fees.ids),
                                ('course_id', '=', course_id), ('semester_id', '=', semester_id), ('school_id', 'parent_of', school_id)]).mapped('fee')
                            price_unit = fee_prices and max(fee_prices) or product.list_price
                            prices[product.id] = price_unit
                        else:
                            prices[product.id] = product.list_price
                elif product.transport_fee:
                    student_id = self.env['student.student'].search([('partner_id', '=', context.get('partner_id', False))], limit=1)
                    if student_id:
                        transportation_cost = student_id.transport_id and student_id.transport_id.cost or 0.0
                        if student_id.pickup_drop:
                            stop_id = self.env['stop.stop'].search([('pickup_drop', '=', student_id.pickup_drop.id)], limit=1)
                            transportation_cost = stop_id and stop_id.cost
                        prices[product.id] = transportation_cost or product[price_type]  or 0.0
                    elif context.get('pickup_drop', False) and context.get('transport_id', False):
                        pickup_id = area_obj.browse(context.get('pickup_drop'))
                        transport_id = transport_obj.browse(context.get('transport_id'))
                        transportation_cost = transport_id and transport_id.cost
                        if pickup_id:
                            stop_id = self.env['stop.stop'].search([('pickup_drop', '=', pickup_id.id)], limit=1)
                            transportation_cost = stop_id and stop_id.cost
                        prices[product.id] = transportation_cost or product[price_type]
                elif context.get('duration', False) and product.is_room:
                    if context['duration'] == 'y':
                        res[product.id] = product[price_type]
                    if context['duration'] == 'hy':
                        res[product.id] = product[price_type]/2
                    if context['duration'] == 'q':
                        res[product.id] = product[price_type]/4

                if price_type == 'list_price':
                    prices[product.id] += product.price_extra
                    # we need to add the price from the attributes that do not generate variants
                    # (see field product.attribute create_variant)
                    if self._context.get('no_variant_attributes_price_extra'):
                        # we have a list of price_extra that comes from the attribute values, we need to sum all that
                        prices[product.id] += sum(self._context.get('no_variant_attributes_price_extra'))

                if uom:
                    prices[product.id] = product.uom_id._compute_price(prices[product.id], uom)

                # Convert from current user company currency to asked one
                # This is right cause a field cannot be in more than one currency
                if currency:
                    prices[product.id] = product.currency_id._convert(
                        prices[product.id], currency, product.company_id, fields.Date.today())
            return prices
        else:
            return super(ProductProduct, self).price_compute(price_type=price_type, uom=uom, currency=currency, company=company)


class AccountFiscalyear(models.Model):
    _name = 'account.fiscalyear'
    _description = 'Account Fiscalyear'

    name = fields.Char(string='Name', required=True)
    code = fields.Char(string='Code', required=True)
    start_date = fields.Date(string='Start Date', required=True)
    end_date = fields.Date(string='End Date', required=True)

    # _sql_constraints = [
    #     ('unique_name', 'unique(name)', 'Name must be unique.'),
    #     ('unique_code', 'unique(code)', 'Code must be unique.')
    #     ]


class ProductProductPrice(models.Model):
    _name = 'product.product.price'
    _description = 'Product Price'

    fiscalyear_id = fields.Many2one('account.fiscalyear', 'Fiscal Year', required=True)
    product_id = fields.Many2one('product.product', 'Product')
    fee_price_ids = fields.One2many('product.product.fee.price', 'product_price_id', string='Fees')


class ProductProductFeePrice(models.Model):
    _name = 'product.product.fee.price'
    _description = 'Product Fee Price'

    product_price_id = fields.Many2one('product.product.price', required=True, string="Product Price")
    course_id = fields.Many2one('course.course', string='Course')
    semester_id = fields.Many2one('semester.semester', string='Standard')
    school_id = fields.Many2one('school.school', string='School', default=lambda self: self.env.user.school_id)
    fee = fields.Float('Fee', required=True)

    @api.onchange('course_id')
    def onchange_course_id(self):
        """
            Set semester according to course.
        """
        semesters = []
        self.semester_id = False
        if self.course_id:
            semesters = self.env['semester.semester'].search([('course_id', '=', self.course_id.id)]).ids
        return {'domain': {'semester_id': [('id', 'in', semesters)]}}
