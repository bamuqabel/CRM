# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import except_orm


class AccountPayment(models.Model):
    _inherit = "account.payment"

    def post(self):
        """" create a payment  """
        context = dict(self._context)
        res = super(AccountPayment, self).post()
        prec = self.env['decimal.precision'].precision_get('Account')
        total_fixed = 0
        total_percent = 0
        total_balance = 0
        min_amount = 0
        invoice = self.env['account.move'].browse(context.get('active_id', False))
        for line in invoice.invoice_payment_term_id.line_ids:
            if line.days == 0:
                if line.value == 'fixed':
                    total_fixed += line.value_amount
                if line.value == 'procent':
                    total_percent += (line.value_amount*invoice.amount_total)
                elif line.value == 'balance':
                    total_balance += line.value_amount
        if total_fixed:
            min_amount = round(total_fixed, prec)
        elif total_percent:
            min_amount = round(total_percent, prec)
        elif total_balance:
            min_amount = round(total_balance, prec)
        student_id = self.env['student.student'].search([('partner_id', '=', self.partner_id.id), ('is_enrolled', '=', False)], limit=1)
        if student_id:
            if self.amount < min_amount:
                raise except_orm(_('Minimum allowed payment'),
                            _("Minimum allowed payment to enrolled the student is: %s") % (min_amount,))
            else:
                student_id = self.env['student.student'].search([('partner_id', '=', self.partner_id.id)])
                if student_id:
                    admission_invoice = self.env['admission.admission'].search([('student_id', '=', student_id.id)])
                    student_values = {'is_enrolled': True}
                    stand_div_id = self.env['semester.history'].search([('semester_id', '=', student_id.semester_id.id), ('batch_id', '=', student_id.batch_id.id)], limit=1)
                    if stand_div_id:
                        stand_div_div_id = self.env['semester.division'].search([('semester_division_id', '=', stand_div_id.id), ('division_id', '=', student_id.division_id.id)], limit=1)
                        student_values.update({'standard_division_id': stand_div_div_id and stand_div_div_id.id or False})
                        if student_id.transport_id and student_id.pickup_drop:
                            stop_id = self.env['stop.stop'].search([('transport_id', '=', student_id.transport_id.id), ('pickup_drop', '=', student_id.pickup_drop.id)], limit=1)
                            student_values.update({'stop_id': stop_id and stop_id.id or False})
                    student_id.write(student_values)
        return res

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: