# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

import time
from odoo import models, fields, api

class WizStudentFinancialReport(models.Model):
    _name = 'wiz.student.financial.report'

    stage_id = fields.Many2one('stage.stage', string='Stage')
    course_id = fields.Many2one('course.course', string='Course')
    batch_id = fields.Many2one('batch.batch', string='Batch')
    semester_id = fields.Many2one('semester.semester', string='Standard')
    division_id = fields.Many2many('division.division', string='Division')

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        """
            Set course according to stage.
        """
        self.course_id = False
        if not self.stage_id:
            self.course_id = False

    @api.onchange('course_id')
    def onchange_course_id(self):
        """
            Set batch according to course.
        """
        self.batch_id = False
        self.semester_id = False
        if not self.course_id:
            self.batch_id = False
            self.semester_id = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        """
            Set semester according to batch.
        """
        self.semester_id = False
        return {'domain':{'semester_id': [('id', 'in', self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        """
            Set division according to semester.
        """
        self.division_id = False
        if not self.semester_id or not self.batch_id:
            self.division_id = False
            return {'domain':{'division_id': [('id', 'in', [])]}}
        division_id = False
        res = {'domain':{}}
        if self.semester_id and self.batch_id:
            class_ids = []
            semester_id = self.env['semester.semester'].browse(self.semester_id.id)
            for division in semester_id.semester_history_ids:
                if division.batch_id.id == self.batch_id.id:
                    class_ids = [div.division_id.id for div in division.division_ids if div.division_id]
            res['domain'].update({'division_id':[('id', 'in', class_ids)]})
        return res

    def print_report(self):
        '''
        To get the date and print the report
        @return : return report
        '''
        data = self.search_read([])[0]
        lst = []
        for division in self.division_id:
            lst.append(division.name)
        data.update({'stage_id': self.stage_id.name, 'course_id': self.course_id.name, 'batch_id': self.batch_id.name, 'semester_id': self.semester_id.name, 'division_id': lst})
        datas = {
            'ids': self._context.get('active_ids', []),
            'model': 'student.student',
            'form': data
        }
        return self.env['report'].get_action(self, 'sync_ems_admission.students_financial_report', data=datas)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: