# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from datetime import datetime
from odoo.exceptions import Warning


class StudentMigration(models.TransientModel):
    _name = 'student.migration'
    _description = "Student Migration"

    school_id = fields.Many2one('school.school', required=True, string='From School Level')
    to_school_id = fields.Many2one('school.school', string='To School Level')
    institute_id = fields.Many2one('res.company', required=True, string="From Institute")
    to_institute_id = fields.Many2one('res.company', string="To Institute")
    date = fields.Date('Date', required=True, default=fields.Date.today())
    stage_id = fields.Many2one('stage.stage', 'From Stage', required=True)
    to_stage_id = fields.Many2one('stage.stage', 'To Stage')
    batch_id = fields.Many2one('batch.batch', 'From Batch', required=True)
    to_batch_id = fields.Many2one('batch.batch', 'To Batch')
    course_id = fields.Many2one('course.course', 'From Course', required=True)
    to_course_id = fields.Many2one('course.course', 'To Course')
    division_id = fields.Many2one('division.division', 'From Division', required=True)
    to_division_id = fields.Many2one('division.division', 'To Division')
    semester_id = fields.Many2one('semester.semester', 'From Standard', required=True)
    to_semester_id = fields.Many2one('semester.semester', 'To Standard')
    student_ids = fields.Many2many('student.student', string='Student(s)')
    alumni = fields.Boolean('Alumni?', default=False)
    invoice = fields.Selection([('autoinvoice', 'Auto Invoice'), ('manual', 'Manual')], string='Invoice', default='manual')
    payment_term_id = fields.Many2one('account.payment.term', string='Payment Term')

    @api.onchange('school_id')
    def onchange_school_id(self):
        """
            Set Institute base on School.
        """
        institutes = []
        self.institute_id = False
        self.stage_id = False
        self.course_id = False
        self.batch_id = False
        self.semester_id = False
        self.division_id = False
        school_ids = []
        if self.school_id:
            school_ids = self.school_id.ids
            self.institute_id = self.school_id.institute_id.id
            institutes = self.institute_id.ids
        return {'domain':{'institute_id': [('id', 'in', institutes)], 'stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('to_school_id')
    def onchange_to_school_id(self):
        """
            Set Institute base on School.
        """
        institutes = []
        self.to_institute_id = False
        self.to_stage_id = False
        self.to_course_id = False
        self.to_batch_id = False
        self.to_semester_id = False
        self.to_division_id = False
        school_ids = []
        if self.to_school_id:
            school_ids = self.to_school_id.ids
            self.to_institute_id = self.to_school_id.institute_id.id
            institutes = self.to_institute_id.ids
        return {'domain':{'to_institute_id': [('id', 'in', institutes)], 'to_stage_id': [('school_id', 'in', school_ids)]}}

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        """
            Set course according to stage.
        """
        self.course_id = False

    @api.onchange('course_id')
    def onchange_course_id(self):
        """
            Set batch, semester, division according to course.
        """
        self.batch_id = False
        self.semester_id = False
        if self.course_id:
            self.division = False

    @api.onchange('batch_id')
    def onchange_batch_id(self):
        """
            Set semester according to batch.
        """
        self.semester_id = False
        return {'domain':{'semester_id': [('id', 'in', self.env['semester.semester'].search([('semester_history_ids.batch_id', '=', self.batch_id.id)]).ids)]}}

    @api.onchange('semester_id')
    def onchange_semester_id(self):
        """
            Set division according to semester.
        """
        self.division_id = False
        divisions = []
        if self.semester_id and self.batch_id:
            divisions = self.semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.batch_id.id).mapped('division_ids').mapped('division_id').ids
        return {'domain': {'division_id': [('id', 'in', divisions)]}}

    @api.onchange('to_stage_id')
    def onchange_to_stage_id(self):
        """
            Set course according to to stage.
        """
        self.to_course_id = False

    @api.onchange('to_course_id')
    def onchange_to_course_id(self):
        """
            Set batch, semester, division, according to to course.
        """
        self.to_batch_id = False
        self.to_semester_id = False
        self.to_division_id = False

    @api.onchange('to_batch_id')
    def onchange_to_batch_id(self):
        return {'domain':{'to_semester_id': [('id', 'in', [semester.id for semester in self.env['semester.semester'].search([]) if semester.semester_history_ids.batch_id == self.to_batch_id])]}}


    @api.onchange('to_semester_id')
    def onchange_to_semester_id(self):
        """
            Set semester according to to semester.
        """
        self.to_division_id = False
        divisions = []
        if self.to_semester_id and self.to_batch_id:
            divisions = self.to_semester_id.semester_history_ids.filtered(lambda x: x.batch_id.id == self.to_batch_id.id).mapped('division_ids').mapped('division_id').ids
        return {'domain': {'to_division_id': [('id', 'in', divisions)]}}

    def fetch_student(self):
        ''' collect the student details'''
        # student_obj = self.env['student.student']
        students = self.env['student.student'].search([
            ('school_id', '=', self.school_id.id),
            ('institute_id', '=', self.institute_id.id),
            ('stage_id', '=', self.stage_id.id),
            ('batch_id', '=', self.batch_id.id),
            ('course_id', '=', self.course_id.id),
            ('division_id', '=', self.division_id.id),
            ('semester_id', '=', self.semester_id.id),
            ('is_enrolled', '=', True),
        ])
        self.write({'student_ids': [(6, 0, students.ids)]})
        return {
            'string': _('Student Migration'),
            'view_mode': 'form',
            'res_id': self.id,
            'res_model': 'student.migration',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'target': 'new'
        }

    def go_forward(self):
        """
            forward student details.
        """
        semester = self.env['semester.semester']
        student_obj = self.env['student.student']
        admission_obj = self.env['admission.admission']
        semester_division_obj = self.env['semester.division']
        student_ids = []

        semester_division_id = semester_division_obj.search([('division_id', '=', self.to_division_id.id)], limit=1)

        course_student_capacity = student_obj.search([('course_id', '=', self.to_course_id.id)])
        if self.to_course_id and (len(self.student_ids) + len(course_student_capacity)) > self.to_course_id.student_capacity:
            raise Warning(_("To Course student capacity is full!"))

        class_student_capacity = student_obj.search([('division_id', '=', self.to_division_id.id)])
        if self.to_division_id and (len(self.student_ids) + len(class_student_capacity)) > self.to_division_id.student_capacity:
            raise Warning(_("To Division student capacity is full!"))

        if self.school_id.id == self.to_school_id.id and self.institute_id.id == self.to_institute_id.id and\
            self.stage_id.id == self.to_stage_id.id and self.course_id.id == self.to_course_id.id\
            and self.batch_id.id == self.to_batch_id.id\
            and self.semester_id.id == self.to_semester_id.id\
            and self.division_id.id == self.to_division_id.id:
            raise Warning(_("Same division migration is not posible."))

        student_values = {}
        for self_obj in self:
            if len(self_obj.student_ids) <= 0:
                 raise Warning(_("Please click on Fetch Student button for migration process!"))

            if self_obj.alumni:
                student_values.update({'is_alumni_student': True, 'is_enrolled': False})
            student_values.update({
                'school_id': self_obj.to_school_id.id,
                'institute_id': self_obj.to_institute_id.id,
                'stage_id': self_obj.to_stage_id.id,
                'course_id': self_obj.to_course_id.id,
                'batch_id': self_obj.to_batch_id.id,
                'semester_id': self_obj.to_semester_id.id,
                'division_id': self_obj.to_division_id.id,
                'is_enrolled': True,
                'standard_division_id': semester_division_id.id
            })
            for student in self_obj.student_ids:
                history_vals = {
                    'school_id': student.school_id.id,
                    'institute_id': student.institute_id.id,
                    'stage_id': student.stage_id.id,
                    'course_id': student.course_id.id,
                    'batch_id': student.batch_id.id,
                    'semester_id': student.semester_id.id,
                    'division_id': student.division_id.id,
                    'student_id': student.id,
                    'is_division_migration': False,
                    'compulsary_subject_ids': student.compulsary_subject_ids.ids,
                    'optional_subject_ids': student.optional_subject_ids.ids,
                    'optional_subject_ids': student.optional_subject_ids.ids,
                }
                student_history_id = self.env['student.history'].create(history_vals)

                if self_obj.school_id.id == self_obj.to_school_id.id and\
                    self_obj.institute_id.id == self_obj.to_institute_id.id\
                    and self_obj.stage_id.id == self_obj.to_stage_id.id \
                    and self_obj.course_id.id == self_obj.to_course_id.id\
                    and self_obj.batch_id.id == self_obj.to_batch_id.id\
                    and self_obj.semester_id.id == self_obj.to_semester_id.id\
                    and self_obj.division_id.id != self_obj.to_division_id.id:
                    student_history_id.is_division_migration = True

                student.write(student_values)

            if self_obj.invoice == 'autoinvoice' and\
                not (self_obj.school_id.id == self_obj.to_school_id.id and\
                self_obj.institute_id.id == self_obj.to_institute_id.id\
                and self_obj.stage_id.id == self_obj.to_stage_id.id \
                and self_obj.course_id.id == self_obj.to_course_id.id\
                and self_obj.batch_id.id == self_obj.to_batch_id.id\
                and self_obj.semester_id.id == self_obj.to_semester_id.id\
                and self_obj.division_id.id != self_obj.to_division_id.id):
                self.proceed_fee()

    def _get_migration_product(self):
        ''' migration in bachelor to master '''
        products = self.env['product.product'].search([('include_in_migration', '=', True)])
        return products

    def proceed_fee(self):
        """
            Set fees Process.
        """
        context = dict(self._context)
        sale_orders = []
        products = self._get_migration_product()
        for student in self.student_ids:
            context.update({
                'admission':'admission',
                'course_id': self.to_course_id and self.to_course_id.id or False,
                'semester_id': self.to_semester_id and self.to_semester_id.id or False,
                'school_id': self.to_school_id and self.to_school_id.id or False,
                'institute_id': self.to_institute_id and self.to_institute_id.id or False,
                'admission_date': self.date or False,
                'is_school_data': True,
            })
            sale_id = self.env['sale.order'].create({
                'partner_id': student.partner_id.id,
                'date_order': fields.Datetime.now(),
                'fee': True,
                'payment_term_id': self.payment_term_id.id,
            })
            sale_id.onchange_partner_id()
            sale_id.onchange_partner_shipping_id()
            solines = []
            for product_id in products:
                so_line = {
                    'product_id': product_id.id,
                    'price_unit': product_id.list_price,
                    'product_uom_qty': 1.0,
                    'product_uom': product_id.uom_id.id,
                    'name': product_id.name,
                }
                list_price = product_id.with_context(context).price_compute('list_price')
                so_line['price_unit'] = list_price.get(product_id.id) or False
                solines.append(so_line)
            sale_id['order_line'] = [(0, 0, line) for line in solines]
            sale_orders.append(sale_id.id)
        return sale_orders
