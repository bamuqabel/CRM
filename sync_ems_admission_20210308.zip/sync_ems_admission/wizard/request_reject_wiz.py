# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)


class RequestReject(models.TransientModel):
    """
        Reject Admission Request
    """
    _name = 'request.reject'
    _description = 'Admission Request Reject'

    reject_reason = fields.Text(string='Reject Reason', required=True)

    def reject_request(self):
        context = dict(self.env.context)
        if context.get('active_id') and context.get('active_model') == 'admission.admission':
            # Send Mail
            mail_template_id = self.env.ref('sync_ems_admission.reject_admission_request_send_email')
            sms_template_id = self.env.ref('sync_ems_admission.sms_template_for_admission_reject')
            active_id = self.env['admission.admission'].browse(context['active_id'])
            if mail_template_id and active_id:
                active_id.reject_reason = self.reject_reason
                mail_template_id.send_mail(active_id.id, force_send=True, raise_exception=False)
                active_id.confirm_rejected()
                _logger.info("Admission Request Reject for %s" % self.reject_reason)
            if active_id and sms_template_id:
                active_id._message_sms_with_template(
                    template_xmlid='sync_ems_admission.sms_template_for_admission_reject',
                    template_fallback=_("Admission Rejected: %s, %s.") % (active_id.middle_name.name, active_id.admission_date),
                    partner_ids=active_id.middle_name and active_id.middle_name.ids,
                    put_in_queue=False
                )
