# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

import time
from odoo import models, fields, api, _
from datetime import datetime

class AdmissionAnalysisReport(models.Model):
    _name = 'admission.analysis.report'

    course_id = fields.Many2one('course.course', string='Course')
    semester_id = fields.Many2many('semester.semester', string='Standard')
    date_from = fields.Date(string='From')
    date_to = fields.Date(string='To')

    @api.onchange('date_from')
    def onchange_date_from(self):
        """
            Set from date
        """
        if self.date_from and self.date_to and self.date_to < self.date_from:
            warning = {'message': _('From should not be greater than To!')}
            self.date_from = False
            return {'warning': warning}

    @api.onchange('date_to')
    def onchange_date_to(self):
        """
            Set to date.
        """
        if self.date_to and self.date_from and self.date_to < self.date_from:
            warning = {'message': _('To should not be less than From!')}
            self.date_to = False
            return {'warning': warning}

    @api.onchange('course_id')
    def onchange_course_id(self):
        """
            Set semester according to course.
        """
        self.semester_id = False
        if not self.course_id:
            self.semester_id = False
            return {'domain':{'semester_id': [('id', 'in', [])]}}
        else:
           semester_ids = self.env['semester.semester'].search([('course_id', '=', self.course_id.id)])
           return {'domain':{'semester_id': [('id', 'in', semester_ids.ids)]}}

    def print_report(self):
        '''To get the date and print the report @return : return report '''
        data = self.search_read([])[0]
        lst = []
        for semester_id in self.semester_id:
            lst.append(semester_id.name)
        date_from = datetime.strptime(self.date_from +' '+ '00:00:00', '%Y-%m-%d %H:%M:%S')
        date_to = datetime.strptime(self.date_to +' '+ '00:00:00'   , '%Y-%m-%d %H:%M:%S')
        data.update({'course_id': self.course_id.name, 'semester_id':lst, 'date_from':date_from.strftime('%d/%m/%Y'), 'date_to':date_to.strftime('%d/%m/%Y')})
        datas = {
            'form': data
        }
        return self.env['report'].get_action(self, 'sync_ems_admission.admission_analysis_report', data=datas)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: