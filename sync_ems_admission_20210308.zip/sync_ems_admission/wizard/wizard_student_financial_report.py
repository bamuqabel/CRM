# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

import time
from odoo import models, fields, api

class StudentFinancialReport(models.Model):
    _name = 'student.financial.report'

    student_id = fields.Many2one('student.student', string='Student', required=True)

    def print_report(self):
        '''
        To get the date and print the report
        @return : return report
        '''
        data = self.search_read([])[0]
        data.update({'student_id': self.student_id.id,'partner_id':self.student_id.partner_id.id})
        datas = {
            'ids': self._context.get('active_ids', []),
            'model': 'student.student',
            'form': data
        }
        return self.env['report'].get_action(self,'sync_ems_admission.student_financial_report', data = datas)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: