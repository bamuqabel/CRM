# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from . import hr_loan
from . import hr_skip_installment
from . import hr_loan_operation
from . import hr_payroll
from . import res_config_settings
