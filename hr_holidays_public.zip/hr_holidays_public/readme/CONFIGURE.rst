Go to *Leaves -> Configuration* and open a Leave Type

* Check "Exclude Public Holidays" to exclude public holidays.
