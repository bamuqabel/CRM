# -*- coding: utf-8 -*-
###############################################################################
#                                                                             #
#    Globalteckz                                                              #
#    Copyright (C) 2013-Today Globalteckz (http://www.globalteckz.com)        #
#                                                                             #
#    This program is free software: you can redistribute it and/or modify     #
#    it under the terms of the GNU Affero General Public License as           #
#    published by the Free Software Foundation, either version 3 of the       #
#    License, or (at your option) any later version.                          #
#                                                                             #
#    This program is distributed in the hope that it will be useful,          #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of           #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            #
#    GNU Affero General Public License for more details.                      #
#                                                                             #
#    You should have received a copy of the GNU Affero General Public License #
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.    #
#                                                                             #   
###############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError
import requests
import json
import urllib
import base64
import datetime
from datetime import date
import logging
logger = logging.getLogger('product')
import urllib.request



class GtMagentoInstance(models.Model):
    _name='gt.magento.instance'
    _description = "GT Magento Instance"
    _rec_name = "name"
    
    
    name = fields.Char(string='Name',size=64, required=True)
    location = fields.Char(string='Location',size=64,required=True)
    apiusername = fields.Char(string='User Name',size=64,required=True)
    apipassoword = fields.Char(string='Password',size=64,required=True)
    token=fields.Char(string='Token')
    location_id = fields.Many2one('stock.location',string='Stock Location')
    count_magento_shop = fields.Integer(compute='GetShopCount')
    count_magento_websites = fields.Integer(compute='GetWebsiteCount')
    count_magento_attribute_set = fields.Integer(compute='GetAttributeSetCount')
    count_magento_attributes = fields.Integer(compute='GetAttributesCount')
    count_magento_categories = fields.Integer(compute='GetCategoriesCount')
    count_magento_products = fields.Integer(compute='GetProductsCount')
    count_magento_customers = fields.Integer(compute='GetCustomersCount')
    from_id = fields.Integer(string="Simple From ID", default=1)
    config_prod_from_id = fields.Integer(string="Config From ID", default=1)
    cust_from_id = fields.Integer(string="Customer From ID", default=1)

    def ActionGetShop(self):
        #print "<================Calling===============>",
        magento_shop = self.env['gt.magento.store'].search([('magento_instance_id','=',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('globalteckz_magento_2.gt_act_magento_shop')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_shop.ids)]
        }

        return result
    
    
    def ActionGetWebsites(self):
        #print "<================Calling===============>",
        magento_web = self.env['gt.magento.website'].search([('magento_instance_id','=',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('globalteckz_magento_2.gt_act_magento_website')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_web.ids)]
        }

        return result
    
    
    def ActionGetAttributeSets(self):
        #print "<================Calling===============>",
        magento_att_set = self.env['gt.product.attribute.set'].search([('magento_instance_id','=',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('globalteckz_magento_2.act_gt_product_attribute_set')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_att_set.ids)]
        }

        return result
    
    
    def ActionGetAttributes(self):
        #print "<================Calling===============>",
        magento_attributes = self.env['gt.product.attributes'].search([('referential_id','=',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('globalteckz_magento_2.act_gt_product_attributes')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_attributes.ids)]
        }

        return result
    
    
    def ActionGetCategories(self):
        #print "<================Calling===============>",
        magento_category = self.env['product.category'].search([('magento_instance_id','=',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('product.product_category_action_form')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_category.ids)]
        }

        return result
    
    
    def ActionGetProduct(self):
        #print "<================Calling===============>",
        magento_products = self.env['product.product'].search([('magento_instance_ids','in',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('globalteckz_magento_2.act_magento_products')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_products.ids)]
        }

        return result
    
    
    def ActionGetCustomer(self):
        #print "<================Calling===============>",
        magento_products = self.env['res.partner'].search([('magento_instance_ids','=',self.id)])
        #print "<=================Shopify===============>",magento_shop
        action = self.env.ref('globalteckz_magento_2.action_magento_customer')
        result = {
        'name': action.name,
        'help': action.help,
        'type': action.type,
        'view_mode': action.view_mode,
        'target': action.target,
        'context': action.context,
        'res_model': action.res_model,
        'domain': [('id', 'in', magento_products.ids)]
        }

        return result
    
    
    def GetShopCount(self):
        shop_obj = self.env['gt.magento.store']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('magento_instance_id', '=', shop.id)])
            shop.count_magento_shop = len(multishop_ids.ids)
        return res
    
    
    def GetWebsiteCount(self):
        shop_obj = self.env['gt.magento.website']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('magento_instance_id', '=', shop.id)])
            shop.count_magento_websites = len(multishop_ids.ids)
        return res
    
    
    def GetAttributeSetCount(self):
        shop_obj = self.env['gt.product.attribute.set']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('magento_instance_id', '=', shop.id)])
            shop.count_magento_attribute_set = len(multishop_ids.ids)
        return res
    
    
    def GetAttributesCount(self):
        shop_obj = self.env['gt.product.attributes']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('referential_id', '=', shop.id)])
            shop.count_magento_attributes = len(multishop_ids.ids)
        return res
    
    
    
    def GetCategoriesCount(self):
        shop_obj = self.env['product.category']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('magento_instance_id', '=', shop.id)])
            shop.count_magento_categories = len(multishop_ids.ids)
        return res
    
    
    
    def GetProductsCount(self):
        shop_obj = self.env['product.product']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('magento_instance_ids','in',self.id)])
            shop.count_magento_products = len(multishop_ids.ids)
        return res
    
    
    
    
    def GetCustomersCount(self):
        shop_obj = self.env['res.partner']
        res = {}
        for shop in self:
            multishop_ids = shop_obj.search([('magento_instance_ids','=',self.id)])
            shop.count_magento_customers = len(multishop_ids.ids)
        return res
    
    
    def generate_token(self):
        url=str(self.location)+"/rest/V1/integration/admin/token"
        payload = {"username":str(self.apiusername), "password":str(self.apipassoword)}
        headers = {'content-type': "application/json",'cache-control': "no-cache",}
        payload=str(payload)
        payload=payload.replace("'",'"')
        payload=str(payload)
        response = requests.request("POST",url, data=payload, headers=headers)
        print ('response.status_code++++++++++++++++++++++++',response.status_code)
        if str(response.status_code)=="200":
            self.write({'token':json.loads(response.text)})
            self._cr.commit()
        return True

    def gt_create_magento_website(self):
        website_obj = self.env['gt.magento.website']
        try:
            self.generate_token()
            url=self.location+"/rest/V1/store/websites"
            print ("url++++++++++++++",url)
            headers = {'authorization':"Bearer "+self.token}
            response = requests.request("GET",url, headers=headers)
            if str(response.status_code)=="200":
                websites=json.loads(response.text)
                for website in websites:
                    try:
                        if len(website):
                            website_id=website_obj.search([('code','=',website['code']),('magento_instance_id','=',self.id)])
                            if website['name'] != 'Admin':
                                if not website_id:
                                    website_obj.create({'name':website['name'],'code':website['code'],'magento_website':True,
                                    'website_id':website['id'], 'default_group_id':website['default_group_id'],'magento_instance_id':self.id })
                                else:
                                    website_id.write({'name':website['name'], 'code':website['code'],'website_id':website['id'], 
                                    'default_group_id':website['default_group_id'],'magento_instance_id':self.id,'magento_website':True,})
                            self._cr.commit()
                    except Exception as exc:
                        logger.error('Exception===================:  %s', exc)
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
        return True


    
    def gt_create_magento_stores(self):
        store_obj = self.env['gt.magento.store']
        website_obj = self.env['gt.magento.website']
        try:
            self.generate_token()
            url=self.location+"/rest/V1/store/storeViews"
            headers = {'authorization':"Bearer "+self.token}
            response = requests.request("GET",url, headers=headers)
            if str(response.status_code)=="200":
                stores=json.loads(response.text)
                for store in stores:
                    print("store",store)
                    try:
                        if len(store):
                            store_id=store_obj.search([('name','=',store['name']),('code','=',store['code']),('store_id','=',store['id']),('magento_instance_id','=',self.id)])
                            if store['name'] != 'Admin':
                                website_id = website_obj.search([('website_id','=',store['website_id']),('magento_instance_id','=',self.id)])
                                if not len(website_id):
                                    raise UserError(_('Please Import Magento Website First'))
                                if not store_id:
                                    store_obj.create({'name':store['name'],'code':store['code'],'store_id':store['id'], 
                                    'website_id':website_id.id,'magento_shop':True, 'magento_instance_id':self.id })
                                else:
                                    store_id.write({'name':store['name'], 'code':store['code'],'store_id':store['id'], 
                                    'website_id':website_id.id,'magento_shop':True, 'magento_instance_id':self.id })
                            self._cr.commit()
                    except Exception as exc:
                        logger.error('Exception===================:  %s', exc)
                        raise UserError(_(exc))
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
            raise UserError(_(exc))
        return True
    
    
    
    def GtCreateMagentoAttributeSet(self):
        attribute_set_obj=self.env['gt.product.attribute.set']
        shop_obj=self.env['gt.magento.store']
        try:
            self.generate_token()
            shop_id=shop_obj.search([('magento_instance_id','=',self.id)])
            if not shop_id:
                raise UserError(_('Please Create Store'))
            url=self.location+"rest/V1/products/attribute-sets/sets/list?searchCriteria=0"
            print("url=====attribute_set>>>>>",url)
            headers = { 'authorization':"Bearer "+self.token}
            response = requests.request("GET",url, headers=headers)
            print ("response+++++",response)
            print ("response.json().get('items')++++++++",response.json().get('items'))
            if str(response.status_code)=='200':
                try:
                    list_prods=response.json().get('items')
                    for list_prod in list_prods:
                        val={
                            'name':list_prod['attribute_set_name'],'code':list_prod['attribute_set_id'],
                            'sort_order':list_prod['sort_order'],'entity_type_id':list_prod['entity_type_id'],
                            'magento_instance_id': self.id,
                            }
                        attribute_id=attribute_set_obj.search([('code','=',list_prod['attribute_set_id']),('magento_instance_id','=',self.id)])
                        if attribute_id:
                            attribute_id.write(val)
                        else:
                            attribute_set_obj.create(val)
                        self._cr.commit()
                except Exception as exc:
                    logger.error('Exception===================:  %s', exc)
                    raise UserError(_(exc))  
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
            raise UserError(_(exc))

        return True
    
    
    
    def GtCreateMagentoAttributes(self):
        att_set_obj = self.env['gt.product.attribute.set']
        att_obj = self.env['gt.product.attributes']
        att_opt_obj = self.env['gt.product.attribute.options']
        front_obj = self.env['gt.frontend.input']
        try:
            self.generate_token()
            headers = { 'authorization':"Bearer "+self.token }
            att_ids = att_set_obj.search([('magento_instance_id','=',self.id),('attributes_import','=',False)])
            for att_id in att_ids:
                attribute_ids_mm = []
                old_attributes = []
                for attss in att_id.attribute_ids:
                    old_attributes.append(attss.id)
                url=self.location+"/rest/V1/products/attribute-sets/"+str(att_id.code)+"/attributes"
                print("url=====attributes=====",url)
                response = requests.request("GET",url, headers=headers)
                if str(response.status_code)=='200':
                    attribute_list= json.loads(response.text)
                    print ("lenght of the attribute_list+++++",len(attribute_list))
                    for jsonloads in attribute_list:
                        try:
                            attribute_oe_ids = att_obj.search([('attribute_code','=',jsonloads['attribute_code']),('referential_id','=',self.id)])
                            if not attribute_oe_ids:
                                url = self.location+"/rest/V1/products/attributes/"+str(jsonloads['attribute_code'])
                                response = requests.request("GET",url, headers=headers)
                                if str(response.status_code)=='200':
                                    jsonload= json.loads(response.text)
                                    frontend_ids = front_obj.search([('name_type','=',jsonload['frontend_input'])])
                                    if not frontend_ids:
                                        frontend_ids = front_obj.create({'name_type':jsonload['frontend_input']})
                                    attribute_oe_ids=att_obj.create({
                                    'attribute_code':jsonload['attribute_code'],
                                    'referential_id':self.id,
                                    'frontend_input_id':frontend_ids.id,
                                    'is_searchable' : jsonload['is_searchable'] if 'is_searchable' in jsonload else False,
                                    'is_visible':jsonload['is_visible'] if 'is_visible' in jsonload else False,
                                    'is_visible_on_front':jsonload['is_visible_on_front'] if 'is_visible_on_front' in jsonload else False,
                                    'is_filterable':jsonload['is_filterable'] if 'is_filterable' in jsonload else False,
                                    'scope':jsonload['scope'] if 'scope' in jsonload else '',
                                    'magento_id':jsonload['attribute_id'],
                                    'is_unique':jsonload['is_unique'] if 'is_unique' in jsonload else False,
                                    'is_required':jsonload['is_required'] if 'is_required' in jsonload else False,
                                    'is_user_defined':jsonload['is_user_defined']if 'is_user_defined' in jsonload else False,
                                    })
                                    if len(jsonload['options']):
                                        options_list = []
                                        for attribute_option in jsonload['options']:
                                            if attribute_option['value']:
                                                attribute_oe_opt_ids = att_opt_obj.search([('attribute_id','=',attribute_oe_ids.id),('referential_id','=',self.id),('label','=',attribute_option['label'])])
                                                if not len(attribute_oe_opt_ids):
                                                    attribute_option_id = att_opt_obj.create({'attribute_id':attribute_oe_ids.id,'referential_id':self.id,'value':attribute_option['value'],'label':attribute_option['label']})
                                                    options_list.append((0,0,{'attribute_name':attribute_option_id.attribute_name,
                                                        'value':attribute_option_id.value,'label':attribute_option_id.label}))
                                                else:
                                                    attribute_oe_opt_ids.write({'attribute_id':attribute_oe_ids.id,'referential_id':self.id,'value':attribute_option['value'],'label':attribute_option['label']})
                                                self._cr.commit()
                                attribute_ids_mm.append(attribute_oe_ids.id)
                            else:
                                attribute_ids_mm.append(attribute_oe_ids.id)
                        except Exception as exc:
                            logger.error('Exception===================:  %s', exc)
                            pass
                    latest = [elem for elem in attribute_ids_mm if elem not in old_attributes]
                    att_id.write({'attribute_ids':[(6,0,latest)],'attributes_import':True})
                    print ("Attribute Updated")
            self._cr.commit()
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
            pass
        return True
    
    
    
    def GtImportMagentoCategories(self):
        category_obj = self.env['product.category']
        magento_shop = self.env['gt.magento.store']
        try:
            self.generate_token()
            store_ids = magento_shop.search([('magento_instance_id','=',self.id)])
            for shop in store_ids:
                url=self.location+"/rest/"+str(shop.code)+"/V1/categories/"
                headers = {'authorization':"Bearer "+self.token }
                response = requests.request("GET",url, headers=headers)
                if str(response.status_code)=='200':
                    try:
                        if response.json().get('is_active')==True:
                            if str(response.json().get('parent_id'))=="1" or str(response.json().get('parent_id'))=="0":
                                category_id=category_obj.search([('name','=',response.json().get('name')),('magento_id','=',response.json().get('id')),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                if not category_id:
                                    category_obj.create({'magento_id':response.json().get('id'),'magento_instance_id':self.id,'position':response.json().get('position'),'level':response.json().get('Level'),
                                    'name':response.json().get('name'),'shop_id':shop.id,})
                            if len(response.json().get('children_data')):
                                sub_categ=response.json().get('children_data')
                                for categ in sub_categ:
                                    sub_categ_id=self.env['product.category'].search([('magento_id','=',categ['id']),('name','=',categ['name']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                    if not sub_categ_id:
                                        categ_id=self.env['product.category'].search([('magento_id','=',categ['parent_id']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                        if categ_id:
                                            self.env['product.category'].create({'parent_id':categ_id.id,'magento_id':categ['id'],'name':categ['name'],
                                            'magento_instance_id':self.id,'position':categ['position'],'level':categ['level'],'shop_id':shop.id,'category_exported':True})
                                    for sub_in_sub in categ['children_data']:
                                        sub_in_sub_cat_id = self.env['product.category'].search([('magento_id','=',sub_in_sub['id']),('name','=',sub_in_sub['name']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                        if not sub_in_sub_cat_id:
                                            cat_id=self.env['product.category'].search([('magento_id','=',sub_in_sub['parent_id']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                            if cat_id:
                                                self.env['product.category'].create({'parent_id':cat_id.id,'magento_id':sub_in_sub['id'],'name':sub_in_sub['name'],'magento_instance_id':self.id,
                                                'position':sub_in_sub['position'],'level':sub_in_sub['level'],'shop_id':shop.id,'category_exported':True})
                                        if sub_in_sub['children_data']:
                                            for sub_to_sub in sub_in_sub['children_data']:
                                                sub_to_sub_cat_id = self.env['product.category'].search([('magento_id','=',sub_to_sub['id']),('name','=',sub_to_sub['name']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                                if not sub_to_sub_cat_id:
                                                    catsub_id=self.env['product.category'].search([('magento_id','=',sub_to_sub['parent_id']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                                    if catsub_id:
                                                        self.env['product.category'].create({'parent_id':catsub_id.id,'magento_id':sub_to_sub['id'],'name':sub_to_sub['name'],'magento_instance_id':self.id,'position':sub_to_sub['position'],
                                                                                    'level':sub_to_sub['level'],'shop_id':shop.id,'category_exported':True})
                                                if sub_to_sub['children_data']:
                                                    for sub_cat in sub_to_sub['children_data']:
                                                        sub_child_id = self.env['product.category'].search([('magento_id','=',sub_cat['id']),('name','=',sub_cat['name']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                                        if not sub_child_id:
                                                            sub_child_ids=self.env['product.category'].search([('magento_id','=',sub_cat['parent_id']),('magento_instance_id','=',self.id),('shop_id','=',shop.id)])
                                                            if sub_child_ids:
                                                                self.env['product.category'].create({'parent_id':sub_child_ids.id,'magento_id':sub_cat['id'],'name':sub_cat['name'],'magento_instance_id':self.id,'position':sub_cat['position'],
                                                                                            'level':sub_cat['level'],'shop_id':shop.id,'category_exported':True})
                        self._cr.commit()
                    except Exception as exc:
                        logger.error('Exception===================:  %s', exc)
                        pass 
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
        return True



    def ExportMultipleMagentoCategories(self):
        category_obj = self.env['product.category']
        category_ids = category_obj.search([('magento_instance_id','=',self.id),('category_exported','=',False)])
        for category_id in category_ids:
            category_id.GtExportMagentoCategory()
        return True
    
    
    def GtExportMagentoProducts(self):
        product_obj = self.env['product.product']
        product_ids = product_obj.search([('magento_instance_ids','=',self.id),('magento_product','=',True),('exported_magento','=',False)])
        for product_id in product_ids:
            product_id.GtExportMagentoProducts()
        
        return True
    
    
    
    def GtExportProductImage(self):
        multi_instance = self.env['gt.magento.product.image.multi']
        for lst_image in self.product_image_id:
            print("<><><><><><><><><>LST_IMAGE<><><><><><><>", lst_image)
            for instance in lst_image.magento_instance_ids:
                lst_image.write({'is_exported': False})
                instance.generate_token()
                token = instance.token
                token = token.replace('"', " ")
                auth_token1 = "Bearer " + token.strip()
                auth_token = auth_token1.replace("'", '"')
                headers = {
                    'authorization': auth_token,
                    'content-type': "application/json",
                    'cache-control': "no-cache",
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
                }
                if lst_image.is_exported == False:
                    # with open('/home/tushar/Downloads/test_image.jpeg', "rb") as image_file:
                    #     b64_encoded_string = base64.b64encode(image_file.read()).decode("utf8")
                    # raw_data = {'base64_encoded_data': b64_encoded_string, 'type': 'image/jpeg', 'name': 'test_image.jpeg'}
                    # json_data = dumps(raw_data, indent=2)
                    # decodes = c.decode("base64")
                    decodes = base64.b64decode(lst_image.image)
                    # newdecode = decodes.encode("base64")
                    newdecode = (base64.b64encode(decodes)).decode("utf8")
                    print("<><><><><>><NEWCXOD?????????????", type(newdecode))
                    type_image = []
                    if lst_image.small_image == True:
                        type_image.append('image')
                    if lst_image.thumbnail == True:
                        type_image.append('thumbnail')
                    if lst_image.swatch_image == True:
                        type_image.append('swatch_image')
                    if lst_image.base_image == True:
                        type_image.append('image')
                    vals = {
                        "entry": {
                            "media_type": "image",
                            "position": 1,
                            "disabled": "true",
                            "types": type_image,
                            "label": "testimage",
                            "content": {
                                "base64_encoded_data": newdecode,
                                "type": "image/" + str(lst_image.image_extension),
                                "name": str(lst_image.name),
                            }
                        }
                    }
                    print("vals+9++++++++++++++", vals)
                    url = str(instance.location) + "rest/V1/products/" + str(self.default_code) + "/media"
                    print("url++++++++++++", url)
                    productload = str(vals)
                    productload = productload.replace("'", '"')
                    productload = str(productload)
                    response = requests.request("POST", url, data=productload, headers=headers)
                    # print ("productload+++++++++++++++++",productload)
                    print('response.status_code++++++', response.status_code)
                    # print ("json.loads(response.text)++++++++++++",json.loads(response.text))
                    if str(response.status_code) == "200":
                        each_response = json.loads(response.text)
                        print("<><><><><>>ECH///////////////", each_response)
                        product_id = multi_instance.search(
                            [('magento_id', '=', each_response), ('gt_magento_instance_id', '=', instance.id),
                             ('gt_magento_exported', '=', True), ('images_ids', '=', lst_image.id)])
                        if not product_id:
                            product_id = multi_instance.create(
                                {'magento_id': each_response, 'gt_magento_instance_id': instance.id,
                                 'gt_magento_exported': True, 'images_ids': lst_image.id})
                            # print("++++++++++++++++++PROD++++++++++++", product_id, product_id.gt_magento_image_ids)
                        prods_id = []
                        for prod_id in lst_image.gt_magento_image_ids:
                            print("+++=========================iddddd", prod_id)
                            prods_id.append(prod_id.id)
                        if product_id.id not in prods_id:
                            # print("++++++++++++++++++PROD++++++++++++", product_id)
                            prods_id.append(product_id.id)
                        lst_image.write({'gt_magento_image_ids': [(6, 0, prods_id)]})
                        lst_image.write({'is_exported': True})
        return True

    def GtImportMagentoSimpleProduct(self):
        print("self.from_id===",self.from_id)
        product_obj = self.env['product.product']
        store_obj = self.env['gt.magento.store']
        website_obj = self.env['gt.magento.website']
        self.generate_token()
        token=self.token
        token=token.replace('"'," ")
        auth_token="Bearer "+token.strip()
        auth_token=auth_token.replace("'",'"')
        headers = {
            'authorization':auth_token,
            'content-type': "application/json",
            'cache-control': "no-cache",
            }
        url=str(self.location)+"/rest/V1/products?searchCriteria[filterGroups][0][filters][0][field]=type_id& searchCriteria[filterGroups][0][filters][0][value]=simple& searchCriteria[filterGroups][0][filters][0][conditionType]=eq&searchCriteria[filterGroups][1][filters][0][field]=entity_id&searchCriteria[filterGroups][1][filters][0][value]="+str(self.from_id)+"&searchCriteria[filterGroups][1][filters][0][conditionType]=gteq"
        response = requests.request("GET",url, headers=headers)
        print ("url++++++++",url)
        response = requests.request("GET",url, headers=headers,)
        print ("response+++++++++",response)
        # print ("json.loads(response.text)+++++++++",json.loads(response.text))
        product_list=json.loads(response.text)
        # print ("product_list+++++++++",product_list)
        print ("create_simple_products+++++++111",requests.session().close())
        for products in product_list['items']:
            print("=====products======",products)
            print("=====sku======",str(products['sku']))
            # if '/' in str(products['sku']):
            #     prod_sku =products['sku'].replace('/','%2F')
            #     print("prod_sku====",prod_sku)
            #     url = str(self.location) + "/rest/V1/products/"+prod_sku
            #     print("url====",url)
            # else:
            url=str(self.location)+"/rest/V1/products/"+str(products['sku'])
            response = requests.request("GET",url, headers=headers)
            print("response====",response)
            each_product=json.loads(response.text)
            print("create_simple_products+++++++2222", requests.session().close())
            # if each_product.get('custom_attributes'):
            for attributes in each_product.get('custom_attributes'):
                if attributes.get('attribute_code') == 'website_ids':
                    for website in attributes.get('value'):
                        website_id = website_obj.search([('website_id','=',website),('magento_instance_id','=',self.id)])
                        store_ids = store_obj.search([('website_id','=',website_id.id),('magento_instance_id','=',self.id)])
                        for store_id in store_ids:
                            product_obj.create_simple_products(self,headers,products['sku'],store_id,website_id)
        return True
    
    
    def GtImportMagentoConfigurableProduct(self):
        product_obj = self.env['product.product']
        store_obj = self.env['gt.magento.store']
        website_obj = self.env['gt.magento.website']
        self.generate_token()
        token=self.token
        token=token.replace('"'," ")
        auth_token="Bearer "+token.strip()
        auth_token=auth_token.replace("'",'"')
        headers = {
            'authorization':auth_token,
            'content-type': "application/json",
            'cache-control': "no-cache",
            }
        url=str(self.location)+"/rest/V1/products?searchCriteria[filterGroups][0][filters][0][field]=type_id& searchCriteria[filterGroups][0][filters][0][value]=configurable& searchCriteria[filterGroups][0][filters][0][conditionType]=eq&searchCriteria[filterGroups][1][filters][0][field]=entity_id&searchCriteria[filterGroups][1][filters][0][value]="+str(self.config_prod_from_id)+"&searchCriteria[filterGroups][1][filters][0][conditionType]=gteq"
        response = requests.request("GET",url, headers=headers, stream=True)
        print("response====",response)
        product_list=json.loads(response.text)
        for products in product_list['items']:
            url = str(self.location) + "/rest/V1/products/" + str(products['sku'])
            response = requests.request("GET", url, headers=headers, stream=True)
            each_product = json.loads(response.text)
            #            print ("each_product.get('custom_attributes')+",each_product)
            #            print ("each_product.get('custom_attributes')+",each_product.get('extension_attributes'))
            #            print ("website_iddddssssss",each_product.get('extension_attributes').get('website_ids'))
            if 'extension_attributes' in each_product:
                extenstion_attributes = each_product.get('extension_attributes')
                print("extenstion_attributes++++++=", extenstion_attributes)
                if 'website_ids' in extenstion_attributes:
                    website_ids = extenstion_attributes.get('website_ids')
                    print("website_ids++++++++", website_ids)
                    # for attributes in each_product.get('custom_attributes'):
                    # print ("attributes+++++++++++++",attributes)
                    #    if attributes.get('attribute_code') == 'website_ids':
                    for website_id in website_ids:
                        print("website_id++++++++++", website_id)
                        website_id = website_obj.search([('website_id', '=', website_id), ('magento_instance_id', '=', self.id)])
                        store_ids = store_obj.search([('website_id', '=', website_id.id), ('magento_instance_id', '=', self.id)])
                        for store_id in store_ids:
                            product_obj.create_configurable_magento_products(self, headers, products['sku'], store_id,website_id)
            self._cr.commit()
        return True

    def GtImportMagentoCustomer(self):
        self.generate_token()
        token=self.token
        token=token.replace('"'," ")
        auth_token="Bearer "+token.strip()
        auth_token=auth_token.replace("'",'"')
        headers = {'authorization':auth_token}
        url=str(self.location)+"/rest/V1/customers/search?searchCriteria[filterGroups][0][filters][0][field]=entity_id& searchCriteria[filterGroups][0][filters][0][value]="+str(self.cust_from_id)+"& searchCriteria[filterGroups][0][filters][0][conditionType]=gteq"
        response = requests.request("GET",url, headers=headers)
        print ("response",response.status_code)
        customer_list=response.json().get('items')
        print ("customer_list+++++",)
        for customer in customer_list:
            print ("customer++++++++++++",customer)
            self.CreateMagentoCustomer(customer)
        return True
    
    
    def CreateMagentoCustomer(self, customer):
        partner_obj = self.env['res.partner']
        partner_vals = {
            'name' : str(customer['firstname'])+ ' ' + str(customer['lastname']),
            'email' : customer['email'],
            'mag_cust_id':customer['id'],
            'customer_rank' : True,
            'magento_instance_ids':self.id,
            'mag_website_in': customer['created_in'],
            'magento_customer':True,
        }
        print ("partner_vals++++++++++++++++",partner_vals)
        partner_id=partner_obj.search([('mag_cust_id','=',customer['id']),('magento_instance_ids','=',self.id)])
        print ("partner_id+++++++++++",partner_id)
        if not partner_id:
            partner_id = partner_obj.create(partner_vals)
            print ("vpartner+_____IDDIDIDID",partner_id)
        else:
            partner_obj.write(partner_vals)
            print ("vpartner+_____IDDIDIDID",partner_id)
        if partner_id:
            self.createMagentoAddress(customer["addresses"],partner_id)
        print("cust_from_id____write______",self.write({'cust_from_id': customer['id']}))
        return True

    
    def createMagentoAddress(self, address,partner_id):
        #try:
#            group_id=customer.get('group_id',False)
#            if customer["store_id"]:
#                shop_id=self.env['magento.store'].search([('store_id','=',customer["store_id"])])
#            if group_id:
#                cust_group=self.env['customer.group'].search([('customer_group_code','=',group_id)])
#                if not cust_group:
#                    self.import_customer_group()
#                    cust_group=self.env['customer.group'].search([('customer_group_code','=',group_id)])
        for cust_address in address:
            print ("cust_address++++++",cust_address)
            partner_vals={}
            company = []
            country_id=self.env['res.country'].search([('code','=',cust_address.get("country_id",False))])
            if country_id:
                partner_vals.update({'country_id':country_id.id})
                if cust_address.get("region",False)['region_code']:
                    state_code = cust_address["region"]["region_code"]
                    state_ids=self.env['res.country.state'].search([('code','=',state_code),('country_id','=',country_id.id)])
                    if not state_ids:
                        state_id=self.env['res.country.state'].create({
                            'code':state_code,
                            'name':cust_address["region"]["region"],
                            'country_id':country_id.id
                            })
                        partner_vals.update({ 'state_id':state_id.id})
                    else:
                        state_id = state_ids[0].id
            if len(cust_address.get('street',False)):
                street,street1=False,False
                street=cust_address.get('street',False)[0]
                if len(cust_address.get('street',False))==2:
                    street1=cust_address.get('street',False)[1]
                partner_vals.update({'street':street,
                                    'street2':street1})
            if cust_address.get('defaultShipping',False):
                partner_vals.update({'type': 'delivery'})
            elif cust_address.get('defaultBilling',False):
                partner_vals.update({'type': 'invoice'})
            else:
                partner_vals.update({'type': 'other'})
            if cust_address.get('default_billing') == True:
                address_type = 'invoice'
            else:
                address_type=''
            if cust_address.get('default_shipping') == True:
                address_type = 'delivery'
            else:
                address_type=''

            partner_vals.update({
                'mag_address_id':cust_address.get(str('id')),
                'name':cust_address.get("firstname",False) + ' ' + cust_address.get("lastname",False),
                'phone':cust_address.get('telephone',False),
                'zip':cust_address.get('postcode',False),
                'city':cust_address.get('city',False),
                'magento_customer': True,
                'mag_cust_id':cust_address.get(str('customer_id')),
                'parent_id':partner_id.id,
                'type': address_type,
                          })
            print ("partner_vals+++++++++++++",partner_vals)
            print ("mag_cust_id+++++++++++++",cust_address.get(str('customer_id')))
            child_id=self.env['res.partner'].search([('mag_address_id','=',cust_address.get(str('id'))),('mag_cust_id','=',cust_address.get(str('customer_id')))])
            print ("partner_id+++++++++",child_id)
            if not child_id:
                child_id = self.env['res.partner'].create(partner_vals)
                print ("child_id+++++++++++++creating first partner",child_id)
                self._cr.commit()
            else:
                child_id = self.env['res.partner'].write(partner_vals)
                    #self._cr.commit()
#        except Exception as exc:
#            logger.error('Exception===================:  %s', exc)
#            pass   
        return True
    
    
    
    def GtImportProductImage(self):
        pro_obj=self.env['product.product']
        shop_obj=self.env['gt.magento.store']
        shop_ids=shop_obj.search([])
        if not shop_ids:
            raise UserError(_('Please Create Store'))
        self.generate_token()
        headers = {
            'authorization':"Bearer "+self.token
            }
        product_ids=pro_obj.search([('magento_product','=',True),('active','=',True),('magento_id','!=','')])
        if  product_ids: 
            for prod_data in product_ids:
                #try:
                if prod_data.default_code:
                    url=self.location+"/rest/V1/products/"+str(prod_data.default_code)+"/media"
                    response = requests.request("GET",url, headers=headers)
                    if str(response.status_code)=='200':
                        list_prods=json.loads(response.text)
                        self.create_image(prod_data,list_prods)
#                except Exception as exc:
#                    print (exc)
        return True
    
    
    
    def create_image(self,prod_data,list_prods):
        img_obj=self.env['product.photo']
        multi_instance = self.env['gt.magento.product.image.multi']
        for list_prod in list_prods:
            logger.error('Exception====list_prod===============:  %s', list_prod)
            #try:
            if list_prod['id']:
                image_name=list_prod['file'].split('.')[0].split('/')[-1]
                url = self.location +  '/pub/media/catalog/product' + list_prod['file']
                file_contain = urllib.request.urlopen(url).read()
                image_path = base64.encodestring(file_contain)

                vals = {
                        'magento_url':list_prod['file'],
                        'name':image_name,
                        'link': 1,
                        'url':url,
                        'product_id': prod_data.id,
                        'is_exported':True,
                        'magento_id':list_prod['id']
                }
                if len(list_prod['types']):
                    for image_type in list_prod['types']:
                        if 'image' in image_type:
                            vals.update({'base_image':True})
                        if 'small_image' in image_type:
                            vals.update({'small_image':True})
                        if 'thumbnail' in image_type:
                            vals.update({'thumbnail':True})

                img_ids = img_obj.search([('name','=',image_name),('product_id','=',prod_data.id)])
                if img_ids:
                    instance_ids = []
                    if len(img_ids.magento_instance_ids) > 0:
                        for old_instance_id in self.magento_instance_ids:
                            instance_ids.append(old_instance_id.id)
                        vals.update({'magento_instance_ids':[(6,0,instance_ids)]})
                    image_id = img_ids.write(vals)
                    logger.error('write image=============:  %s', image_id)
                    logger.error('write image=============:  %s', image_id)
                else:
                    img_ids =img_obj.create(vals)
                    if img_ids and img_ids[0].link==True:
                        file_data = urllib.request.urlopen(img_ids.url).read()
                        image_path = base64.encodestring(file_data)
                        image_id = img_ids.write({'image':image_path})
                instance_id = multi_instance.search([('magento_id','=',list_prod['id']),('gt_magento_instance_id','=',self.id),('gt_magento_exported','=',True),('images_ids','=',img_ids.id)])
                if not instance_id:
                    instance_id = multi_instance.create({'magento_id':list_prod['id'],'gt_magento_instance_id':self.id,'gt_magento_exported':True,'images_ids':img_ids.id})
                prods_id = []
                for prod_id in img_ids.gt_magento_image_ids:
                    prods_id.append(prod_id.id)
                if instance_id.id not in prods_id:
                    prods_id.append(instance_id.id)
                img_ids.write({'gt_magento_image_ids':[(6,0,prods_id)]})
            image_data=img_obj.search([('product_id','=',prod_data.id)])
            if image_data and image_data[0].link== True:
                file_contain = urllib.request.urlopen(image_data[0].url).read()
                image_path = base64.encodestring(file_contain)
            else:
                image_path = image_data.image
            update=prod_data.write({'image_1920':image_path})
            print ("image_id++++++++++++",image_id)
#            except Exception as exc:
#                logger.error('Exception===================:  %s', exc)
#                pass
        self._cr.commit()
        return True


    
    def GtImportMagentoStock(self):
        try:
            product_obj=self.env['product.product']
            stock_inve_line_obj=self.env['stock.inventory.line']
            stock_inv_obj=self.env['stock.inventory']
            self.generate_token()
            headers = {
                'authorization':"Bearer "+self.token
                }
            product_list = product_obj.search([('magento_instance_ids','=',self.id),('magento_product','=',True)])
            print ("product_list++++++++++++++",product_list)
            print ("product_list lenght ++++++", len(product_list))
            inventory_id = stock_inv_obj.create({'name':'update stock'+' '+str(datetime.datetime.now())})
            for product in product_list:
                try:
                    if product.default_code:
                        url=self.location+"/rest/V1/stockItems/"+str(product.default_code)+"?searchCriteria"
                        response = requests.request("GET",url, headers=headers)
                        each_response=json.loads(response.text)
                        if ('qty') in each_response:
                            if (each_response['qty']) != None:
                                if float(each_response['qty']) > 0.0000:
                                    data = stock_inve_line_obj.create({'inventory_id':inventory_id.id,'location_id':self.location_id.id,'product_id':product.id,'product_qty':each_response['qty']})
                                    self._cr.commit()
                except Exception as exc:
                        logger.error('Exception===================:  %s', exc)
                        pass 

            inventory_id.action_done()
            self._cr.commit()
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
            pass
        return True

    def GtExportProductStock(self):
        multi_instance = self.env['gt.magento.product.multi']
        try:
            product_obj=self.env['product.product']
            (instances,)=self.browse(self._ids)
            instances.generate_token()
            headers = {
                'authorization':"Bearer "+instances.token,
                'content-type': "application/json",
                'cache-control': "no-cache",
                }
            product_list = product_obj.search([('magento_instance_ids','=',self.id),('magento_product','=',True)])
            for product in product_list:
                multi_id = multi_instance.search([('gt_magento_instance_id','=',self.id),('gt_magento_exported','=',True),('product_id','=',product.id)])
                try:
                    if product.qty_available > 0.00:
                        vals = { "stockItem": {
                            "itemId": 0,
                            "productId": multi_id.magento_id,
                            "stockId": 1,
                            "qty": product.qty_available,
                            "isInStock": "true",
                            "extensionAttributes": {}
                          }
                        }
                        payload = str(vals) 
                        payload=payload.replace("'",'"')     
                        payload=str(payload)
                        url=self.location+"/rest/V1/products/"+str(product.default_code)+"/stockItems/"+"0"
                        response = requests.request("PUT",url, data=payload, headers=headers)
                        print (response)
                        if str(response.status_code)=="200":
                            each_response=json.loads(response.text)
                except Exception as exc:
                        logger.error('Exception===================:  %s', exc)
                        pass 
        except Exception as exc:
            logger.error('Exception===================:  %s', exc)
            pass
        return True
