# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import date


class EnrollmentProgram(models.Model):
    _name = 'ils.enrollment'
    _description = 'Enrollment Program'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name')
    student_id = fields.Many2one(comodel_name='res.partner', string='Student', domain="([('contact_type', '=', 'student')])")
    sponsor_id = fields.Many2one(comodel_name='res.partner', string='Sponsor', domain="([('contact_type', '=', 'sponsor')])")
    program_id = fields.Many2one(comodel_name='product.template', string='Program', domain="([('is_program', '=', True)])")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    score = fields.Float(string='Assessment Score', default=1)
    url = fields.Char(string='URL (PDF)')
    module_id = fields.Many2one(comodel_name='ils.modules')
    state = fields.Selection(string='Status', selection=[
        ('new', 'NEW'),
        ('send_to_lms', 'SEND TO LMS'),
        ('sent_to_lms', 'SENT TO LMS'),
        ('enrolled', 'ENROLLED'),
        ('inactive', 'INACTIVE'),
        ('archived', 'ARCHIVED')],
        default='new')
    enroll_student_ids = fields.Many2many('ils.enrollment.student.group', 'enrollment_group_rel', 'enrollment_id', 'group_id', copy=False)
    api_ref_code = fields.Char(readonly=True)
    enrollment_student_semester_ids = fields.One2many('ils.enrollment.student.semester', 'student_enrollment_id') 

    def create(self, vals):
        res = super(EnrollmentProgram, self).create(vals)
        if res.academy_id and res.student_id:
            current_date = date.today()
            sequence = self.env['ir.sequence'].next_by_code('sutdent_id')
            res.student_id.student_id = '%s%s%s%s' % (res.academy_id.code.upper(), '{:02d}'.format(current_date.month), current_date.strftime("%y"), sequence)
        return res

    def write(self, vals):
        
        if  vals and vals.get('enroll_student_ids'):
            before_enroll_student_ids = self.enroll_student_ids.ids
            res = super(EnrollmentProgram, self).write(vals)
            after_enroll_student_ids = self.enroll_student_ids.ids
            removed_enrollments = list(set(before_enroll_student_ids) - set(after_enroll_student_ids))
            if removed_enrollments:
                for group in self.env['ils.enrollment.student.group'].browse(removed_enrollments):
                    sql_query = """DELETE
                                FROM enrollment_student_group_rel
                                WHERE group_id = """ + str(group.id) + """
                                AND enrollment_id = """ + str(self.id) + """
                                """
                    self.env.cr.execute(sql_query)
        else:
            res = super(EnrollmentProgram, self).write(vals)
        if self.student_id and self.academy_id:
            if not self.student_id.student_id:
                current_date = date.today()
                sequence = self.env['ir.sequence'].next_by_code('sutdent_id')
                self.student_id.student_id = '%s%s%s%s' % (self.academy_id.code.upper(), '{:02d}'.format(current_date.month), current_date.strftime("%y"), sequence)

        return res

    @api.onchange('sponsor_id')
    def sponsor_send_to_lms(self):
        for record in self:
            if record.sponsor_id and record.academy_id:
                self.write({
                    'state': 'send_to_lms',
                })
    
    @api.onchange('academy_id')
    def academy_send_to_lms(self):
        for record in self:
            if record.sponsor_id and record.academy_id:
                self.write({
                    'state': 'send_to_lms',
                })

    def action_export_timesheet(self):
        return {
            'name': 'Export TimeSheet',
            'view_mode': 'form',
            'res_model': 'ils.timsheet.filter',
            'type': 'ir.actions.act_window',
            'context': {'default_enrollment_id': self.id},
            'target': 'new',
        }
