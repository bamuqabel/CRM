# -*- coding: utf-8 -*-

from odoo import models, fields, api
import datetime
import calendar
from datetime import timedelta, date
import xlwt
import base64
import xlsxwriter
from io import BytesIO


class ilsTimeTable(models.Model):
    _name = 'ils.timetable'
    _description = 'Time Table'

    name = fields.Char(readonly=True)
    date = fields.Date(string='Date', required=True)
    timetable_line_ids = fields.One2many(comodel_name='ils.timetable.line', inverse_name='timetable_id')
    batch_id = fields.Many2one(comodel_name='ils.batch')
    semester_id = fields.Many2one(comodel_name='ils.semester')
    week_day = fields.Selection(string='Week Day', selection=[
        ('sunday', 'Sunday'),
        ('monday', 'Monday'),
        ('tuesday', 'Tuesday'),
        ('wednesday', 'Wednesday'),
        ('thursday', 'Thursday'),
        ('friday', 'Friday'),
        ('saturday', 'Saturday'),
        ])
    state = fields.Selection(string='Status', selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ], default='draft')
    descripton = fields.Char()

    @api.depends('date')
    def name_get(self):
        res = []
        for rec in self:
            rec.name = 'TimeTable (%s)' % (rec.date)
            res += [(rec.id, rec.name)]
        return res


class ilsTimeTableLine(models.Model):
    _name = 'ils.timetable.line'
    _description = 'Time Table Line'

    timetable_id = fields.Many2one(comodel_name='ils.timetable')
    module_id = fields.Many2one(comodel_name='ils.modules')
    batch_id = fields.Many2one(comodel_name='ils.batch')
    batch_group_id = fields.Many2one(comodel_name='ils.enrollment.student.group', string="Batch Group")
    room_id = fields.Many2one('ils.room')
    batch_time = fields.Char(string="Batch Time")
    time_index = fields.Char(string="Time Index")
    descripton = fields.Char(string="Description")
    date = fields.Date(string='Date', required=True)
    teacher_ids = fields.Many2many('ils.teacher', 'teacher_timetable_rel', 'time_line_id', 'teacher_id')
    semester_id = fields.Many2one(comodel_name='ils.semester')

    def daterange(self, start_date, end_date):
        for n in range(int((end_date - start_date).days) + 1):
            yield start_date + timedelta(n)

    @api.model
    def change_draft_timetable(self, line_id=False, change_date=False, change_time_index=False, change_time=False, batch_group_id=False, update_draft_timesheet=False):
        timetable_line_obj =  self.env['ils.timetable.line']
        academy_dayoff_obj = self.env['ils.academy.dayoff']

        if line_id and batch_group_id and change_date and change_time_index:
            batch_group = self.env['ils.enrollment.student.group'].browse(int(batch_group_id))
            academy_id = batch_group.batch_id.academy_id
            start_date = datetime.datetime.strptime(change_date , '%Y-%m-%d')
            academy_day_off_id = academy_dayoff_obj.search([('day_off_date', '=', start_date), ('academy_id', '=', academy_id.id)])

            if start_date.strftime("%A").lower() not in ['friday', 'saturday'] and not academy_day_off_id:
                # check related theory module index in same date
                check_related_module = timetable_line_obj.search([
                    ('module_id', '=', batch_group.module_id.related_module.id),
                    ('date', '=', start_date),
                    ('time_index', '=', change_time_index - 1)])
                if check_related_module:
                    return False

                # available room condition
                check_room_available = timetable_line_obj.search([
                    ('room_id', '=', batch_group.room_id.id),
                    ('time_index', '=', change_time_index),
                    ('date', '=', start_date)])
                if check_room_available:
                    return False

                # teacher available condition
                assign_teacher_ids = []
                for teacher in  batch_group.teacher_ids:
                    teacher_working_hours = teacher.no_of_hours
                    check_teacher_available = timetable_line_obj.search([
                        ('teacher_ids', 'in', [teacher.id]),
                        ('date', '=', start_date)])
                    if len(check_teacher_available) < int(teacher_working_hours):
                        assign_teacher_ids.append(teacher.id)
                if assign_teacher_ids:
                    assign_teacher_ids = [ (4, teacher_id) for teacher_id in assign_teacher_ids ]
                else:
                    return False

                if update_draft_timesheet:
                    if update_draft_timesheet.get(line_id):
                        update_draft_timesheet.get(line_id).update({
                            'date': start_date,
                            'batch_group_id': batch_group.id,
                            'time_index': change_time_index,
                            'batch_time': change_time})
                    else:
                        update_draft_timesheet.update({line_id : {
                        'date': start_date,
                        'batch_group_id': batch_group.id,
                        'time_index': change_time_index,
                        'batch_time': change_time}})
                    return update_draft_timesheet
                else:
                    return {line_id : {
                        'date': start_date,
                        'batch_group_id': batch_group.id,
                        'time_index': change_time_index,
                        'batch_time': change_time}}
            else:
                return False
        else:
            return False

    @api.model
    def save_final_timesheet(self, update_draft_timesheet=False):
        timetable_line_obj =  self.env['ils.timetable.line']
        timetable_obj =  self.env['ils.timetable']
        batch_group_obj = self.env['ils.enrollment.student.group']
        if update_draft_timesheet:
            batch_group = False
            for line_id in update_draft_timesheet:
                line_dict = update_draft_timesheet.get(line_id)
                timetable_line = timetable_line_obj.browse(int(line_id))
                start_date = datetime.datetime.strptime(str(line_dict.get('date')), '%Y-%m-%d %H:%M:%S')
                batch_group = batch_group_obj.browse(int(line_dict.get('batch_group_id')))
                timetable = timetable_obj.search([('date', '=', start_date.date()), ('batch_id', '=', batch_group.batch_id.id)])
                if timetable:
                    timetable_line.write({
                        'timetable_id': timetable.id,
                        'date': start_date.date(),
                        'batch_time': line_dict.get('batch_time'),
                        'time_index': int(line_dict.get('time_index')),
                        })
            # update all Timetable status to Saved
            if batch_group:
                batch_group.batch_id.timesheet_saved = True
            batch_timetables = timetable_obj.search([('batch_id', '=', batch_group.batch_id.id)])
            if batch_timetables:
                batch_timetables.write({'state': 'confirm'})
            return "Timesheet saved!"
        else:
            return "Timesheet not saved!"

    @api.model
    def export_generated_timesheet(self, active_scale=None, activateSwap=None, active_batch_id=None, timesheet_start_date=None, timesheet_end_date=None, current_date=None):
        ils_batch_obj = self.env['ils.batch']
        ils_acedamy_obj = self.env['ils.academy.timeslot']
        ils_module_obj = self.env['ils.modules']
        start_date = False
        end_date = False
        day_off_list = []
        time_table_data = {
            'active_scale': active_scale,
            'date_range': False,
            'date_slot': [],
            'timeslot': [],
            'time_slot_data': [],
            'day_off_list':[]}

        selected_date_range = []
        timesheet_start_date = datetime.datetime.strptime(timesheet_start_date, '%Y-%m-%d') if timesheet_start_date else False
        timesheet_end_date = datetime.datetime.strptime(timesheet_end_date, '%Y-%m-%d') if timesheet_end_date else False
        for date in self.daterange(timesheet_start_date, timesheet_end_date):
            selected_date_range.append(date.date())

        if activateSwap == 'today':
            today = datetime.datetime.today().date()
        elif current_date and activateSwap != 'today':
            today = datetime.datetime.strptime(current_date, "%Y-%m-%d")
            # count days dependes on active_scale
            if active_scale == 'day':
                days = 1
            if active_scale == 'week':
                days = 7
            if active_scale == 'month':
                days = 28
            # generate active date
            if activateSwap == 'previous':
                today = today - datetime.timedelta(days=days)
            elif activateSwap == 'next':
                today = today + datetime.timedelta(days=days)

        if active_scale == 'day':
            time_table_data['date_range'] = datetime.datetime.strftime(today, "%d %B %Y")
            # set hours list
            for i in range(1,25):
                suffix = "am" if i < 12 else "pm"
                time_table_data.get('date_slot').append({
                    'start_date': datetime.datetime.strftime(today, "%Y-%m-%d"),
                    'display_date': (str(i) + " " + suffix)
                })
        elif active_scale == 'week':
            start_date = today - datetime.timedelta(days=today.weekday() + 1)
            end_date = start_date + datetime.timedelta(days=6)
            time_table_data['date_range'] = start_date.strftime("%d %B %Y") + " - " + end_date.strftime("%d %B %Y")
        elif active_scale == 'month':
            _, num_days = calendar.monthrange(today.year, today.month)
            start_date = datetime.date(today.year, today.month, 1)
            end_date = datetime.date(today.year, today.month, num_days)
            time_table_data['date_range'] = start_date.strftime("%B %Y")

        if active_scale in ['week', 'month']:
            for single_date in self.daterange(start_date, end_date):
                if active_scale == 'week':
                    day = int(single_date.strftime("%d"))
                    suffix = 'th' if 11 <= day <= 13 else {1:'st',2:'nd',3:'rd'}.get(day%10, 'th')
                    time_table_data.get('date_slot').append({
                        'start_date': datetime.datetime.strftime(single_date, "%Y-%m-%d"),
                        'display_date': (single_date.strftime("%A, %d") + suffix)
                    })
                elif active_scale == 'month':
                    time_table_data.get('date_slot').append({
                        'start_date': datetime.datetime.strftime(single_date, "%Y-%m-%d"),
                        'display_date': (single_date.strftime("%d"))
                    })
                else:
                    pass
                # check if date is sundays
                if single_date.strftime("%A").lower() in ['friday', 'saturday']:
                    day_off_list.append(datetime.datetime.strftime(single_date, "%Y-%m-%d"))

        batch_id = ils_batch_obj.browse(active_batch_id)
        timeslot = batch_id.get_timetable_timeslot()
        time_table_data['timeslot'] = timeslot

        # get off dates
        academy_id = batch_id.academy_id
        academy_day_offs = self.env['ils.academy.dayoff'].search([
            ('day_off_date', '>=', start_date),
            ('day_off_date', '<=', end_date),
            ('academy_id', '=', academy_id.id)]).mapped('day_off_date')
        for date in academy_day_offs:
            day_off_list.append(datetime.datetime.strftime(date, "%Y-%m-%d"))

        # holidays = self.env['hr.holidays.public.line'].search([
        #     ('date', '>=', start_date),
        #     ('date', '<=', end_date)]).mapped('date')
        # for date in holidays:
        #     day_off_list.append(datetime.datetime.strftime(date, "%Y-%m-%d"))

        if day_off_list:
            time_table_data.update({'day_off_list': day_off_list})

        time_table_batches = ils_batch_obj.get_table_data(batch_id.ids, selected_date_range, time_table_data.get('date_slot'), timeslot, teacher_ids=None, student_enrollment_ids=None)
        time_table_data['time_slot_data'] = time_table_batches
        attachment_id = self.generate_excel_report(time_table_data)
        if attachment_id:
            return '/web/content/%s?download=true' % (attachment_id.id)

    def generate_excel_report(self, time_table_data, diff_days=None):
        filename = 'Timesheet' + '.xls'
        fp = BytesIO()
        workbook = xlsxwriter.Workbook(fp)
        heading = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'bg_color': "#FFDAB9"})
        bold = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': "#C0C0C0"})
        other_label = workbook.add_format({'bold': True, 'align': 'center', 'font_name': 'Times New Roman', 'bg_color': "#C0C0C0"})
        data_row = workbook.add_format({'align': 'left', 'text_wrap': True})
        sheet = workbook.add_worksheet('Time sheet %s Report' % time_table_data['date_range'])
        row = 0
        col = 1
        sheet.set_column(row, col, 25)
        # sheet.write(row, col, 'Variables', bold)
        for date in time_table_data['date_slot']:
            date_day = datetime.datetime.strptime(date.get('start_date'), '%Y-%m-%d')
            data = '%s \n%s' % (date.get('start_date'), date_day.strftime('%A'))
            sheet.set_column(row, col, 25)
            sheet.write(row + 1, col, data, other_label)
            col +=1 
        row += 1
        col = 0
        day_off_list = []
        for day_off in time_table_data['day_off_list']:
            day_off_list.append(int(day_off.split('-')[-1]))
        for time, value in time_table_data['time_slot_data'].items():
            row += 1
            col = 0
            sheet.write(row, col, time, other_label)
            line_list = []
            counter = 1
            for rec in value:
                if rec and rec.id not in line_list:
                    teachers = []
                    cous_time = 0
                    prep_time = 0
                    room_gap = rec.room_id.module_room_ids.search([('module_id', '=', rec.batch_group_id.module_id.id)])
                    for teacher in rec.teacher_ids:
                        cous_time += teacher.counselling_time
                        prep_time += teacher.preparation_time
                        teachers.append(teacher.teacher_id.name)
                    col += 1
                    if counter in day_off_list:
                        sheet.write(row, col, 'Day Off', other_label)
                        col += 1
                        counter += 1
                    data = 'Batch: %s, \nSemester: %s, \nModule: %s,\nRoom : %s, \nTeacher: %s, \nCounselling time: %s Mins, \nPreparation time: %s Mins, \nGap betweem classes (In Minutes): %s Mins' % (rec.batch_id.name, rec.semester_id.name, rec.batch_group_id.module_id.name, rec.room_id.name, str(teachers)[1:-1], cous_time, prep_time, room_gap.gap_between_class if room_gap else 0)
                    sheet.write(row, col, data, data_row)
                    line_list.append(rec.id)
                    counter += 1

        workbook.close()
        file_save = base64.encodestring(fp.getvalue())
        fp.close()
        xls_val = dict(
            name=filename,
            store_fname=filename,
            res_model='ils.batch',
            type='binary',
            datas=file_save,
        )
        attachment = self.env['ir.attachment'].create(xls_val)
        return attachment
