
import datetime
from odoo import api, fields, models
from datetime import timedelta


class ilsTimesheetFilter(models.TransientModel):
	_name = 'ils.timsheet.filter'
	_description = 'ILS Timesheet Filter'

	teacher_id = fields.Many2one('ils.teacher')
	timesheet_start_date = fields.Date('Start Date')
	timesheet_end_date = fields.Date('End Date')
	enrollment_id = fields.Many2one('ils.enrollment')

	def daterange(self, start_date, end_date):
		for n in range(int((end_date - start_date).days) + 1):
			yield start_date + timedelta(n)

	def generate_timesheet(self):
		ils_batch_obj = self.env['ils.batch']
		ils_acedamy_obj = self.env['ils.academy.timeslot']
		ils_module_obj = self.env['ils.modules']
		start_date = False
		end_date = False
		day_off_list = []
		time_table_data = {
			'date_range': False,
			'date_slot': [],
			'batch_id': {},
			'time_slot_data': [],
			'day_off_list':[]}

		selected_date_range = []
		# timesheet_start_date = datetime.datetime.strptime(self.timesheet_start_date, '%Y-%m-%d') if self.timesheet_start_date else False
		# timesheet_end_date = datetime.datetime.strptime(self.timesheet_end_date, '%Y-%m-%d') if self.timesheet_end_date else False
		for date in self.daterange(self.timesheet_start_date, self.timesheet_end_date):
			selected_date_range.append(date)

		# set hours list
		time_table_data['date_range'] = self.timesheet_start_date.strftime("%d %B %Y") + " - " + self.timesheet_end_date.strftime("%d %B %Y")
		for single_date in self.daterange(self.timesheet_start_date, self.timesheet_end_date):
			day = int(single_date.strftime("%d"))
			suffix = 'th' if 11 <= day <= 13 else {1:'st',2:'nd',3:'rd'}.get(day%10, 'th')
			time_table_data.get('date_slot').append({
				'start_date': datetime.datetime.strftime(single_date, "%Y-%m-%d"),
				'display_date': (single_date.strftime("%A, %d") + suffix)
			})
			# check if date is sundays
			if single_date.strftime("%A").lower() in ['friday', 'saturday']:
				day_off_list.append(datetime.datetime.strftime(single_date, "%Y-%m-%d"))

		batch_ids = []
		if self.teacher_id:
			batch_ids = self.env['ils.enrollment.student.group'].search([('teacher_ids', 'in', self.teacher_id.id)]).mapped('batch_id')
		else:
			batch_ids = self.enrollment_id.enroll_student_ids.mapped('batch_id')
		timeslot_list = []
		for batch_id in batch_ids:
			timeslot = batch_id.get_timetable_timeslot()
			timeslot_list.append(timeslot)
			# if not old_time_slot:
			# 	old_time_slot = time
			academy_id = batch_id.academy_id
			academy_day_offs = self.env['ils.academy.dayoff'].search([
				('day_off_date', '>=', start_date),
				('day_off_date', '<=', end_date),
				('academy_id', '=', academy_id.id)]).mapped('day_off_date')
		time_table_data['batch_id'] = {'time_slot': timeslot_list}

		# # get off dates
		for date in academy_day_offs:
			day_off_list.append(datetime.datetime.strftime(date, "%Y-%m-%d"))

		# holidays = self.env['hr.holidays.public.line'].search([
		# 	('date', '>=', start_date),
		# 	('date', '<=', end_date)]).mapped('date')
		# for date in holidays:
		# 	day_off_list.append(datetime.datetime.strftime(date, "%Y-%m-%d"))

		if day_off_list:
			time_table_data.update({'day_off_list': day_off_list})
		time_table_batches = ils_batch_obj.get_table_data(batch_ids.ids, selected_date_range, time_table_data.get('date_slot'), timeslot, self.teacher_id.ids, student_enrollment_ids=self.enrollment_id)
		time_table_data['time_slot_data'] = time_table_batches
		days_diff = self.timesheet_end_date  - self.timesheet_start_date
		attachment = self.env['ils.timetable.line'].generate_excel_report(time_table_data, days_diff.days)
		action = {
			'name': 'FEC',
			'type': 'ir.actions.act_url',
			'url': '/web/content/%s?download=true' % (attachment.id),
			'target': 'self',
			}
		return action
		