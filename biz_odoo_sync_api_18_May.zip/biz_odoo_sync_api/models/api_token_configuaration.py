# -*- coding: utf-8 -*-

import json
import requests
from odoo import models, fields, api, _

class ApiTokenConfiguration(models.Model):
    _name = 'ils.api.token.configuration'

    name = fields.Char('API Name', required=1)
    url = fields.Char('API Url', required=1)
    username = fields.Char('Username', required=1)
    password = fields.Char('Password', required=1)
    privatekey = fields.Char('Private key', required=1)
    auth_token = fields.Char('Authorization Token', readonly=1)
    
    def auth_token_cron(self):
        if not self:
            self = self.env['ils.api.token.configuration'].search([])
        for rec in self:
            header = dict()
            header.update({
                'accept': 'application/json',
                'content-type': 'application/json',
            })
            url = 'https://vetbyehl.sandbox.myabsorb.eu/api/Rest/v1/Authenticate'
            body = {
                      "Username": rec.username,#"nah@ils.com.sa",
                      "Password": rec.password, #"123456",
                      "PrivateKey": rec.privatekey #"63e0ac3d-6862-4228-9ae5-2fcee16f3950"
                    }
            req = requests.post(rec.url, headers=header, json=body)
            content = json.loads(req.content)
            rec.auth_token = content
            