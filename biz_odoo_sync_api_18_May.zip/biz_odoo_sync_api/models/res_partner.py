# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class ResPartner(models.Model):
    _inherit = "res.partner"

    api_ref_code = fields.Char('API Reference Code', reaonly=True)
