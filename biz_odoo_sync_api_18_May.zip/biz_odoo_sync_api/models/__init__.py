# -*- coding: utf-8 -*-

from . import api_token_configuaration
from . import res_partner
from . import api_configuration