
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import ast


class ilsBatchGroupConfirmation(models.TransientModel):
    _name = 'ils.batch.group.confirmation'
    _description = 'ILS Batch Group Confirmation'

    batch_id = fields.Many2one('ils.batch', String="Batch")
    is_entrollement_group_created = fields.Boolean(string="Is enrollement group created", default=False)
    enrollment_student_group_ids = fields.One2many(comodel_name='ils.batch.group.confirmation.lines', inverse_name='group_confirmation_id', string="Enrollment Groups")
    display_message = fields.Text(string="Display Message")
    student_ids = fields.Char(string="student IDs")

    @api.model
    def default_get(self, fields):
        res = super(ilsBatchGroupConfirmation, self).default_get(fields)
        batch_id = self.env['ils.batch'].browse(self.env.context['active_ids']) if self.env.context and self.env.context.get('active_ids') else False
        student_ids = self.env['ils.enrollment'].search([('program_id', '=', batch_id.program_id.id)]).ids
        enrolled_student_group = self.env['ils.enrollment.student.group'].search([
            ('enroll_student_ids', 'in', student_ids),
            ('batch_id', '!=', batch_id.id) ]).mapped('enroll_student_ids')
        if enrolled_student_group:
            student_ids = list(set(student_ids) - set(enrolled_student_group.ids))
        res.update({'batch_id': batch_id.id, 'student_ids': student_ids})
        if batch_id.enrollment_student_group_ids:
            display_message = "This process will remove the existing batch groups for this batch and creates new groups based on current configurations. Are you sure, you want to proceed?"
        else:
            display_message = "Are you sure to create batch groups?"
        res.update({'display_message': display_message})
        return res

    def action_create_confirmation_lines(self):
        batch_id = self.batch_id
        confirmation_line_onj = self.env['ils.batch.group.confirmation.lines']
        enrollment_onj = self.env['ils.enrollment']
        if batch_id.enrollment_student_group_ids:
            batch_id.remove_branch_groups()
            # delete existing timetable
            existing_timetables = self.env['ils.timetable'].search([('batch_id', '=', batch_id.id)])
            existing_timetable_lines = self.env['ils.timetable.line'].search([('timetable_id', 'in', existing_timetables.ids)])
            existing_timetable_lines.unlink()
            existing_timetables.unlink()

        # to create new groups
        flag = False
        program_id = batch_id.program_id
        module_ids = self.env['ils.modules'].search([('id', 'in', batch_id.program_id.module_ids.ids)], order="is_practical")
        # student_ids = self.env['ils.enrollment'].search([('program_id', '=', program_id.id)])
        student_ids = ast.literal_eval(self.student_ids)

        if student_ids:
            for module in module_ids:
                module_room_id = self.env['ils.module.room'].search([('module_id', '=', module.id)], order='id, capacity')
                if module_room_id:
                    module_room_id = module_room_id[0]
                    # create student groups
                    list_student_ids = student_ids
                    capacity = module_room_id.capacity
                    strudent_groups = []
                    while len(list_student_ids) > capacity:
                        strudent_groups.append(list_student_ids[:capacity])
                        list_student_ids = list(set(list_student_ids) - set(list_student_ids[:capacity]))
                    else:
                        strudent_groups.append(list_student_ids)
                    flag = True if strudent_groups else False
                    # create group records
                    group_count = 0
                    for group in strudent_groups:
                        group_count += 1
                        group_student_ids = [ (4, stud_id) for stud_id in group ]
                        confirmation_line_onj.create({
                            'name': module.name + " - " + batch_id.name + " - Group " + str(group_count),
                            'module_id': module.id,
                            'batch_id': batch_id.id,
                            'room_id': module_room_id.room_id.id,
                            'enroll_student_ids': group_student_ids,
                            'group_confirmation_id': self.id,
                            'teacher_ids': module.teacher_ids,
                            })
                else:
                    error_message = "'" + str(module.name) + "' module have no room assigned. Please update the room details in module first!"
                    raise UserError(_(error_message))
        else:
            error_message = "All students are already enrolled in another batches!"
            raise UserError(_(error_message))

        if flag == True:
            self.is_entrollement_group_created = True
            wizard_action = {'type': 'ir.actions.act_window',
                            'res_model': self._name,
                            'name': 'Created Groups',
                            'view_mode': 'form',
                            'context': dict(self.env.context,
                                            wizard_id=self.id,
                                            view_cache=False,),
                            'target': 'new',
                            'res_id': self.id,}
            return wizard_action
        else:
            error_message = "No details found to create groups. Please check configuratinons!"
            raise UserError(_(error_message))

    def action_create_groups(self):
        enrollment_student_group_obj = self.env['ils.enrollment.student.group']
        for group_line in self.enrollment_student_group_ids:
            enrollment_student_group_obj.create({
                'name': group_line.name,
                'module_id':group_line.module_id.id,
                'batch_id': group_line.batch_id.id,
                'room_id': group_line.room_id.id,
                'enroll_student_ids': group_line.enroll_student_ids,
                'teacher_ids': group_line.teacher_ids
                })
        return True


class ilsBatchGroupConfirmationlines(models.TransientModel):
    _name = 'ils.batch.group.confirmation.lines'
    _description = 'ILS Batch Group Confirmation Lines'

    def _get_enroll_student_ids(self):
        domain = [('id','in', [])]
        if self.env.context.get('enroll_student_ids_list'):
            enrollements = ast.literal_eval(self.env.context.get('enroll_student_ids_list'))
            return [('id','in', enrollements)]
        return domain

    name = fields.Char(string="Name")
    module_id = fields.Many2one('ils.modules', String="Module")
    batch_id = fields.Many2one('ils.batch', String="Batch")
    room_id = fields.Many2one(comodel_name='ils.room', string="Room")
    enroll_student_ids = fields.Many2many('ils.enrollment', 'enrollment_student_group_confirmation_rel', 'group_id', 'enrollment_id', domain=_get_enroll_student_ids)
    group_confirmation_id = fields.Many2one('ils.batch.group.confirmation')
    teacher_ids = fields.Many2many('ils.teacher', 'teacher_student_group_confirmation_rel', 'group_id', 'teacher_id')
    room_capacity = fields.Integer(string='Capacity', compute="_compute_room_capacity", readonly=True)

    def _compute_room_capacity(self):
        for record in self:
            if record.module_id and record.room_id:
                module_room = self.env['ils.module.room'].search([
                    ('module_id', '=', record.module_id.id),
                    ('room_id', '=', record.room_id.id)])
                if module_room:
                    record.room_capacity = module_room.capacity
                else:
                    record.room_capacity = False

    @api.onchange('room_id')
    def onchange_room_id(self):
        for record in self:
            record._compute_room_capacity()

    @api.onchange('teacher_ids')
    def onchange_module_id(self):
        domain = {'teacher_ids': []}
        for rec in self:
            if rec.module_id:
                domain = {'teacher_ids': [('id', 'in', rec.module_id.teacher_ids.ids)]}
            if rec.teacher_ids:
                module_teachers = rec.module_id.teacher_ids.ids
                group_teachers = rec.teacher_ids.ids
                check =  all(teacher in module_teachers for teacher in group_teachers)
                if check is False:
                    worng_teacher_list = list(set(group_teachers) - set(module_teachers))
                    worng_teacher_name = ""
                    for teacher in self.env['ils.teacher'].search([('id', 'in', (worng_teacher_list))]):
                        worng_teacher_name += teacher.teacher_id.name + ", "
                    raise UserError(_(worng_teacher_name + " teacher allowed for this batch!"))
        return {'domain': domain}