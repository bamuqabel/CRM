# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Employment(models.Model):
    _name = 'ils.employment'
    _description = 'Employment'
    _rec_name = 'employer'

    date_from = fields.Date(string='From')
    date_to = fields.Date(string='To')
    empl_type = fields.Selection(string='Employment Type', selection=[
        ('full_time', 'Full Time'),
        ('part_time', 'Part Time'),
        ('freelancer', 'Freelancer'),
        ('fixed_term', 'Fixed Term'),
        ('shift_worker', 'Shift Worker'),
        ('trainee_or_apprentice', 'Trainee or Apprentice')]
    )
    hours = fields.Integer(string='No. of Hours')
    employer = fields.Many2one(comodel_name='ils.employer')
    position = fields.Char(string='Position')
    main_duties = fields.Text(string='Main Duties')
    attachment = fields.Binary(string='Attachment')
    student_id = fields.Many2one(comodel_name='res.partner', string='Student', domain="([('contact_type', '=', 'student')])")
