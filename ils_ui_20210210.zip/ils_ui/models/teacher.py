# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ilsTeacher(models.Model):
    _name = 'ils.teacher'
    _description = 'Teacher'
    _rec_name = 'teacher_id'

    code = fields.Char(string='Code', required=True)
    teacher_id = fields.Many2one('res.partner', string='Teacher')
    no_of_hours = fields.Float(string='No. of hours in Day')
    no_of_weeks = fields.Float(string='No. of hours in week')
    share_class = fields.Boolean(string='Share Class?')
    counselling_time = fields.Float(string='Counselling time')
    preparation_time = fields.Float(string='Preparation time')
    module_ids = fields.Many2many('ils.modules', 'teacher_module_rel', 'teacher_id', 'module_id')

    @api.onchange('no_of_hours')
    def onchange_module_level(self):
        for record in self:
            if record.no_of_hours:
                record.no_of_weeks = record.no_of_hours * 5