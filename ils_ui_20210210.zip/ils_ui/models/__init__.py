# -*- coding: utf-8 -*-

from . import res_partner
from . import academy
from . import product_template
from . import batch
from . import enrollment
from . import education
from . import employer
from . import employment
from . import admission_checklist
from . import modules
from . import semester
from . import room
from . import teacher
from . import timetable
from . import enrollment_student_group