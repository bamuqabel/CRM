# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ilsSemester(models.Model):
    _name = 'ils.semester'
    _description = 'Room'

    name = fields.Char(string='name')
    semester_code = fields.Char(string='Semester Code')
    program_id = fields.Many2one(comodel_name='product.template', required=True, string='Program', domain="([('is_program', '=', True)])")
    no_of_weeks = fields.Integer(string='No. of Weeks', required=True)
    module_ids = fields.Many2many(comodel_name='ils.modules')
    start_date = fields.Date(string='Start Date', default=fields.Date.context_today)
    end_date = fields.Date(string='End Date', default=fields.Date.context_today)
    semester_type = fields.Selection(string='Semester Type', selection=[
        ('half', 'Half'),
        ('full', 'Full'),],
        default='half')

    @api.depends('name', 'semester_code')
    def name_get(self):
        res = []
        for rec in self:
            name = "[%s]%s" % (rec.semester_code, rec.name)
            res += [(rec.id, name)]
        return res