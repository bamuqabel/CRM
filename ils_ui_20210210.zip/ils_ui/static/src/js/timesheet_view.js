odoo.define('ils_ui.timesheet_view', function (require) {
    "use strict";

    var core = require('web.core');
    var Widget = require('web.Widget');
    var AbstractAction = require('web.AbstractAction');

    var QWeb = core.qweb;
    var _t = core._t;

    var BatchTimesheet = AbstractAction.extend({
        hasControlPanel: true,
        events: {
            'click .o_gantt_button_scale': '_on_click_button_scale',
            'click .o_gantt_button_swap': '_on_click_button_swap',
            'click .save_draft_timesheet': '_on_click_save_draft_timesheet',
        },
        init: function (parent, context) {
            this._super.apply(this, arguments);
            this.allowedScales = ["day", "week", "month"];
            this.activateScale = 'month';
            this.activateSwap = 'today';
            this.active_batch_id = context.context.timesheet_batch_id
            this.timesheet_start_date = context.context.timesheet_start_date
            this.timesheet_end_date = context.context.timesheet_end_date
            this.update_draft_timesheet = {};
        },
        willStart: function() {
            return Promise.all([this, this._getHtml(), this._super()]);
        },
        start: function() {
            var self = this;
            this.updateControlPanel({
                cp_content: this._renderComponent()
            });
            this._super.apply(this, arguments);
            setTimeout(function() {
                self.$('.o_content').html(self.reportHtml);
                self.$el.addClass('o_view_controller');
                self._controlPanel.$el.find('div.o_control_panel > div.upr-row-cp > ol.breadcrumb').addClass('estimation-breadcrumb');
                self._controlPanel.$el.find('div.o_control_panel > div.upr-row-cp > div.o_cp_left').addClass('o_est_cp_left');
                self._controlPanel.$el.find('div.o_control_panel > div.upr-row-cp').addClass('o_est_up_row');
                self._controlPanel.$el.find('div.o_cp_left').addClass('o_cp_left_timesheet');
                self._controlPanel.$el.find('div.o_cp_buttons').addClass('o_cp_buttons_timesheet');
            }, 500);
            this._set_table_events();
        },
        _getHtml: function() {
            var self = this;
            return this._rpc({
                model: 'report.ils_ui.report_timesheet',
                method: 'get_html',
                kwargs: {
                    'active_scale': this.activateScale,
                    'activateSwap': this.activateSwap,
                    'active_batch_id': this.active_batch_id,
                    'timesheet_start_date': this.timesheet_start_date,
                    'timesheet_end_date': this.timesheet_end_date,
                    'current_date': this.current_date,
                },
            }).then(result => {
                this.current_date = result[0];
                this.reportHtml = result[1];
            });
        },
        _reload: function() {
            var self = this;
            this._getHtml();
            setTimeout(function() {
                return self.$('.o_content').html(self.reportHtml);
            }, 500);
            this._set_table_events();
        },
        _renderComponent: function() {
            const $buttons = $(QWeb.render("BatchTimesheetHeader", {'widget': this}));
            return {
                $buttons,
            };
        },
        _set_table_events: function() {
            var self = this;
            setTimeout(function(){
                $(document).find('.table-event').on("dragstart", function (event) {
                    var dt = event.originalEvent.dataTransfer;
                    dt.setData('id', $(this).attr('id'));
                    dt.setData('batch_group_id', $(this).attr('batch-group'));
                    // dt.setData('timetable_id', $(this).attr('timetable_id'));
                });
                $(document).find('table td.td-drop-event').on("dragenter dragover drop", function (event) {
                    event.preventDefault();
                    if (event.type === 'drop') {
                        var event_element = $(this);
                        var data_id = event.originalEvent.dataTransfer.getData('id',$(this).attr('id'));
                        var batch_group_id = event.originalEvent.dataTransfer.getData('batch_group_id',$(this).attr('batch_group_id'));
                        var change_date = $(this).data('td-date');
                        var change_time_index = $(this).data('td-timeindex');
                        var change_time = $(this).data('td-time');
                        // var timetable_id = $(this).data('timetable-id');

                        self._rpc({
                            model: 'ils.timetable.line',
                            method: 'change_draft_timetable',
                            kwargs: {
                                'line_id': data_id,
                                'change_date': change_date,
                                'change_time_index': change_time_index,
                                'change_time': change_time,
                                'batch_group_id': batch_group_id,
                                'update_draft_timesheet': self.update_draft_timesheet,
                            },
                        }).then(result => {
                            if (result){
                                self.update_draft_timesheet = result;
                                if(event_element.find('span').length===0){
                                    var de=$('#'+data_id).detach();
                                    de.appendTo(event_element);
                                }
                            } else {
                                alert(_t('This batch not allowed in this time slot!'));
                            }
                        });

                    };
                });
            },2000);
        },
        _on_click_button_scale: function (ev) {
            ev.preventDefault();
            var $this = this;
            var $button = $(ev.currentTarget);
            $('.o_gantt_button_scale.active').removeClass('active');
            $button.addClass('active');
            this.activateScale = $button.data('value');
            setTimeout(function() {
                $this._reload();
            }, 1000);
        },
        _on_click_button_swap: function (ev) {
            ev.preventDefault();
            var $this = this;
            var $button = $(ev.currentTarget);
            $('.o_gantt_button_scale.active').removeClass('active');
            $button.addClass('active');
            this.activateSwap = $button.data('value');
            setTimeout(function() {
                $this._reload();
            }, 1000);
        },
        _on_click_save_draft_timesheet: function (ev) {
            var $this = this;
            $this._rpc({
                model: 'ils.timetable.line',
                method: 'save_final_timesheet',
                kwargs: {
                    'update_draft_timesheet': $this.update_draft_timesheet,
                },
            }).then(result => {
                alert(_t(result))
            });
        },
    });

    core.action_registry.add('timesheet.gantt_view', BatchTimesheet);
    return BatchTimesheet;
});