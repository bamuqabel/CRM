# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
import math

class Modules(models.Model):
    _name = 'ils.modules'
    _description = 'Modules'

    name = fields.Char(string='Course Name', required=True)
    arabic_name = fields.Char(string='Arabic Name', required=True)
    code = fields.Char(string='Course Code', required=True)
    lesson_duration = fields.Integer(string='Duration of Lesson')
    no_of_hours = fields.Integer(string='No. of Hours')
    no_of_weeks = fields.Integer(string='No. of Weeks in One Semester')
    semester_ids = fields.Many2many(comodel_name='ils.semester')
    enrolled_student_ids = fields.One2many(comodel_name='ils.enrollment', inverse_name='module_id')
    program_ids = fields.Many2many('product.template', 'module_program_rel', 'module_id', 'program_id')
    module_room_ids = fields.One2many('ils.module.room', 'module_id', string="Rooms and Capacity")
    module_type = fields.Selection(string='Module Type', selection=[
        ('specific', 'Specific'),
        ('commo', 'Commo'),],
        default='specific')
    specific_room = fields.Boolean(string='Required Specific Room')
    priority = fields.Selection(string='Priority', selection=[
        ('module_limit', 'Module Limit'),
        ('room_limit', 'Room Limit'),],
        default='module_limit')
    # learing_levels = fields.Selection(string='Learing Levels', selection=[
    #     ('intermediate', 'Intermediate'),
    #     ('advanced', 'Advanced'),],
    #     default='intermediate')
    # balance = fields.Float(string='Blance')
    # prerequisites = fields.Boolean(string='Prerequisites')
    batch_ids = fields.One2many(comodel_name='ils.batch', inverse_name='module_id')
    enrollment_student_group_ids = fields.One2many(comodel_name='ils.enrollment.student.group', inverse_name='module_id', string="Enrollment Groups")
    teacher_ids = fields.Many2many('ils.teacher', 'module_teacher_rel', 'module_id', 'teacher_id')
    no_of_lessons = fields.Float(string="No. of Lesson")
    module_level = fields.Selection(string='Module Level', selection=[
        ('practical', 'Practical'),
        ('basic', 'Basic'),
        ('advance', 'Advance')])
    is_practical = fields.Boolean(string="Is Practical", default=False)
    related_module = fields.Many2one('ils.modules', string="Related module?")
    credit_hours = fields.Float('Credit Hours')

    @api.depends('name', 'code')
    def name_get(self):
        res = []
        for rec in self:
            name = '[%s]%s' % (rec.code, rec.name)
            res += [(rec.id, name)]
        return res

    @api.onchange('module_level')
    def onchange_module_level(self):
        for record in self:
            if record.module_level and record.module_level == 'practical':
                record.is_practical = True
            else:
                record.is_practical = False

    @api.onchange('lesson_duration')
    def onchange_lesson_duration(self):
        for record in self:
            if record.lesson_duration:
                # hours = record.lesson_duration / 60
                # decimal_no = hours - int(hours)
                # if decimal_no not in [0.0, 0.5]:
                #     record.lesson_duration = False
                if isinstance(record.lesson_duration, float):
                    raise UserError(_("Incorrect time! It should be full hour or full and half hour."))
                elif record.lesson_duration and record.no_of_hours:
                    lesson_hours = record.lesson_duration / 60
                    no_of_lessons = record.no_of_hours / lesson_hours
                    decimal_no = no_of_lessons - int(no_of_lessons)
                    record.no_of_lessons = math.ceil(no_of_lessons)

    @api.onchange('no_of_hours')
    def onchange_no_of_hours(self):
        for record in self:
            if record.lesson_duration and record.no_of_hours:
                lesson_hours = record.lesson_duration / 60
                no_of_lessons = record.no_of_hours / lesson_hours
                decimal_no = no_of_lessons - int(no_of_lessons)
                record.no_of_lessons = math.ceil(no_of_lessons)

    @api.onchange('program_ids')
    def onchange_program_ids(self):
        for record in self:
            if not record.module_type:
                raise UserError(_("Please add Module Type first!"))
            elif record.module_type and record.module_type == 'specific' and len(record.program_ids) > 1:
                raise UserError(_("You can only add only one program, as it is a specific module!"))
            else:
                for program in record.program_ids:
                    program.write({
                        'module_ids': [(4, record.id)]
                        })

    @api.model
    def create(self, vals):
        res = super(Modules, self).create(vals)
        if res.semester_ids:
            program_list = []
            for sem in res.semester_ids:
                if sem.program_id.id not in program_list:
                    program_list.append(sem.program_id.id)
            res.program_ids = [(6, 0, program_list)]
        if res.program_ids:
            for program in res.program_ids:
                program.write({
                    'module_ids': [(4, res.id)]
                    })
        if res.teacher_ids:
            for teacher in res.teacher_ids:
                teacher.write({
                    'module_ids': [(4, res.id)]
                    })
        return res

    def write(self, vals):
        # old_semester_ids = self.semester_ids.ids
        res = super(Modules, self).write(vals)
        for module in self:
            if vals and vals.get('semester_ids'):
                program_list = []
                for sem in self.semester_ids:
                    if sem.program_id.id not in program_list:
                        program_list.append(sem.program_id.id)
                module.program_ids = [(6, 0, program_list)]
            if vals and vals.get('program_ids'):
                sql_query = """DELETE
                                FROM program_module_rel
                                WHERE module_id = """ + str(module.id) + """
                                """
                self.env.cr.execute(sql_query)
                for program in module.program_ids:
                    program.write({
                        'module_ids': [(4, module.id)]
                        })
            if vals and vals.get('teacher_ids'):
                sql_query = """DELETE
                                FROM teacher_module_rel
                                WHERE module_id = """ + str(module.id) + """
                                """
                self.env.cr.execute(sql_query)
                for teacher in module.teacher_ids:
                    teacher.write({
                        'module_ids': [(4, module.id)]
                        })
        return res

    def get_timsheet_room_gap(self, module_id=False, room_id=False):
        if module_id and room_id:
            module_room_id = self.env['ils.module.room'].search([
                ('module_id', '=', module_id.id),
                ('room_id', '=', room_id.id)])
            if module_room_id:
                return module_room_id[0].gap_between_class
        return False