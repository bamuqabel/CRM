# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Education(models.Model):
    _name = 'ils.education'
    _description = 'Education'

    school = fields.Many2one(comodel_name='ils.school', string='School, Institution and State or Country')
    year = fields.Integer(string='Year Completed (YYYY)')
    result = fields.Float(string='Result')
    qualification = fields.Many2one(comodel_name='ils.qualification', string='Qualification Obtained')
    ouo = fields.Char(string='Office use only')
    attachment = fields.Binary(string='Attachment')
    student_id = fields.Many2one(comodel_name='res.partner', string='Student', domain="([('contact_type', '=', 'student')])")


class IlsSchool(models.Model):
    _name = 'ils.school'
    _description = 'School'

    name = fields.Char(string='Name')


class IlsQualification(models.Model):
    _name = 'ils.qualification'
    _description = 'Qualification'

    name = fields.Char(string='Name')