# -*- coding: utf-8 -*-

from odoo import models, fields, api

class EnrollmentStudentSemester(models.Model):
    _name = 'ils.enrollment.student.semester'
    _description = 'Enrollment Student Semester'

    result = fields.Selection(string='Result', selection=[
        ('pass', 'Pass'),
        ('fail', 'Fail')])
    batch_id = fields.Many2one('ils.batch')
    semester_id = fields.Many2one('ils.semester')
    student_enrollment_id = fields.Many2one('ils.enrollment')
    module_id = fields.Many2one('ils.modules', String="Module")