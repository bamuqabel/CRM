# -*- encoding: utf-8 -*-

from odoo import models, api, _
from odoo.exceptions import Warning

class StockPicking(models.Model):
    _inherit = 'stock.picking'
    current_user = fields.Many2one('res.users', compute='_get_current_user')
    
    @api.depends()
    def _get_current_user(self):
        for rec in self:
            rec.current_user = self.env.user
        # i think this work too so you don't have to loop
        self.update({'current_user' : self.env.user.id})