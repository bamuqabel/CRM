# -*- encoding: utf-8 -*-

{
    'name': "Transfer Validation Permission",
    'version': "13",
    'author': "ILS",
    'website': "http://www.ils.com.sa",
    'category': "Stock",
    'license': 'OPL-1',
    'summary': """
    Give a special permission to validate a transfer per transfer type.
    """,
    'description': """
        Give a special permission to validate a transfer per transfer type.
    """,
    'depends': ['stock'],
    'installable': True,
    'auto_install': False,
    'application': True,
}
