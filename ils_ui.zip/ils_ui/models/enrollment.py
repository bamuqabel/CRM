# -*- coding: utf-8 -*-

from odoo import models, fields, api

class EnrollmentProgram(models.Model):
    _name = 'ils.enrollment'

    name = fields.Char()
    student_id = fields.Many2one(comodel_name='res.partner', string='Student', domain="([('contact_type', '=', 'student')])")
    sponsor_id = fields.Many2one(comodel_name='res.partner', string='Sponsor', domain="([('contact_type', '=', 'sponsor')])")
    program_id = fields.Many2one(comodel_name='product.template', string='Program', domain="([('is_program', '=', True)])")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    batch_id = fields.Many2one(comodel_name='ils.batch', string='Batch')
    score = fields.Float(string='Assessment Score')
    url = fields.Char(string='URL (PDF)')
    state = fields.Selection(string='Status', selection=[
        ('new', 'NEW'),
        ('send_to_lms', 'SEND TO LMS'),
        ('sent_to_lms', 'SENT TO LMS'),
        ('enrolled', 'ENROLLED'),
        ('inactive', 'INACTIVE'),
        ('archived', 'ARCHIVED')],
        # readonly=True,
        default='new')

    @api.onchange('sponsor_id')
    def sponsor_send_to_lms(self):
        for record in self:
            if record.sponsor_id and record.academy_id:
                self.write({
                    'state': 'send_to_lms',
                })
    
    @api.onchange('academy_id')
    def academy_send_to_lms(self):
        for record in self:
            if record.sponsor_id and record.academy_id:
                self.write({
                    'state': 'send_to_lms',
                })
