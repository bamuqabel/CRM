# -*- coding: utf-8 -*-

from odoo import models, fields, api

class EnrollmentProgram(models.Model):
    _name = 'ils.enrollment'
    _description = 'Enrollment Program'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name')
    student_id = fields.Many2one(comodel_name='res.partner', string='Student', domain="([('contact_type', '=', 'student')])")
    sponsor_id = fields.Many2one(comodel_name='res.partner', string='Sponsor', domain="([('contact_type', '=', 'sponsor')])")
    program_id = fields.Many2one(comodel_name='product.template', string='Program', domain="([('is_program', '=', True)])")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    score = fields.Float(string='Assessment Score')
    url = fields.Char(string='URL (PDF)')
    module_id = fields.Many2one(comodel_name='ils.modules')
    state = fields.Selection(string='Status', selection=[
        ('new', 'NEW'),
        ('send_to_lms', 'SEND TO LMS'),
        ('sent_to_lms', 'SENT TO LMS'),
        ('enrolled', 'ENROLLED'),
        ('inactive', 'INACTIVE'),
        ('archived', 'ARCHIVED')],
        default='new')
    enroll_student_ids = fields.Many2many('ils.enrollment.student.group', 'enrollment_group_rel', 'enrollment_id', 'group_id')

    def write(self, vals):
        if  vals and vals.get('enroll_student_ids'):
            before_enroll_student_ids = self.enroll_student_ids.ids
            res = super(EnrollmentProgram, self).write(vals)
            after_enroll_student_ids = self.enroll_student_ids.ids
            removed_enrollments = list(set(before_enroll_student_ids) - set(after_enroll_student_ids))
            if removed_enrollments:
                for group in self.env['ils.enrollment.student.group'].browse(removed_enrollments):
                    sql_query = """DELETE
                                FROM enrollment_student_group_rel
                                WHERE group_id = """ + str(group.id) + """
                                AND enrollment_id = """ + str(self.id) + """
                                """
                    self.env.cr.execute(sql_query)
        else:
            res = super(EnrollmentProgram, self).write(vals)
        return res

    @api.onchange('sponsor_id')
    def sponsor_send_to_lms(self):
        for record in self:
            if record.sponsor_id and record.academy_id:
                self.write({
                    'state': 'send_to_lms',
                })
    
    @api.onchange('academy_id')
    def academy_send_to_lms(self):
        for record in self:
            if record.sponsor_id and record.academy_id:
                self.write({
                    'state': 'send_to_lms',
                })