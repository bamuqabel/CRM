# -*- coding: utf-8 -*-

from odoo import models, fields, api

class AdmissionChecklist(models.Model):
    _name = 'ils.admission.checklist'
    _rec_name = 'doc'

    doc = fields.Text(string='Document')
    requirement = fields.Text(string='Requirement')
    status = fields.Boolean(string='Status', default=False)
    comments = fields.Text(string='Comments')
    attachment = fields.Binary(string='Attachment')

    student_id = fields.Many2one(comodel_name='res.partner', string='Student', domain="([('contact_type', '=', 'student')])")


class AdmissionChecklistStatic(models.Model):
    _name = 'ils.admission.checklist.static'
    _rec_name = 'doc'

    doc = fields.Text(string='Document')
    requirement = fields.Text(string='Requirement')
    status = fields.Boolean(string='Status', default=False)
    comments = fields.Text(string='Comments')
    attachment = fields.Binary(string='Attachment')
