# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ilsProgram(models.Model):
    _inherit = 'product.template'

    duration = fields.Integer(string='Program Duration in Months')
    quantity = fields.Integer(string='Program Session Quantity')
    lms = fields.Selection(string='LMS', selection=[('bunyan','Bunyan LMS'), ('ehl','Vet By EHL'), ('upm','UPM')])
    is_program = fields.Boolean(string='Is Program')
    extranl_pro_id = fields.Char(string='Extranl Program ID')

    batches = fields.One2many(comodel_name='ils.batch', inverse_name='program', string='Batches')