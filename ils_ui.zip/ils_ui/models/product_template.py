# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ilsProgram(models.Model):
    _inherit = 'product.template'

    arabic_name = fields.Char(string='Arabic Name', required=True)
    duration = fields.Integer(string='Program Duration in Months', required=True)
    quantity = fields.Integer(string='Program Session Quantity', required=True, compute='_compute_program_sessions')
    lms = fields.Selection(string='LMS', required=True, selection=[('bunyan','Bunyan LMS'), ('ehl','Vet By EHL'), ('upm','UPM')])
    is_program = fields.Boolean(string='Is Program')
    extranl_pro_id = fields.Char(string='Extranl Program ID')
    batches = fields.One2many(comodel_name='ils.batch', inverse_name='program_id', string='Batches')
    module_ids = fields.Many2many('ils.modules', 'program_module_rel', 'program_id', 'module_id')

    def _compute_program_sessions(self):
        for record in self:
            no_of_sessions = 0
            for module in record.module_ids:
                no_of_sessions += module.no_of_lessons
            record.quantity = no_of_sessions