# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ilsAcademy(models.Model):
    _name = 'ils.academy'

    name = fields.Char()
    country_id = fields.Many2one(comodel_name='res.country')
    resion_id = fields.Many2one(comodel_name='academy.resion', string='Academy Region', domain="([('country_id', '=', country_id)])")
    city_id = fields.Many2one(comodel_name='academy.city', string='Academy City', domain="([('resion_id', '=', resion_id)])") 
    phone = fields.Char(string='Academy Phone Number')
    email =  fields.Char(string='Academy Email')
    responsible = fields.Many2one(comodel_name='res.partner')
    
    batches = fields.One2many(comodel_name='ils.batch', inverse_name='academy_id', string='Batches')

    # @api.onchange('city_id')
    # def city_change(self):
    #     for record in self:
    #         if record.city_id:
    #             self.name = record.city_id.name + " " + "Academy"

class AcademyCity(models.Model):
    _name = 'academy.city'

    name = fields.Char(string='Name')
    resion_id = fields.Many2one(comodel_name='academy.resion', string='Resion')

class AcademyResion(models.Model):
    _name = 'academy.resion'

    name = fields.Char(string='Name')
    country_id = fields.Many2one(comodel_name='res.country', string='Countery')
    
