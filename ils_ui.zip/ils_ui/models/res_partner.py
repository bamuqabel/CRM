# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ResPartnerInhert(models.Model):
    _inherit = 'res.partner'

    contact_type = fields.Selection(selection=[('student','Student'),('sponsor','Sponsor')], string='Contact Type')
    
    first_name = fields.Char(string='First Name')
    father_name = fields.Char(string='Father Name')
    family_name = fields.Char(string='Family Name')
    student_id = fields.Integer(string='Student ID')
    id_num = fields.Integer(string='ID Number', required=True, default=0)
    passport = fields.Char(string='Passport Number')
    dob = fields.Date(string='Date of Birth')
    gender = fields.Selection(selection=[('male','Male'),('female','Female')], string='Gender')
    high_school_gpa = fields.Float(string='High School GPA', required=True, default=0.00)
    attach = fields.Binary(string='Attachments')

    education = fields.One2many(comodel_name='ils.education', inverse_name='student_id', string='Education')
    employment = fields.One2many(comodel_name='ils.employment', inverse_name='student_id', string='Employment')
    admission_checklist = fields.One2many(comodel_name='ils.admission.checklist', inverse_name='student_id', string='Admission Checklist')
    
    min_num_of_student = fields.Integer(string='Minmum Number of Student')
    invoice_date = fields.Integer(string='Invoicing Date', size=2)

    enrollment_count = fields.Integer(string='Enrollments', compute='_compute_enroll_count')
    enrollment_student_count = fields.Integer(string='Student Enrollments', compute='_compute_enrollment_student_count')

    @api.onchange('first_name')
    def first_name_change(self):
        for record in self:
            if record.first_name and self.father_name and self.family_name:
                self.name = record.first_name + " " + self.father_name + " " + self.family_name
            else:
                self.name = record.first_name

    @api.onchange('father_name')
    def father_name_change(self):
        for record in self:
            if record.father_name and self.first_name and self.family_name:
                self.name = self.first_name + " " + record.father_name + " " + self.family_name
            elif record.father_name and self.first_name:
                self.name = self.first_name + " " + record.father_name

    @api.onchange('family_name')
    def family_name_change(self):
        for record in self:
            if record.family_name and self.first_name and self.first_name:
                self.name = self.first_name + " " + self.father_name + " " + record.family_name

    def _compute_enroll_count(self):
        for record in self:
            record.enrollment_count = self.env['ils.enrollment'].search_count(
                [('student_id', '=', record.id)])

    def _compute_enrollment_student_count(self):
        for record in self:
            record.enrollment_student_count = self.env['ils.enrollment'].search_count(
                [('sponsor_id', '=', record.id)])

    @api.constrains('invoice_date')
    def check_invoice_date(self):
        for record in self:
            if record.invoice_date > 31:
                raise ValidationError('Invoicing Date Can Not > 31')

    
    # get value for admission_checklist
    @api.model
    def default_get(self, fields):
        res = super(ResPartnerInhert, self).default_get(fields)
        a_checklist_lines = [(5,0,0)]
        a_checklist_rec = self.env['ils.admission.checklist.static'].search([])
        for a_checklist in a_checklist_rec:
            line = (0, 0, {
                'doc': a_checklist.doc,
                'requirement': a_checklist.requirement,
                'status': a_checklist.status,
                'comments': a_checklist.comments,
                'attachment': a_checklist.attachment,
            })
            a_checklist_lines.append(line)
            res.update({
                'admission_checklist': a_checklist_lines
            })
        return res