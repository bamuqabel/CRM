from odoo import models, fields, api

class ilsPatch(models.Model):
    _name = 'ils.batch'

    name = fields.Char()
    program = fields.Many2one(comodel_name='product.template', string='Program', domain="([('is_program', '=', True)])")
    academy_id = fields.Many2one(comodel_name='ils.academy', string='Academy')
    s_date =  fields.Date(string='Start Date')
    e_date =  fields.Date(string='End Date')

    enrollments = fields.One2many(comodel_name='ils.enrollment', inverse_name='batch_id', string='Enrollments')