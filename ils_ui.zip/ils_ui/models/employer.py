# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Employer(models.Model):
    _name = 'ils.employer'
    _description = 'Employer'

    name = fields.Char(string='Name')
