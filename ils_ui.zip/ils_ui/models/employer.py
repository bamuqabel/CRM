# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Employer(models.Model):
    _name = 'ils.employer'

    name = fields.Char(string='Name')
