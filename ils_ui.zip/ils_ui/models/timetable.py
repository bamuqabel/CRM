# -*- coding: utf-8 -*-

from odoo import models, fields, api
import datetime

class ilsTimeTable(models.Model):
    _name = 'ils.timetable'
    _description = 'Time Table'

    name = fields.Char(readonly=True)
    date = fields.Date(string='Date', required=True)
    timetable_line_ids = fields.One2many(comodel_name='ils.timetable.line', inverse_name='timetable_id')
    batch_id = fields.Many2one(comodel_name='ils.batch')
    week_day = fields.Selection(string='Week Day', selection=[
        ('sunday', 'Sunday'),
        ('monday', 'Monday'),
        ('tuesday', 'Tuesday'),
        ('wednesday', 'Wednesday'),
        ('thursday', 'Thursday'),
        ('friday', 'Friday'),
        ('saturday', 'Saturday'),
        ])
    state = fields.Selection(string='Status', selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ], default='draft')
    descripton = fields.Char()

    @api.depends('date')
    def name_get(self):
        res = []
        for rec in self:
            rec.name = 'TimeTable (%s)' % (rec.date)
            res += [(rec.id, rec.name)]
        return res


class ilsTimeTableLine(models.Model):
    _name = 'ils.timetable.line'
    _description = 'Time Table Line'

    timetable_id = fields.Many2one(comodel_name='ils.timetable')
    module_id = fields.Many2one(comodel_name='ils.modules')
    batch_id = fields.Many2one(comodel_name='ils.batch')
    batch_group_id = fields.Many2one(comodel_name='ils.enrollment.student.group', string="Batch Group")
    room_id = fields.Many2one('ils.room')
    batch_time = fields.Char(string="Batch Time")
    time_index = fields.Char(string="Time Index")
    descripton = fields.Char(string="Description")
    date = fields.Date(string='Date', required=True)
    teacher_ids = fields.Many2many('ils.teacher', 'teacher_timetable_rel', 'time_line_id', 'teacher_id')

    @api.model
    def change_draft_timetable(self, line_id=False, change_date=False, change_time_index=False, change_time=False, batch_group_id=False, update_draft_timesheet=False):
        timetable_line_obj =  self.env['ils.timetable.line']
        academy_dayoff_obj = self.env['ils.academy.dayoff']

        if line_id and batch_group_id and change_date and change_time_index:
            batch_group = self.env['ils.enrollment.student.group'].browse(int(batch_group_id))
            academy_id = batch_group.batch_id.academy_id
            start_date = datetime.datetime.strptime(change_date , '%Y-%m-%d')
            academy_day_off_id = academy_dayoff_obj.search([('day_off_date', '=', start_date), ('academy_id', '=', academy_id.id)])

            if start_date.strftime("%A").lower() != 'sunday' and not academy_day_off_id:
                # check related theory module index in same date
                check_related_module = timetable_line_obj.search([
                    ('module_id', '=', batch_group.module_id.related_module.id),
                    ('date', '=', start_date),
                    ('time_index', '=', change_time_index - 1)])
                if check_related_module:
                    return False

                # available room condition
                check_room_available = timetable_line_obj.search([
                    ('room_id', '=', batch_group.room_id.id),
                    ('time_index', '=', change_time_index),
                    ('date', '=', start_date)])
                if check_room_available:
                    return False

                # teacher available condition
                assign_teacher_ids = []
                for teacher in  batch_group.teacher_ids:
                    teacher_working_hours = teacher.no_of_hours
                    check_teacher_available = timetable_line_obj.search([
                        ('teacher_ids', 'in', [teacher.id]),
                        ('date', '=', start_date)])
                    if len(check_teacher_available) < int(teacher_working_hours):
                        assign_teacher_ids.append(teacher.id)
                if assign_teacher_ids:
                    assign_teacher_ids = [ (4, teacher_id) for teacher_id in assign_teacher_ids ]
                else:
                    return False

                if update_draft_timesheet:
                    if update_draft_timesheet.get(line_id):
                        update_draft_timesheet.get(line_id).update({
                            'date': start_date,
                            'batch_group_id': batch_group.id,
                            'time_index': change_time_index,
                            'batch_time': change_time})
                    else:
                        update_draft_timesheet.update({line_id : {
                        'date': start_date,
                        'batch_group_id': batch_group.id,
                        'time_index': change_time_index,
                        'batch_time': change_time}})
                    return update_draft_timesheet
                else:
                    return {line_id : {
                        'date': start_date,
                        'batch_group_id': batch_group.id,
                        'time_index': change_time_index,
                        'batch_time': change_time}}
            else:
                return False
        else:
            return False

    @api.model
    def save_final_timesheet(self, update_draft_timesheet=False):
        timetable_line_obj =  self.env['ils.timetable.line']
        timetable_obj =  self.env['ils.timetable']
        batch_group_obj = self.env['ils.enrollment.student.group']
        if update_draft_timesheet:
            batch_group = False
            for line_id in update_draft_timesheet:
                line_dict = update_draft_timesheet.get(line_id)
                timetable_line = timetable_line_obj.browse(int(line_id))
                start_date = datetime.datetime.strptime(str(line_dict.get('date')), '%Y-%m-%d %H:%M:%S')
                batch_group = batch_group_obj.browse(int(line_dict.get('batch_group_id')))
                timetable = timetable_obj.search([('date', '=', start_date.date()), ('batch_id', '=', batch_group.batch_id.id)])
                if timetable:
                    timetable_line.write({
                        'timetable_id': timetable.id,
                        'date': start_date.date(),
                        'batch_time': line_dict.get('batch_time'),
                        'time_index': int(line_dict.get('time_index')),
                        })
            # update all Timetable status to Saved
            if batch_group:
                batch_group.batch_id.timesheet_saved = True
            batch_timetables = timetable_obj.search([('batch_id', '=', batch_group.batch_id.id)])
            if batch_timetables:
                batch_timetables.write({'state': 'confirm'})
            return "Timesheet saved!"
        else:
            return "Timesheet not saved!"