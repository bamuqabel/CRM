# -*- coding: utf-8 -*-

from odoo import models, fields, _
import requests
from requests.auth import HTTPBasicAuth
from odoo.exceptions import UserError
from odoo.tools import ustr


class ApiConfiguration(models.Model):
    _name = 'ils.api.configuration'
    _description = 'Api Configuration'


    name = fields.Char(String="Name")
    url = fields.Char(String="Url")
    username = fields.Char(String="Username")
    password = fields.Char(String="Password")
    model_ids = fields.Many2many('ir.model', String="Objects", domain=[('model','=like','ils%')])


    def test_api_connection(self):
        token = False
        if 'auth' in self.url:
            try:
                header = {'content-type': 'application/json'}
                response = requests.request("POST",
                                            str(self.url), 
                                            auth=HTTPBasicAuth(self.username, self.password),
                                            headers=header, verify=False)
                token = response.json()["Token"] or False
            except Exception as e:
                raise UserError(_("API Connection Test Failed! Here is the error:\n%s") % ustr(e))
        try:
            if token:
                headers = {'content-type': 'application/json', 'x-auth-token': token}
            else:
                headers = {'content-type': 'application/json'}
            response = requests.get(self.url, headers=headers, verify=False)
            if response.status_code != 200:
                raise UserError(_("Did not received proper response."))
        except Exception as e:
            raise UserError(_("API Connection Test Failed! Here is the error:\n%s") % ustr(e))

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("API Connection Test Succeeded!"),
                'message': _("Everything seems properly set up!"),
                'sticky': False,
            }
        }