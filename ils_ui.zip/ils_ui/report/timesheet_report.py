
import datetime
import calendar
from datetime import timedelta, date
from odoo import api, models


class report_batch_timesheet(models.AbstractModel):
    _name = 'report.ils_ui.report_timesheet'
    _description = 'Batch Timesheet Report'

    def daterange(self, start_date, end_date):
        for n in range(int((end_date - start_date).days) + 1):
            yield start_date + timedelta(n)

    @api.model
    def get_html(self, active_scale=None, activateSwap=None, active_batch_id=None, timesheet_start_date=None, timesheet_end_date=None, current_date=None):
        ils_batch_obj = self.env['ils.batch']
        ils_acedamy_obj = self.env['ils.academy.timeslot']
        ils_module_obj = self.env['ils.modules']
        start_date = False
        end_date = False
        day_off_list = []
        time_table_data = {
            'active_scale': active_scale,
            'date_range': False,
            'date_slot': [],
            'timeslot': [],
            'time_slot_data': [],
            'day_off_list':[]}

        selected_date_range = []
        timesheet_start_date = datetime.datetime.strptime(timesheet_start_date, '%Y-%m-%d') if timesheet_start_date else False
        timesheet_end_date = datetime.datetime.strptime(timesheet_end_date, '%Y-%m-%d') if timesheet_end_date else False
        for date in self.daterange(timesheet_start_date, timesheet_end_date):
            selected_date_range.append(date.date())

        if activateSwap == 'today':
            today = datetime.datetime.today().date()
        elif current_date and activateSwap != 'today':
            today = datetime.datetime.strptime(current_date, "%Y-%m-%d")
            # count days dependes on active_scale
            if active_scale == 'day':
                days = 1
            if active_scale == 'week':
                days = 7
            if active_scale == 'month':
                days = 28
            # generate active date
            if activateSwap == 'previous':
                today = today - datetime.timedelta(days=days)
            elif activateSwap == 'next':
                today = today + datetime.timedelta(days=days)

        if active_scale == 'day':
            time_table_data['date_range'] = datetime.datetime.strftime(today, "%d %B %Y")
            # set hours list
            for i in range(1,25):
                suffix = "am" if i < 12 else "pm"
                time_table_data.get('date_slot').append({
                    'start_date': datetime.datetime.strftime(today, "%Y-%m-%d"),
                    'display_date': (str(i) + " " + suffix)
                })
        elif active_scale == 'week':
            start_date = today - datetime.timedelta(days=today.weekday() + 1)
            end_date = start_date + datetime.timedelta(days=6)
            time_table_data['date_range'] = start_date.strftime("%d %B %Y") + " - " + end_date.strftime("%d %B %Y")
        elif active_scale == 'month':
            _, num_days = calendar.monthrange(today.year, today.month)
            start_date = datetime.date(today.year, today.month, 1)
            end_date = datetime.date(today.year, today.month, num_days)
            time_table_data['date_range'] = start_date.strftime("%B %Y")

        if active_scale in ['week', 'month']:
            for single_date in self.daterange(start_date, end_date):
                if active_scale == 'week':
                    day = int(single_date.strftime("%d"))
                    suffix = 'th' if 11 <= day <= 13 else {1:'st',2:'nd',3:'rd'}.get(day%10, 'th')
                    time_table_data.get('date_slot').append({
                        'start_date': datetime.datetime.strftime(single_date, "%Y-%m-%d"),
                        'display_date': (single_date.strftime("%A, %d") + suffix)
                    })
                elif active_scale == 'month':
                    time_table_data.get('date_slot').append({
                        'start_date': datetime.datetime.strftime(single_date, "%Y-%m-%d"),
                        'display_date': (single_date.strftime("%d"))
                    })
                else:
                    pass
                # check if date is sundays
                if single_date.strftime("%A").lower() == 'sunday':
                    day_off_list.append(datetime.datetime.strftime(single_date, "%Y-%m-%d"))

        batch_id = ils_batch_obj.browse(active_batch_id)
        timeslot = batch_id.get_timetable_timeslot()
        time_table_data['timeslot'] = timeslot

        # get off dates
        academy_id = batch_id.academy_id
        academy_day_offs = self.env['ils.academy.dayoff'].search([
            ('day_off_date', '>=', start_date),
            ('day_off_date', '<=', end_date),
            ('academy_id', '=', academy_id.id)]).mapped('day_off_date')
        for date in academy_day_offs:
            day_off_list.append(datetime.datetime.strftime(date, "%Y-%m-%d"))

        # updated on 25 feb 2021
        # holidays = self.env['hr.holidays.public.line'].search([
        #     ('date', '>=', start_date),
        #     ('date', '<=', end_date)]).mapped('date')
        # for date in holidays:
        #     day_off_list.append(datetime.datetime.strftime(date, "%Y-%m-%d"))

        if day_off_list:
            time_table_data.update({'day_off_list': day_off_list})

        time_table_batches = ils_batch_obj.get_table_data(active_batch_id, selected_date_range, time_table_data.get('date_slot'), timeslot)
        time_table_data['time_slot_data'] = time_table_batches

        html_data = self.env.ref('ils_ui.report_batch_timesheet').render({
            'time_table_data': time_table_data,
            'get_block_time_description': ils_acedamy_obj.get_block_time_description,
            'get_timsheet_room_gap': ils_module_obj.get_timsheet_room_gap})
        current_date = datetime.datetime.strftime(today, "%Y-%m-%d")
        return [current_date, html_data]