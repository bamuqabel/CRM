# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

import base64
from odoo import http, tools, _
from datetime import datetime
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.addons.website.controllers.main import QueryURL
from ast import literal_eval


class PortalAccount(CustomerPortal):

    def _prepare_portal_layout_values(self):
        domain = []
        values = super(PortalAccount, self)._prepare_portal_layout_values()
        if request.env.user.sudo().has_group('base.group_portal'):
             domain += [('user_id', '=', request.env.user.id)]
        if request.env.user.sudo().has_group('sync_ems.group_student'):
            domain += [('student_id.user_id', '=', request.env.user.id)]
        admission_count = request.env['admission.admission'].sudo().search_count(domain)
        values['admission_count'] = admission_count
        return values

    def _admission_get_page_view_values(self, admission, access_token, **kwargs):
        values = {
            'page_name': 'admission',
            'admission': admission,
        }
        return self._get_page_view_values(admission, access_token, values, False, False, **kwargs)

    @http.route(['/my/admissions/<int:admission_id>'], type='http', auth="user", website=True)
    def portal_my_admissions(self, admission_id=None, access_token=None, report_type=None, download=False, **kw):
        admission = request.env['admission.admission'].sudo()
        redirect = ("/my/admissions")
        try:
            admission_sudo = self._document_check_access('admission.admission', admission_id, access_token=access_token)
            values = self.get_values(admission_sudo)
        except Exception as e:
            return request.redirect("%s?error_e=%s" % (redirect, (tools.ustr(e))))

        values.update(self._admission_get_page_view_values(admission_sudo, access_token, **kw))
        post = values
        post['datepicker'] = 1

        return request.render("sync_ems_admission_website.apply4admission", post, {})

    @http.route(['/my/admissions', '/my/admissions/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_admissions_details(self, page=1, search=None, search_in='all', **kw):
        admissions = request.env['admission.admission'].sudo()
        domain = []
        if request.env.user.sudo().has_group('base.group_portal'):
            domain += [('user_id', '=', request.env.user.id)]
        if request.env.user.sudo().has_group('sync_ems.group_student'):
            domain += [('student_id.user_id', '=', request.env.user.id)]
        # searchbar_inputs = {
        #     'transport_type': {'input': 'transport_type', 'label': _('Search in Transport type')},
        #     'commodity': {'input': 'commodity', 'label': _('Search in Commodity')},
        #     'beneficiary': {'input': 'beneficiary', 'label': _('Search in Beneficiary')},
        #     'all': {'input': 'all', 'label': _('Search in All')},
        # }
        # searchbar_groupby = {
        #     'none': {'input': 'none', 'label': _('None')},
        #     # 'commodity': {'input': 'commodity', 'label': _('Commodity')},
        # }
        # partner = request.env.user.partner_id.id
        # domain = []

        # Claims count for pager
        # admission_count = admissions.search_count(domain)
        # make pager
        # pager = portal_pager(
        #     url="/my/admissions",
        #     total=admission_count,
        #     page=page,
        #     step=self._items_per_page
        # )
        # keep = QueryURL('/my/certificates', search=search)
        admission = admissions.sudo().search(domain)
        # if groupby == 'commodity':
        #     grouped_certificates = [InsurancePolicy.concat(*g) for k, g in groupbyelem(certificates, itemgetter('product_id'))]
        # else:
        grouped_admission = [admission]

        values = {
            'admissions': admissions,
            'page_name': 'admission',
            'grouped_admission': admission,
            'default_url': '/my/admissions',
            'currency': request.env.user.company_id.currency_id,
        }
        return request.render("sync_ems_admission_website.portal_my_admissions", values)

    def slicedict(self, d, s):
        return {k: v for k, v in d.items() if k.startswith(s)}

    def get_related_record(self):
        semester_ids = request.env['other.standard'].sudo().search_read([], ['id', 'name'])
        language_ids = request.env['student.language'].sudo().search_read([], ['id', 'name'])
        division_ids = request.env['other.division'].sudo().search_read([], ['id', 'name'])
        return {'semester_ids': semester_ids, 'language_ids': language_ids, 'division_ids': division_ids}

    def create_basic_info(self, post):
        post['is_user'] = False
        parent_detail, family_record, family_record = {}, [], []
        if post.get('birth_date'):
            post.update({'birth_date': datetime.strptime(post.get('birth_date'), '%d-%m-%Y')})
        if post.get('default_date'):
            post.pop('default_date')

        if post.get('if_other_f_edu'):
            f_education = request.env['education.education'].sudo().create({'name': post.pop('f__other_education')})
            post.update({'f_education': f_education.id})
            post.pop('if_other_f_edu')
        else:
            post.pop('f__other_education')
        if post.get('if_other_m_edu'):
            m_education = request.env['education.education'].sudo().search([('name', '=', post.get('m__other_education'))], limit=1)
            if m_education:
                post.update({'m_education': m_education.id})
            else:
                m_education = request.env['education.education'].sudo().create({'name': post.get('m__other_education')})
                post.update({'m_education': m_education.id})
            post.pop('if_other_m_edu')
            if post.get('m__other_education'):
                post.pop('m__other_education')
        else:
            post.pop('m__other_education')
        ufile = post.pop('ufile')
        if ufile:
            data = ufile.read()
            args = [len(data), ufile.filename,
                    ufile.content_type, base64.b64encode(data)]
            post.update({'photo': args[3]})
        vals = {'mobile': post.pop('father_mobile'),
                'name': post.get('middle_name'),
                'f_workplace': post.pop('f_place_work'),
                'email': post.get('f_email'),
                'father_id_no': post.get('f_id'),
                'function': post.pop('father_job'),
                'is_parent': True,
                'm_workplace': post.pop('m_place_work'),
                'm_job': post.pop('mother_job'),
                'm_email': post.pop('m_email'),
                'm_name': post.pop('m_name'),
                'm_mobile': post.pop('mother_mobile')}
        if post.get('f_id') and post.get('f_email'):
            user_id = request.env['res.users'].sudo().search([('login', '=', post.get('f_email'))], limit=1)
            parent_id = False
            if not user_id:
                parent_id = request.env['res.partner'].sudo().search([('is_parent', '=', True), ('father_id_no', '=', post.get('f_id')), ('email', '=', post.get('f_email'))], limit=1)
                post.pop('f_email')
                if not parent_id:
                    parent_id = request.env['res.partner'].sudo().create(vals)
                else:
                    parent_id.update(vals)
            else:
                user_id.partner_id.update(vals)
                parent_id = user_id.partner_id
                post.update({'is_user': True})
                post.pop('f_email')

            if parent_id:
                post.update({'middle_name': parent_id.id, 'email': parent_id.email, 'mobile': parent_id.mobile})
                if not post.get('admission'):
                    relation_id = request.env['student.relationship'].sudo().search([('name', '=', 'Father')], limit=1)
                    if not relation_id:
                        relation_id = request.env['student.relationship'].sudo().create({'name': 'Father'})
                    else:
                        family_record.append({'name': parent_id.name, 'parent_id': parent_id.id, 'relationship_id': relation_id.id})
                        if family_record:
                            post['parent_ids'] = [(0, 0, line) for line in family_record]
        post.update({
            'school_id': literal_eval(post.get('school_id')),
            'stage_id': literal_eval(post.get('stage_id')),
            'course_id': literal_eval(post.get('course_id')),
            'batch_id': literal_eval(post.get('batch_id')),
            'semester_id': literal_eval(post.get('semester_id')),
            })
        if post.get('religion_id'):
            post.update({'religion_id': literal_eval(post.get('religion_id'))})
        if post.get('total_fmember'):
            post.update({'total_fmember': literal_eval(post.get('total_fmember'))})
        if post.get('countrys_id'):
             post.update({'countrys_id': literal_eval(post.pop('countrys_id'))})
        if post.get('country_id'):
             post.update({'country_id': literal_eval(post.pop('country_id'))})
        if post.get('f_education'):
             post.update({'f_education': post.pop('f_education') or literal_eval(post.pop('f_education'))})
        if post.get('m_education'):
             post.update({'m_education': post.pop('m_education')})
        # Student User Creation
        return post

    def create_previous_record(self, post):
        previous_record, previous_academic_rec = [], {}
        previouse_name = self.slicedict(post, 'name_')
        prev_language_record = []
        for item in previouse_name.keys():
            rec = int(item.split('_')[1])
            if post.get('name_{}'.format(rec)):
                previous_academic_rec.update({'name': post.pop('name_{}'.format(rec))})
            if post.get('if_o_semester_{}'.format(rec)) == 'on':
                    semester_id = request.env['other.standard'].sudo().create({'name': post.pop('semester_name_{}'.format(rec))})
                    previous_academic_rec.update({'semester_id': semester_id.id})
                    post.pop('if_o_semester_{}'.format(rec))
            else:
                if post.get('semester_id_{}'.format(rec)):
                    previous_academic_rec.update({'semester_id': post.get('semester_id_{}'.format(rec))})
                    post.pop('semester_id_{}'.format(rec))
            if post.get('if_o_division_{}'.format(rec)) == 'on':
                    division_id = request.env['other.division'].sudo().create({'name': post.get('division_name_{}'.format(rec))})
                    post.pop('division_name_{}'.format(rec))
                    previous_academic_rec.update({'division_id': division_id.id})
                    post.pop('if_o_division_{}'.format(rec))
            else:
                if post.get('division_id_{}'.format(rec)):
                    previous_academic_rec.update({'division_id': post.get('division_id_{}'.format(rec))})
                    post.pop('division_id_{}'.format(rec))
            if post.get('start_date_{}'.format(rec)):
                previous_academic_rec.update({'start_date': post.pop('start_date_{}'.format(rec))})
            if post.get('end_date_{}'.format(rec)):
                previous_academic_rec.update({'end_date': post.pop('end_date_{}'.format(rec))})
            if previous_academic_rec:
                previous_academic_id = request.env['previous.academic.report'].sudo().create(previous_academic_rec)
                prev_language_record.append({'language': literal_eval(post.pop('language_id_{}'.format(rec))), 'academic_id': previous_academic_id.id})
                previous_record.append(previous_academic_id.id)
            if post.get('semester_id_{}'.format(rec)) == False or post.get('semester_id_{}'.format(rec)):
                post.pop('semester_id_{}'.format(rec))
            if post.get('division_id_{}'.format(rec)) == False or post.get('division_id_{}'.format(rec)):
                post.pop('division_id_{}'.format(rec))
            if post.get('division_name_{}'.format(rec)) == False or post.get('division_name_{}'.format(rec)):
                post.pop('division_name_{}'.format(rec))
            if post.get('semester_name_{}'.format(rec)) == False or post.get('semester_name_{}'.format(rec)):
                post.pop('semester_name_{}'.format(rec))
        if prev_language_record:
            post['prev_language_ids'] = [(0, 0, line) for line in prev_language_record]
        if previous_record:
            post['prev_academic_ids'] = [(4, line) for line in previous_record]
        return post

    def create_health_record(self, post):
        admission_id = None
        health_detail = {}
        if post.get('admission'):
            admission_id = request.env['admission.admission'].sudo().browse(int(post.get('admission')))
        if post.get('height'):
            health_detail.update({'height': post.pop('height')})
        else:
            post.pop('height')
        if post.get('weight'):
            health_detail.update({'weight': post.pop('weight')})
        else:
            post.pop('weight')
        if post.get('blood_group'):
            health_detail.update({'blood_group': post.pop('blood_group')})
        else:
            post.pop('blood_group')
        if post.get('diff_speak'):
            health_detail.update({'diff_speak': post.get('diff_speak')})
            if post.get('diff_speak') == 'on':
                health_detail.update({'diff_speak_note': post.pop('speaking_difficulty')})
            post.pop('diff_speak')
        else:
            health_detail.update({'diff_speak': False})
            if post.get('speaking_difficulty') or post.get('speaking_difficulty') == False:
                post.pop('speaking_difficulty')
        if post.get('diff_sight'):
            health_detail.update({'diff_sight': post.get('diff_sight')})
            if post.get('diff_sight') == 'on':
                health_detail.update({'diff_sight_note': post.pop('diff_sight_note')})
            post.pop('diff_sight')
        else:
            health_detail.update({'diff_sight': False})
            if post.get('diff_sight_note') or post.get('diff_sight_note') == False:
                post.pop('diff_sight_note')
        if post.get('diff_listening'):
            health_detail.update({'diff_listening': post.get('diff_listening')})
            if post.get('diff_listening') == 'on':
                health_detail.update({'diff_listening_note': post.pop('diff_listening_note')})
            post.pop('diff_listening')
        else:
            health_detail.update({'diff_listening': False})
            if post.get('diff_listening_note') or post.get('diff_listening_note') == False:
                post.pop('diff_listening_note')
        if post.get('other_difficulty'):
            health_detail.update({'other_difficulty': post.get('other_difficulty')})
            if post.get('other_difficulty') == 'on':
                health_detail.update({'other_difficulty_note': post.pop('other_difficulty_note')})
            post.pop('other_difficulty')
        else:
            health_detail.update({'other_difficulty': False})
            if post.get('other_difficulty_note') or post.get('other_difficulty_note') == False:
                post.pop('other_difficulty_note')
        if post.get('gn_health_status'):
            health_detail.update({'gn_health_status': post.get('gn_health_status')})
            if post.get('gn_health_status') == 'on':
                health_detail.update({'gn_health_status_note': post.pop('gn_health_status_note')})
            post.pop('gn_health_status')
        else:
            health_detail.update({'gn_health_status': False})
            if post.get('gn_health_status_note') or post.get('gn_health_status_note') == False:
                post.pop('gn_health_status_note')
        if post.get('physical_challenges'):
            health_detail.update({'physical_challenges': post.get('physical_challenges')})
            if post.get('physical_challenges') == 'on':
                health_detail.update({'physical_challenges_note': post.pop('physical_challenges_note')})
            post.pop('physical_challenges')
        else:
            health_detail.update({'physical_challenges': False})
            if post.get('physical_challenges_note') or post.get('physical_challenges_note') == False:
                post.pop('physical_challenges_note')
        if health_detail.get('height') and health_detail.get('weight') and health_detail.get('blood_group'):
            if admission_id:
                if admission_id.health_lines:
                    admission_id.health_lines.sudo().write(health_detail)
                else:
                    health_id = request.env['health.health'].sudo().create(health_detail)
                    if health_id:
                         post.update({'health_lines': [(4, health_id.id, False)]})
            else:
                health_id = request.env['health.health'].sudo().create(health_detail)
                if health_id:
                     post.update({'health_lines': [(4, health_id.id, False)]})
        return post

    def create_admission(self, post):
        parent_detail, previous_academic_rec = {}, {}
        if post:
            val = {}
            for k,v in post.items():
                if v == '':
                    val.update({k: False})
                else:
                    val.update({k: v})
            post = val
            post.update(self.create_basic_info(post))
            post.update(self.create_health_record(post))
            if post.get('state_id'):
                post.update({'state_id': literal_eval(post.get('state_id'))})
            if post.get('previous_academic_rec'):
                post.update(self.create_previous_record(post))
            post.pop('previous_academic_rec')
            post.pop('admission')
            return post

    def update_admission(self, post):
        previous_record = None
        admission_id = request.env['admission.admission'].sudo().browse(int(post.get('admission')))
        if admission_id and post:
            val = {}
            for k,v in post.items():
                if v == '':
                    val.update({k: False})
                else:
                    val.update({k: v})
            post = val
            if post.get('state_id'):
                post.update({'state_id': literal_eval(post.get('state_id'))})
            post.update(self.create_health_record(post))
            post.update(self.create_basic_info(post))
            if post.get('previous_academic_rec'):
                post.update(self.create_previous_record(post))
            previous_record = []
            prev_language_record = []
            previous_academic_rec = {}
            for rec in admission_id.prev_academic_ids:
                if post.get('update_name_{}'.format(rec.id)):
                    previous_academic_rec.update({'name': post.pop('update_name_{}'.format(rec.id))})
                if post.get('update_if_o_semester_{}'.format(rec.id)) == 'on':
                    semester_id = request.env['other.standard'].sudo().create({'name': post.pop('update_semester_name_{}'.format(rec.id))})
                    previous_academic_rec.update({'semester_id': semester_id.id})
                    post.pop('update_if_o_semester_{}'.format(rec.id))
                else:
                    if post.get('update_semester_id_{}'.format(rec.id)):
                        previous_academic_rec.update({'semester_id': post.get('update_semester_id_{}'.format(rec.id))})
                        post.pop('update_semester_id_{}'.format(rec.id))
                if post.get('update_if_o_division_{}'.format(rec.id)) == 'on':
                    division_id = request.env['other.division'].sudo().create({'name': post.get('update_division_name_{}'.format(rec.id))})
                    post.pop('update_division_name_{}'.format(rec.id))
                    previous_academic_rec.update({'division_id': division_id.id})
                    post.pop('update_if_o_division_{}'.format(rec.id))
                else:
                    if post.get('update_division_id_{}'.format(rec.id)):
                        previous_academic_rec.update({'division_id': post.get('update_division_id_{}'.format(rec.id))})
                        post.pop('update_division_id_{}'.format(rec.id))
                if post.get('update_start_date_{}'.format(rec.id)):
                    previous_academic_rec.update({'start_date': post.pop('update_start_date_{}'.format(rec.id))})
                if post.get('update_end_date_{}'.format(rec.id)):
                    previous_academic_rec.update({'end_date': post.pop('update_end_date_{}'.format(rec.id))})
                if previous_academic_rec:
                    previous_academic_id = rec.sudo().write(previous_academic_rec)
                    previous_record = rec.id
                if post.get('update_semester_id_{}'.format(rec.id)) == False or post.get('update_semester_id_{}'.format(rec.id)):
                    post.pop('update_semester_id_{}'.format(rec.id))
                if post.get('update_division_id_{}'.format(rec.id)) == False or post.get('update_division_id_{}'.format(rec.id)):
                    post.pop('update_division_id_{}'.format(rec.id))
                if post.get('update_division_name_{}'.format(rec.id)) == False or post.get('update_division_name_{}'.format(rec.id)):
                    post.pop('update_division_name_{}'.format(rec.id))
                if post.get('update_semester_name_{}'.format(rec.id)) == False or post.get('update_semester_name_{}'.format(rec.id)):
                    post.pop('update_semester_name_{}'.format(rec.id))
                for line in admission_id.prev_language_ids:
                    if line.academic_id.id == rec.id:
                        line.write({'language': literal_eval(post.pop('update_language_id_{}'.format(rec.id)))})
                if prev_language_record:
                    post['prev_language_ids'] = [(0, 0, line) for line in prev_language_record]
            post.pop('previous_academic_rec')
            if post.get('admission'):
                post.pop('admission')
            document = post.get('document')
            if post.get('document'):
                attached_files = request.httprequest.files.getlist('document')
                for document in attached_files:
                    data = document.read()
                    vals = {
                        'res_model': 'admission.admission',
                        'res_id': admission_id.id,
                        'datas': base64.b64encode(data),
                        'type': 'binary',
                        'name': document.filename,
                    }
                    request.env['ir.attachment'].sudo().create(vals)
            post.pop('document')
            admission_id.sudo().write(post)
        return True

    @http.route('/record/selection', type='json', method="['POST']", auth='public', website=True)
    def record_selection(self, **post):
        values = self.get_related_record()
        return values

    @http.route(['/my/data'], type='json', auth='public')
    def user_image_value(self, image, encoding='base64'):
        partner = request.env.user.partner_id
        if len(image.split(',')) > 1:
            return image

    @http.route('/state/selection', type='json', method="['POST']", auth='public', website=True)
    def state_selection(self, country_id, **post):
        if country_id:
            country = request.env['res.country'].sudo().browse(int(country_id)).ids
            return request.env['res.country.state'].sudo().search_read([('country_id', 'in', country)], ['id', 'name'])

    @http.route('/course/selection', type='json', method="['POST']", auth='public', website=True)
    def course_selection(self, stage_id, **post):
        if stage_id:
            stage = request.env['stage.stage'].sudo().browse(int(stage_id))
            return request.env['course.course'].sudo().search_read([('stage_id', '=', stage.id)], ['id', 'name'])

    @http.route('/batch/selection', type='json', method="['POST']", auth='public', website=True)
    def batch_selection(self, course_id, **post):
        if course_id:
            course = request.env['course.course'].sudo().browse(int(course_id))
            return request.env['batch.batch'].sudo().search_read([('course_id', '=', course.id)], ['id', 'name'])

    @http.route('/stage/selection', type='json', method="['POST']", auth='public', website=True)
    def stage_selection(self, school_id, **post):
        if school_id:
            school = request.env['school.school'].sudo().browse(int(school_id))
            return request.env['stage.stage'].sudo().search_read([('school_id', '=', school.id)], ['id', 'name'])

    @http.route('/set/terms', type='json', method="['POST']", auth='public', website=True)
    def set_terms(self, school_id, **post):
        terms = False
        if school_id:
            school = request.env['school.school'].sudo().browse(int(school_id))
            while school.parent_id:
                if not school.parent_id.parent_id:
                    terms = school.terms_and_conditions
                    break
                else:
                    school = school.parent_id
        return terms

    @http.route('/standard/selection', type='json', method="['POST']", auth='public', website=True)
    def standard_selection(self, batch_id, **post):
        if batch_id:
            semesters = [semester.id for semester in request.env['semester.semester'].sudo().search([]) if semester.semester_history_ids.filtered(lambda x: x.batch_id.id == int(batch_id))]
            semester_id = request.env['semester.semester'].sudo().search_read([('id', 'in', semesters)], ['id', 'name'])
            return semester_id

    # @http.route('/email/validation', type='json', method="['POST']", auth='public', website=True)
    # def email_validation(self, email, **post):
    #     if email:
    #         user_id = request.env['res.users'].sudo().search([('login', '=', email)], limit=1)
    #         if user_id:
    #             return True
    #         else:
    #             return False

    @http.route('/EducationResource/Admission', type='http', auth='public', website=True, csrf=False)
    def admissionForm(self, **post):
        if not request.env.user.sudo().has_group('base.group_public') and request.env.user.partner_id.is_parent:
            post['partner_id'] = request.env.user.partner_id
        values = self.get_values()
        post['institute_ids'] = values.get('institute_ids')
        post['stage_ids'] = values.get('stage_ids')
        post['countries'] = values.get('countries')
        post['middle_name'] = request.env['res.partner'].sudo().search([('is_parent', '=', True)])
        post['religion_ids'] = values.get('religion_ids')
        post['parent_education'] = values.get('parent_education')
        post['blood_group'] = values.get('blood_group')
        post['genders'] = values.get('genders')
        post['school_ids'] = values.get('school_ids')
        post['default_id'] = request.env['res.country'].sudo().search([('code', '=', 'SA')], limit=1)
        post['student_position'] = values.get('student_position')
        post['states'] = values.get('states')
        post['is_parent_died'] = values.get('is_parent_died')
        post['datepicker'] = 1
        return request.render("sync_ems_admission_website.apply4admission", post, {})

    @http.route('/Apply/Admission', type='http', auth='public', website=True)
    def applyadmission(self, **post):
        record, is_user = None, None
        admission = request.env['admission.admission'].sudo()
        post.pop('is_accepted')
        try:
            if post.get('admission'):
                admission_id = request.env['admission.admission'].sudo().browse(int(post.get('admission')))
                try:
                    if len(post) > 1:
                        record = self.update_admission(post)
                except Exception as e:
                    request.env.cr.rollback()
                    return request.redirect("/EducationResource/Admission?error=%s" % tools.ustr(e))
                if record:
                    return request.render("sync_ems_admission_website.thankyou", {'application_no': admission_id.application_number})
                return request.redirect("/EducationResource/Admission?error=Unknown_error")
            else:
                try:
                    if len(post) > 1:
                        document = post.pop('document')
                        post = self.create_admission(post)
                        is_user = post.pop('is_user')
                        record = request.env['admission.admission'].sudo().create(post)
                        attached_files = request.httprequest.files.getlist('document')
                        if record and attached_files:
                            for document in attached_files:
                                if document:
                                    data = document.read()
                                    vals = {
                                        'res_model': 'admission.admission',
                                        'res_id': record.id,
                                        'datas': base64.b64encode(data),
                                        'type': 'binary',
                                        'name': document.filename,
                                    }
                                    request.env['ir.attachment'].sudo().create(vals)
                except Exception as e:
                    request.env.cr.rollback()
                    return request.redirect("/EducationResource/Admission?error=%s" % tools.ustr(e))
                if record:
                    record.onchange_semester_id()
                    record.submit()
                    if not is_user:
                        record.sudo().create_parent_login()
                    return request.render("sync_ems_admission_website.thankyou", {'application_no': record.application_number})
        except Exception as e:
            request.env.cr.rollback()
            return request.redirect("/EducationResource/Admission?error=%s" % tools.ustr(e))

    def get_values(self, admission_id=None):
        values = {}
        school_obj = request.env['school.school'].sudo()
        admission = request.env['admission.admission'].sudo()
        institute_ids = request.env['res.company'].sudo().search([('is_institute', '=', True)])
        semester_ids = request.env['other.standard'].sudo().search([])
        language_ids = request.env['student.language'].sudo().search([])
        division_ids = request.env['other.division'].sudo().search([])
        countries = request.env['res.country'].sudo().search([])
        gender = admission._fields['gender']._description_selection(request.env)
        religion = request.env['religion.religion'].sudo().search([])
        states = request.env['res.country.state'].sudo().search([])
        student_position = admission._fields['position_stud']._description_selection(request.env)
        # Parent School not present filtered
        school_ctx = {'is_parent_school': 1}
        schools = [line.get('id') for line in school_obj.with_context(school_ctx).search_read([],['id'])]
        school_ids = school_obj.with_context(school_ctx).search([('id', 'in', schools)])

        stage_ids = request.env['stage.stage'].sudo().search([('school_id', 'in', school_ids.ids)])
        parent_education = request.env['education.education'].sudo().search([])
        blood_group = request.env['health.health'].sudo()._fields['blood_group']._description_selection(request.env)
        is_parent_died = request.env['admission.admission'].sudo()._fields['is_parent_died']._description_selection(request.env)

        if admission_id:
            stage_ids = request.env['stage.stage'].sudo().search([('school_id', '=', admission_id.school_id.id)])
            course_id = request.env['course.course'].sudo().search([('stage_id', '=', admission_id.stage_id.id)])
            batch_id = request.env['batch.batch'].sudo().search([('course_id', '=', admission_id.course_id.id)])
            semesters = [semester.id for semester in request.env['semester.semester'].search([]) if semester.semester_history_ids.filtered(lambda x: x.batch_id.id == int(admission_id.batch_id.id))]
            semester_id = request.env['semester.semester'].sudo().search([('id', 'in', semesters)])
            values.update({'course_id': course_id,
                            'batch_id': batch_id,
                            'semester_id': semester_id})

        values.update({
            'admission': admission,
            'semester_ids': semester_ids,
            'language_ids': language_ids,
            'division_ids': division_ids,
            'countries': countries,
            'genders': gender,
            'religion_ids': religion,
            'states': states,
            'student_position': student_position,
            'stage_ids': stage_ids,
            'school_ids': school_ids,
            'parent_education': parent_education,
            'blood_group': blood_group,
            'institute_ids': institute_ids,
            'is_parent_died': is_parent_died
        })
        return values

    @http.route(['/EducationResource/Admission/thank-you'],type='http', auth='public', website=True)
    def thankyou(self, **form_data):
        return request.render("sync_ems_admission_website.thankyou", {})
