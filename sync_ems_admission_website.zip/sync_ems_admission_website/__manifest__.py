## -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.


{
    'name': 'Website For Admission Registration',
    'version': '1.0',
    'category': 'web',
    "sequence": 3,
    'summary': 'Admission Registration Process',
    'complexity': "easy",
    'description': """
            Admission registration process through website

    """,
    'author': 'Synconics Technologies Pvt. Ltd.',
    'website': 'http://www.synconics.com',
    'images': [],
    'depends': ['base','web','website','sync_ems_admission'],
    'init_xml': [],

    'data': [
            'views/admission_template_view.xml',
            'views/admission_portal.xml',
            ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
