odoo.define('sync_ems_admission_website.portal_user', function (require){
'use_strict';

    require('web.dom_ready');
    var ajax = require('web.ajax');
    var core = require('web.core');

    var Qweb = core.qweb;
    var _t = core._t;
    var publicWidget = require('web.public.widget');
    var Dialog = require('web.Dialog');
    var semester_id, language_id, $speaking_difficulty, $difficulty_sight_info, $difficulty_listening_info, $other_difficulty_info, gn_helth_status_info, $physical_challenges_info;
    var count = 1;

    ajax.loadXML('/sync_ems_admission_website/static/src/xml/templates.xml', Qweb);
    ajax.jsonRpc("/record/selection", 'call', {})
    .then(function(data){
        semester_id = data['semester_ids']
        language_id = data['language_ids']
        division_id = data['division_ids']
    });
    publicWidget.registry.AddmissionForm = publicWidget.Widget.extend({
        selector: '.ems_apply4admission_form',
        events: {
            'change #school_id': '_onChangeSchool',
            'change #stage_id': '_onChangeStage',
            'change #batch_id': '_onChangeBatch',
            'change #course_id': '_onChangeCourse',
            'change #country_id': '_onChangeCountry',
            'click .add-upload-btn': '_onClickAddBtn',
            'click .remove-upload-btn': '_onClickRemoveBtn'
        },
        /**
         * @override
         */
         start: function () {
            // Initialize datetimepickers
             var datepickers_options = {
                useCurrent: false,
                defaultDate: $('#defaultDate').val(),
                minDate: moment({ y: 1900 }),
                maxDate: moment({ y: 9999, M: 11, d: 31 }),
                calendarWeeks: true,
                icons : {
                    time: 'fa fa-clock-o',
                    date: 'fa fa-calendar',
                    next: 'fa fa-chevron-right',
                    previous: 'fa fa-chevron-left',
                    up: 'fa fa-chevron-up',
                    down: 'fa fa-chevron-down',
                   },
                locale : moment.locale(),
                format : 'DD-MM-YYYY',
            };
            this.$target.find('.o_website_form_date').datetimepicker(datepickers_options);
            return this._super.apply();
        }, 
        /**
         * @private
         */
        selection: function (data, selectField) {
            if (selectField.data('init')===0 || selectField.find('option').length===0) {
                if (data.length) {
                    var opt_default = $('<option>').text('')
                        .attr('value', '')
                        .attr('data-code', '');
                    selectField.append(opt_default);
                    _.each(data, function (x) {
                        var opt = $('<option>').text(x.name)
                            .attr('value', x.id)
                            .attr('data-code', x.name);
                        selectField.append(opt);
                    });
                    selectField.parent('div').show();
                } else {
                    var opt = $('<option>').text('')
                        .attr('value', '')
                        .attr('data-code', '');
                    selectField.append(opt);
                    selectField.parent('div').show();
                }
                selectField.data('init', 0);
            } else {
                selectField.data('init', 0);
            }
        },
        /**
         * @private
         */
        _onChangeSchool: function () {
            var selectstage = $("select[name='stage_id']");
            var self = this;
            selectstage.html('');
            $("#stage_id").html('');
            $("#course_id").html('');
            if (!$("#school_id").val()) {
                $(self.$el).find('.school_terms_conditions').html('')
                $(self.$el).find('.accept_terms_checkbox').addClass('o_hidden')
                return;
            } else{
                ajax.jsonRpc("/stage/selection", 'call', {'school_id': $("#school_id").val()}).then(function (data) {
                    self.selection(data, selectstage)
                });
                ajax.jsonRpc('/set/terms', 'call', {'school_id': $("#school_id").val()}).then(function(data){
                    $(self.$el).find('.school_terms_conditions').html(data)
                    $(self.$el).find('.accept_terms_checkbox').removeClass('o_hidden')
                })
            }
        },
        /**
         * @private
         */
        _onChangeStage: function () {
            var self = this;
            var selectcourse = $("select[name='course_id']");
            selectcourse.html('');
            $("#batch_id").html('');
            $("#semester_id").html('');
            if (!$("#stage_id").val()) {
                return;
            } else{
                ajax.jsonRpc("/course/selection", 'call', {'stage_id': $("#stage_id").val()}).then(function (data) {
                    self.selection(data, selectcourse)
                });
            }
        },
        /**
         * @private
         */
        _onChangeCourse: function () {
            var self = this;
            var selectbatch = $("select[name='batch_id']");
            $("#semester_id").html('');
            selectbatch.html('');
            if (!$("#course_id").val()) {
                return;
            } else{
                ajax.jsonRpc("/batch/selection", 'call', {'course_id': $("#course_id").val()}).then(function (data) {
                    self.selection(data, selectbatch)
                });
            }
        },
        /**
         * @private
         */
        _onChangeBatch: function () {
            var self = this;
            var selectsemester = $("select[name='semester_id']");
            selectsemester.html('');
            if (!$("#batch_id").val()) {
                return;
            } else{
                ajax.jsonRpc("/standard/selection", 'call', {'batch_id': $("#batch_id").val()}).then(function (data) {
                    self.selection(data, selectsemester)
                });
            }
        },
        /**
         * @private
         */
        _onChangeCountry: function () {
            var self = this;
            var selectstate = $("select[name='state_id']");
            selectstate.html('');
            if (!$("#country_id").val()) {
                return;
            } else{
                ajax.jsonRpc("/state/selection", 'call', {'country_id': $("#country_id").val()}).then(function (data) {
                    self.selection(data, selectstate)
                });
            }
        },
        _onClickAddBtn: function (ev) {
            var self = $(this.$el)
            var count = $('input.form-upload-file').length + 1
            var add_more_btn = self.find('.add-new-btn-section')
           $("<div class='upload-file-btn-section' style='height:50px;'><div class='col-md-10'><input type='file' class='form-control col-md-10 mt8 pl0' name='document' accept='image/*,application/pdf' style='border: 0; box-shadow: none; background-color:#f1f1f1; float:left; overflow: hidden;'/></div><span class='remove-upload-btn col-md-2 fa fa-trash-o fa-2x' style='color:#ce0403; text-decoration:none; background-color:transparent;float:right;padding-top:15px;cursor:pointer;'/></div>").insertBefore(add_more_btn);
        },
        _onClickRemoveBtn: function (ev) {
            $(ev.currentTarget).parent().remove()
        }
    });

    $speaking_difficulty = $('.speaking_difficulty').detach();
    $difficulty_sight_info = $('.difficulty_sight_info').detach();
    $difficulty_listening_info = $('.difficulty_listening_info').detach();
    $other_difficulty_info  = $('.other_difficulty_info').detach();
    $gn_helth_status_info = $('.gn_helth_status_info').detach();
    $physical_challenges_info = $('.physical_challenges_info').detach();

    $('#diff_speak').on('change', function () {
        if ($(this).prop('checked') && $speaking_difficulty) {
            $speaking_difficulty.appendTo($('#speaking_difficulty'));
        }
        else{
            $('.speaking_difficulty').detach();
        }
    });
    $('#diff_sight').on('change', function () {
        if ($(this).prop('checked') && $difficulty_sight_info) {
            $difficulty_sight_info.appendTo($('#difficulty_sight_info'));
        }
        else{
            $('.difficulty_sight_info').detach();
        }
    });
    $('#diff_listening').on('change', function () {
        if ($(this).prop('checked') && $difficulty_listening_info) {
            $difficulty_listening_info.appendTo($('#difficulty_listening_info'));
        }
        else{
            $('.difficulty_listening_info').detach();
        }
    });
    $('#other_difficulty').on('change', function () {
        if ($(this).prop('checked') && $other_difficulty_info) {
            $other_difficulty_info.appendTo($('#other_difficulty_info'));
        }
        else{
            $('.other_difficulty_info').detach();
        }
    });
    $('#gn_health_status').on('change', function () {
        if ($(this).prop('checked') && $gn_helth_status_info) {
            $gn_helth_status_info.appendTo($('#gn_health_status_info'));
        }
        else{
            $('.gn_helth_status_info').detach();
        }
    });
    $('#if_other_f_edu').on('change', function () {
        if ($(this).prop('checked')) {
            $('.f_other').removeClass('o_hidden');
            $('#f_education').addClass('o_hidden');
        }
        else{
            $('.f_other').addClass('o_hidden');
            $('#f_education').removeClass('o_hidden');
        }
    });

     $('#if_other_m_edu').on('change', function () {
        if ($(this).prop('checked')) {
            $('.m_other').removeClass('o_hidden');
            $('#m_education').addClass('o_hidden');
        }
        else{
            $('.m_other').addClass('o_hidden');
            $('#m_education').removeClass('o_hidden');
        }
    });

    $('#physical_challenges').on('change', function () {
        if ($(this).prop('checked') && $physical_challenges_info) {
            $physical_challenges_info.appendTo($('#physical_challenges_info'));
        }
        else{
            $('.physical_challenges_info').detach();
        }
    });


    function previoise_semester(ev) {
        var other_semester = ev.currentTarget.id
        var id = ev.currentTarget.id.split("_")[3]
        var selectsemester = $('select[name=semester_id_' + id + ']');
        var textsemester = $('select[name=semester_name' + id + ']');
        if ($('#' + other_semester).prop('checked')) {
            $('select[name=semester_id_' + id + ']').addClass('o_hidden')
            $('input[name=semester_name_' + id + ']').removeClass('o_hidden')
            $('input[name=semester_name_' + id + ']').attr('required', 'required')
            $('select[name=semester_id_' + id + ']').removeAttr('required')
        }
        else{
            $('select[name=semester_id_' + id + ']').attr('required', 'required')
            $('select[name=semester_id_' + id + ']').removeClass('o_hidden')
            $('input[name=semester_name_' + id + ']').addClass('o_hidden')
            $('input[name=semester_name_' + id + ']').removeAttr('required')
        }
    }

    function previoise_division(ev) {
        var other_division = ev.currentTarget.id
        var id = ev.currentTarget.id.split("_")[3]
        var selectdivision = $('select[name=division_id_' + id + ']');
        var textdivision = $('select[name=division_name' + id + ']');
        if ($('#' + other_division).prop('checked')) {
            $('select[name=division_id_' + id + ']').addClass('o_hidden')
            $('input[name=division_name_' + id + ']').removeClass('o_hidden')
            $('input[name=division_name_' + id + ']').attr('required', 'required')
            $('select[name=division_id_' + id + ']').removeAttr('required')
        }
        else{
            $('select[name=division_id_' + id + ']').attr('required', 'required')
            $('select[name=division_id_' + id + ']').removeClass('o_hidden')
            $('input[name=division_name_' + id + ']').addClass('o_hidden')
            $('input[name=division_name_' + id + ']').removeAttr('required')
        }
    }

    function update_previoise_semester(ev) {
        var other_semester = ev.currentTarget.id
        var id = ev.currentTarget.id.split("_")[3]
        var selectsemester = $('select[name=update_semester_id_' + id + ']');
        var textsemester = $('select[name=update_semester_name' + id + ']');
        if ($('#' + other_semester).prop('checked')) {
            $('select[name=update_semester_id_' + id + ']').addClass('o_hidden');
            $('input[name=update_semester_name_' + id + ']').removeClass('o_hidden');
        }
        else{
            $('select[name=update_semester_id_' + id + ']').removeClass('o_hidden')
            $('input[name=update_semester_name_' + id + ']').addClass('o_hidden')
        }
    }

    function update_previoise_division(ev) {
        var other_division = ev.currentTarget.id
        var id = ev.currentTarget.id.split("_")[3]
        var selectdivision = $('select[name=update_division_id_' + id + ']');
        var textdivision = $('select[name=update_division_name' + id + ']');
        if ($('#' + other_division).prop('checked')) {
            $('select[name=update_division_id_' + id + ']').addClass('o_hidden')
            $('input[name=update_division_name_' + id + ']').removeClass('o_hidden')
        }
        else{
            $('select[name=update_division_id_' + id + ']').removeClass('o_hidden')
            $('input[name=update_division_name_' + id + ']').addClass('o_hidden')
        }
    }


    function previous_academic_info(flag) {
            var $PreviousAcademicReport = $(Qweb.render("PreviousAcademicReport", {
                'flag': flag,
                'id': count,
                'semester_id': semester_id,
                'division_id': division_id,
                'language_ids': language_id,
            }));
            $('.oe_button').before($PreviousAcademicReport);
            $('#previous_academic_rec').val(count);
            $PreviousAcademicReport.find('.previous_academic_delete span').on('click', function () {
                $(this).parents('.previous_academic_info_row_add').remove();
            });
            $PreviousAcademicReport.find(".semester_id").on('change', function (ev) {
                var division_id = ev.currentTarget.id.split("_")[2]
                var selectdivis = $('select[name=division_id_' + division_id + ']');
                selectdivis.html('');
                ajax.jsonRpc("/division/selection", 'call', {}).then(function (data) {
                    selection(data, selectdivis)
                });
            });

            $PreviousAcademicReport.find(".if_o_semester").on('change', function (ev) {
                previoise_semester(ev)
            });

            $PreviousAcademicReport.find(".if_o_division").on('change', function (ev) {
                previoise_division(ev)
            });
        }

        $(".if_o_semester").on('change', function (ev) {
                update_previoise_semester(ev);
            });

        $(".if_o_division").on('change', function (ev) {
                update_previoise_division(ev);
            });

        $('#add_previous_academic_ids').click(function (ev) {
            ev.preventDefault();
            previous_academic_info(true);
            count += 1
        });

        function mobile_validate(ev) {
             Dialog.alert(self, _t("Please enter mobile number less 12 digits."), {
                title: _t('Mobile Number is invalid'),
            });
        }

        $(".o_forum_file").change(function () {
            var self = this;
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            if (regex.test($(this).val().toLowerCase())) {
                    if (typeof (FileReader) != "undefined") {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                        var data = e.target.result
                        ajax.jsonRpc('/my/data', 'call', {'image': data,}).then(function (result) {
                                $(".profile_image img").attr("src", result);
                              })
                        }
                       reader.readAsDataURL($(this)[0].files[0]);
                    } else {
                     Dialog.alert(this, _t("This browser does not support FileReader."));
                    return;
                    }
            } else {
                Dialog.alert(this, _t("Please upload a valid image file."));
                    return;

            }
        });
});
