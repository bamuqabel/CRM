# -*- coding: utf-8 -*-
{
    'name': "student Information System Custom event module",
    'author': "Innovative Leading Solutions organization",
    'website': "https://www.ils.com.sa/",
    'category': 'Uncategorized',
    'version': '13.0.1.0.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'website', 'event_sale', 'event','ils_ui'],

    # always loaded
    'data': [
        'views/event_registration_view.xml',
        'views/template.xml',
        'views/product_template.xml',
    ]
}
