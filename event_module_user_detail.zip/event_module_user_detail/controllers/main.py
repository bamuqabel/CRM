# Copyright 2017-2018 Tecnativa - Pedro M. Baeza
# Copyright 2018 Brainbean Apps

import base64
from odoo import http, _
from odoo.http import request
from odoo.addons.website_sale.controllers.main import WebsiteSale
from odoo.addons.website_event_sale.controllers.main import WebsiteEventSaleController

class WebsiteEventSaleControllerCustom(WebsiteEventSaleController):

    @http.route()
    def registration_confirm(self, event, **post):
        registrations = self._process_registration_details(post)
        attachment_obj = request.env['ir.attachment']
        event_tickt_obj = request.env['event.event.ticket']
        for data in registrations:
            ticket = data.get('ticket_id')
            ticket_id = event_tickt_obj.browse(int(ticket))
            data.update({'product_id':ticket_id.product_id.product_tmpl_id.id})
            if ticket_id.product_id.product_tmpl_id.is_program == True:
                attachment_cv = attachment_obj.sudo().create({'name':'uploaded_cv'+'.pdf',
                                                     'datas': base64.b64encode(data.get('cv').read()),
                                                     'res_model': 'res.partner',
                                                     'type': 'binary',
                                                      'mimetype': 'application/x-pdf',
                                                     })
                attachment_national_doc = attachment_obj.sudo().create({'name':'uploaded_national_id'+'.pdf',
                                                                        'datas':base64.b64encode(data.get('national_document').read()),
                                                                        'res_model': 'res.partner',
                                                                        'mimetype': 'application/x-pdf'})
                attachment_commercial_doc = attachment_obj.sudo().create({'name':'uploaded_commercial_id'+'.pdf',
                                                                        'datas':base64.b64encode(data.get('commercial_document').read()),
                                                                        'res_model': 'res.partner',
                                                                        'mimetype': 'application/x-pdf'})
                data.update({'cv':attachment_cv.id,
                             'national_document':attachment_national_doc.id,
                             'commercial_document':attachment_commercial_doc.id})
        request.session['event_dict'] = registrations
        return super(WebsiteEventSaleControllerCustom, self).registration_confirm(event, **post)

class WebsiteSaleCustom(WebsiteSale):

    @http.route()
    def payment_validate(self, transaction_id=None, sale_order_id=None, **post):
        first_name = ""
        father_name = ""
        family_name = ""
        enrollment_name = ""
        academy_name = ""
        attachment_obj = request.env['ir.attachment']
        academy_id = request.env['ils.academy']

        if sale_order_id is None:
            order = request.website.sale_get_order()
        else:
            order = request.env['sale.order'].sudo().browse(sale_order_id)
            assert order.id == request.session.get('sale_last_order_id')
        tx = order.get_portal_last_transaction()         
        if tx:
            event_data_dict = request.session.get('event_dict')
            if event_data_dict != None:
                for event in event_data_dict:
                    program_id = request.env['product.template'].sudo().search([('id','=',int(event.get('product_id')))])
                    if program_id.is_program == True:
                        attachment_cv = attachment_obj.sudo().search([('id','=',event.get('cv'))])
                        national_doc = attachment_obj.sudo().search([('id','=',event.get('national_document'))])
                        commercial_doc = attachment_obj.sudo().search([('id','=',event.get('commercial_document'))])
                        name = event.get('name')
                        split_name_val = name.split(" ", 2)
                        if event.get('academy_id'):
                            academy_id = request.env['ils.academy'].sudo().search([('id','=',int(event.get('academy_id')))])
                        if academy_id and academy_id.id:
                            academy_name = academy_id.name
                        if len(split_name_val) == 1:
                            first_name = split_name_val[0]
                            enrollment_name = first_name+"_"+academy_name
                        if len(split_name_val) == 2:
                            first_name = split_name_val[0]
                            father_name = split_name_val[1]
                            enrollment_name = first_name+"_"+academy_name
                        if len(split_name_val) > 2:
                            first_name = split_name_val[0]
                            father_name = split_name_val[1]
                            family_name = split_name_val[2]
                            enrollment_name = first_name+"_"+family_name+"_"+academy_name
                        partner = request.env['res.partner'].create({'name':event.get('name'),
                                                                     'email':event.get('email'),
                                                                     'mobile':event.get('phone'),
                                                                     'id_num':event.get('national_id'),
                                                                     'gender':event.get('gender-input'),
                                                                     'age':event.get('age'),
                                                                     'region':event.get('region'),
                                                                     'level_of_education':event.get('education-level'),
                                                                     'work_experiance':event.get('work-experiance'),
                                                                     'grocery_owner':event.get('grocery-input'),
                                                                     'city':event.get('city'),
                                                                     'contact_type':'student',
                                                                     # 'commercial_id':event.get('commercial_id'),
                                                                     'first_name':first_name,
                                                                     'father_name':father_name,
                                                                     'family_name':family_name,
                                                                     'is_new_entrepreneur':event.get('entrepreneur-input')
                                                                     })
                        attachment_cv.res_id, national_doc.res_id, commercial_doc.res_id = partner  .id,partner.id,partner.id
                        enrolment_user = request.env['ils.enrollment'].create({'name':enrollment_name.replace(" ", "_"),
                                                                               'code':((program_id.name)+"_"+str(program_id.id)).replace(" ", "_"),
                                                                               'student_id':partner.id,
                                                                               'academy_id':program_id.product_academy_id.id,
                                                                               'program_id':program_id.id})
                request.session['event_dict'] = None  
        return super(WebsiteSaleCustom, self).payment_validate(transaction_id, sale_order_id, **post)
