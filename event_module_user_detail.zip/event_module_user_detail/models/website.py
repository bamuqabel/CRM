# Copyright 2017-2018 Tecnativa - Pedro M. Baeza
# Copyright 2018 Brainbean Apps
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from odoo import models, fields, api, _

class Website(models.Model):
    _inherit = 'website'

    def get_academies(self):
        acadamy_ids = self.env['ils.academy'].search([('active','=',True)])
        return acadamy_ids

    def is_programm_product(self, ticket_line):
        ticket_obj = self.env['event.event.ticket']
        if ticket_line:
            ticket_id = ticket_obj.browse(ticket_line)
            product_id = ticket_id.product_id.product_tmpl_id
            return product_id
        return False