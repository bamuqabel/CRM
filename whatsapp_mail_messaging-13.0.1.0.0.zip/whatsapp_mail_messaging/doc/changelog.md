## Module <whatsapp_mail_messaging>

#### 22.06.2021
#### Version 13.0.1.0.0
#### ADD
- Initial commit




