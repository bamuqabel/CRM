from odoo import fields,models,api,_

class SetJournalLockDate(models.TransientModel):
    _name = 'set.journal.lock.date'
    _description = 'Lock Date Per Journal'

    per = fields.Selection(selection=[('day', 'Day'), ('month', 'Month'), ('date', 'Date')], string='Lock Date Per',
                           default='day')
    can_be_create_before = fields.Integer("Lock Date Before",
                                          help='set x as number of days which you need to lock journal entry before x days')
    no = fields.Integer("Lock Date Before",
                        help='set x as number of months which you need to lock journal entry before x months')
    # days_of_months = fields.Integer('No. of Days', default=30)
    # can_be_create_before_month = fields.Integer(compute='_calc_months_days', store=1)
    date_from = fields.Date('From')
    date_to = fields.Date('To')



    def set_jounal_lock_date(self):
        active_ids = self._context.get('active_ids')
        journal_ids = self.env['account.journal'].browse(active_ids)
        print ('Journal_ids-----------------',journal_ids)

        for journal in journal_ids:
            if self.per=='day' and self.can_be_create_before:
                journal.write({'per':self.per,
                               'can_be_create_before':self.can_be_create_before,
                               })
                print ('------------journal',journal)
            elif self.per == 'month' and self.no:
                journal.write({'per': self.per,
                               'no': self.no,
                               })
                print ('------------journal month',journal)

            elif self.per =='date' and self.date_to and self.date_from:
                journal.write({'per': self.per,
                               'date_from': self.date_from,
                               'date_to': self.date_to})
            if not self.per:
                journal.write({'per': None,})
        return

