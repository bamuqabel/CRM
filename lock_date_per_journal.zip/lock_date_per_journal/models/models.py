# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.osv import osv
from odoo.exceptions import Warning
import time
class AccountJournal(models.Model):
    _inherit = 'account.journal'

    per = fields.Selection(selection=[('day','Day'),('month','Month'),('date','Date')],string='Lock Date Per',default='day')
    can_be_create_before = fields.Integer("Lock Date Before",help='set x as number of days which you need to lock journal entry before x days')
    no = fields.Integer("Lock Date Before",help='set x as number of months which you need to lock journal entry before x months')
    days_of_months = fields.Integer('No. of Days',default=30)
    can_be_create_before_month = fields.Integer(compute='_calc_months_days',store=1)
    date_from = fields.Date('From')
    date_to = fields.Date('To')


    @api.constrains('per','no','days_of_months','can_be_create_before')
    def _calc_months_days(self):
        for journal in self:
            if journal.per == 'month' and journal.no and journal.days_of_months:
                journal.can_be_create_before_month = journal.no * journal.days_of_months
                print('can_be_request_before_month---------------> ',journal.can_be_create_before_month)

class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.constrains('journal_id', 'date')
    def check_before_days(self):
        import datetime
        from dateutil.relativedelta import relativedelta
        date_format = '%Y-%m-%d'
        dt = datetime.datetime.strftime(self.date,date_format)
        if self.date:
            today = datetime.datetime.strptime(time.strftime(date_format), date_format)
            if self.journal_id.per == 'day':
                print('sssssssssssss')
                if self.journal_id.can_be_create_before > 0:
                    temp_before = (today - datetime.timedelta(days=self.journal_id.can_be_create_before)).strftime(
                        date_format)
                    print('sssssssssssss')
                    if dt <= temp_before:
                        raise Warning(_('You can not create entry related to journal "%s" in "%s" or before') %
                                      (self.journal_id.name,temp_before))
                    else:
                        pass
            elif self.journal_id.per == 'month':
                if self.journal_id.can_be_create_before_month > 0:
                    temp_before = (today - relativedelta(months=self.journal_id.no)).strftime(
                        date_format)
                    if dt <= temp_before:
                        raise Warning(_('You can not create entry related to journal "%s" in "%s" or before') %
                                      (self.journal_id.name,temp_before))

                    else:
                        pass
            elif self.journal_id.per == 'date':
                if self.journal_id.date_from and self.journal_id.date_to:
                    print ('Type--------------- ',type(self.journal_id.date_from),' ',type(self.journal_id.date_to))
                    if self.date >= self.journal_id.date_from \
                        and self.date <= self.journal_id.date_to:
                        raise Warning(_('You can not create entry related to journal "%s" in date range from "%s"  to  "%s" ')%
                                      (self.journal_id.name,str(self.journal_id.date_from)
                                       ,str(self.journal_id.date_to)))
                    else:
                        pass
