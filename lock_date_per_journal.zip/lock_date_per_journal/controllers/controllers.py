# -*- coding: utf-8 -*-
from odoo import http

# class ControlJournalEntry(http.Controller):
#     @http.route('/control_journal_entry/control_journal_entry/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/control_journal_entry/control_journal_entry/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('control_journal_entry.listing', {
#             'root': '/control_journal_entry/control_journal_entry',
#             'objects': http.request.env['control_journal_entry.control_journal_entry'].search([]),
#         })

#     @http.route('/control_journal_entry/control_journal_entry/objects/<model("control_journal_entry.control_journal_entry"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('control_journal_entry.object', {
#             'object': obj
#         })