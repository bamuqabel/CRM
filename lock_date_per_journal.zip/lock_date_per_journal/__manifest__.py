# -*- coding: utf-8 -*-
{
    'name': "Lock Date Per journal",

    'summary': """
        """,

    'description': """
         This Module :
           - Will add 3 fields in journal view.
           - Will help you to lock date per journal.
           - Go to Journal menu under configraion menu and select per (days or months), then set number of days or months.
        
    """,

    'author': "Rightechs Solutions",
    'website': "http://www.rightechs.info",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/11.0/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Accounting',
    'version': '12.0',

    # any module necessary for this one to work correctly
    'depends': ['base','account'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'wizard/set_lock_date_wizard.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'currency':'EUR',
    'price':15,
    'license': 'AGPL-3',
}
