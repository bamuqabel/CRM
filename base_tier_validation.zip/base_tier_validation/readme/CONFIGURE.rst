To configure this module, you need to:

#. Go to *Settings > Technical > Tier Validations > Tier Definition*.
#. Create as many tiers as you want for any model having tier validation
   functionality.

**Note:**

* If check **Notify Reviewers on Creation**, all possible reviewers will be notified by email when this definition is triggered.
* If check **Comment**, reviewers can comment after click Validate or Reject.
* If check **Approve by sequence**, reviewers is forced to review by specified sequence.
