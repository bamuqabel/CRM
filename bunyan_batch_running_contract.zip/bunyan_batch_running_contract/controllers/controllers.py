# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanBatchRunningContract(http.Controller):
#     @http.route('/bunyan_batch_running_contract/bunyan_batch_running_contract/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_batch_running_contract/bunyan_batch_running_contract/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_batch_running_contract.listing', {
#             'root': '/bunyan_batch_running_contract/bunyan_batch_running_contract',
#             'objects': http.request.env['bunyan_batch_running_contract.bunyan_batch_running_contract'].search([]),
#         })

#     @http.route('/bunyan_batch_running_contract/bunyan_batch_running_contract/objects/<model("bunyan_batch_running_contract.bunyan_batch_running_contract"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_batch_running_contract.object', {
#             'object': obj
#         })
