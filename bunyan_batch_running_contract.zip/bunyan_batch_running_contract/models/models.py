# -*- coding: utf-8 -*-

from odoo import models


class HrPayslipEmployees(models.TransientModel):
    _inherit = 'hr.payslip.employees'

    def _get_available_contracts_domain(self):
        return [('contract_ids.state', '=', 'open'), ('company_id', '=', self.env.company.id)]
