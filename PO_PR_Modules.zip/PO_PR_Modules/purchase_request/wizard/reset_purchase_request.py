from odoo import models, fields, _


class ResetPurchaseRequestReason(models.TransientModel):
    _name = 'purchase.request.reset.reason'

    reason = fields.Char('Reason', required=1)

    def action_reset_reason(self):
        for rec in self.env['purchase.request'].browse(self._context.get('active_ids', [])):
            if self.reason:
                rec.write({'state': 'draft'})
                rec.message_post(
                    body=_(
                        'This Order has been reset to draft because %s') % self.reason)

        return
