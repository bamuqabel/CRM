# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'res.partner'

    cr_no = fields.Char('CR. No.')


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    partner_address = fields.Char('Partner Address',compute='onchange_partner')
    company_address = fields.Char('Company Address', compute='onchange_partner')
    delivery_address = fields.Char('Delivery Address',compute='onchange_picking_type_id' )

    def action_rfq_send(self):
        '''
        This function opens a window to compose an email, with the edi purchase template message loaded by default
        '''
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            if self.env.context.get('send_rfq', False):
                template_id = ir_model_data.get_object_reference('rightechs_po_report_pdf', 'email_template_pdf_purchase')[1]
            else:
                template_id = ir_model_data.get_object_reference('rightechs_po_report_pdf', 'email_template_pdf_purchase_done')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = dict(self.env.context or {})
        ctx.update({
            'default_model': 'purchase.order',
            'active_model': 'purchase.order',
            'active_id': self.ids[0],
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'custom_layout': "mail.mail_notification_paynow",
            'force_email': True,
            'mark_rfq_as_sent': True,
        })

        # In the case of a RFQ or a PO, we want the "View..." button in line with the state of the
        # object. Therefore, we pass the model description in the context, in the language in which
        # the template is rendered.
        lang = self.env.context.get('lang')
        if {'default_template_id', 'default_model', 'default_res_id'} <= ctx.keys():
            template = self.env['mail.template'].browse(ctx['default_template_id'])
            if template and template.lang:
                lang = template._render_template(template.lang, ctx['default_model'], ctx['default_res_id'])

        self = self.with_context(lang=lang)
        if self.state in ['draft', 'sent']:
            ctx['model_description'] = _('Request for Quotation')
        else:
            ctx['model_description'] = _('Purchase Order')

        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }


    @api.depends('picking_type_id')
    def onchange_picking_type_id(self):
        delivery_address = ''
        if self.picking_type_id:
            if self.picking_type_id.warehouse_id.partner_id:
                if self.picking_type_id.warehouse_id.partner_id.street:
                    delivery_address += self.picking_type_id.warehouse_id.partner_id.street
                if self.picking_type_id.warehouse_id.partner_id.city:
                    delivery_address += '\n - ' + self.picking_type_id.warehouse_id.partner_id.city
                if self.picking_type_id.warehouse_id.partner_id.state_id:
                    delivery_address += '\n - ' + self.picking_type_id.warehouse_id.partner_id.state_id.name
                if self.picking_type_id.warehouse_id.partner_id.zip:
                    delivery_address += '\n - ' + self.company_id.zip
                if self.picking_type_id.warehouse_id.partner_id.country_id:
                    delivery_address += '\n - ' + self.picking_type_id.warehouse_id.partner_id.country_id.name
        self.delivery_address = delivery_address


    @api.depends('partner_id','company_id')
    def onchange_partner(self):
        print('partner_name ', self.partner_id.name)
        address = ''
        comp_address = ''
        if self.company_id:
            if self.company_id.street:
                comp_address += self.company_id.street
            if self.company_id.city:
                comp_address += '\n - ' + self.company_id.city
            if self.company_id.state_id:
                comp_address += '\n - ' + self.company_id.state_id.name
            if self.company_id.zip:
                comp_address += '\n - ' + self.company_id.zip
            if self.company_id.country_id:
                comp_address += '\n - ' + self.company_id.country_id.name
        if self.partner_id:
            if self.partner_id.street:
                address += self.partner_id.street
            if self.partner_id.city:
                address += ' - ' + self.partner_id.city
            if self.partner_id.state_id:
                address += ' - ' + self.partner_id.state_id.name
            if self.partner_id.zip:
                address += ' - ' + self.partner_id.zip
            if self.partner_id.country_id:
                address += ' - ' + self.partner_id.country_id.name
        self.partner_address = address
        self.company_address = comp_address
