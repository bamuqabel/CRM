# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, models, fields, _
from odoo.exceptions import ValidationError, UserError
from odoo.tools.safe_eval import safe_eval
import base64
from odoo.tools import float_compare, float_is_zero


class HrPayslip(models.Model):
    _inherit = "hr.payslip"

    def check_duplicate_record(self):
        for rec in self:
            clause_1 = ['&', ('date_to', '<=', rec.date_to), ('date_to', '>=', rec.date_from)]
            clause_2 = ['&', ('date_from', '<=', rec.date_to), ('date_from', '>=', rec.date_from)]
            clause_3 = ['&', ('date_from', '<=', rec.date_from), '|', ('date_to', '=', False), ('date_to', '>=', rec.date_to)]
            clause_final = [('employee_id', '=', rec.employee_id.id), ('state', '=', 'done'), ('id', '!=', rec.id), '|', '|'] + clause_1 + clause_2 + clause_3
            rec_ids = self.search(clause_final)
            if len(rec_ids) % 2 == 0 and rec.credit_note:
                raise ValidationError(_('You already Refund payslip with same duration of "%s".Kindly check Once.'
                                        % (rec.employee_id.name + ' ' + rec.employee_id.last_name)))
            elif not len(rec_ids) % 2 == 0 and not rec.credit_note:
               raise ValidationError(_('You already generated payslip with same duration of "%s".Kindly check Once.'
                                        % (rec.employee_id.name + ' ' + rec.employee_id.last_name)))

    def send_payslip(self):
        for rec in self:
            if rec.employee_id.work_email:
                template = rec.env.ref('saudi_hr_payroll.send_payslip_mail', raise_if_not_found=False)
                template.send_mail(rec.id)
                rec.is_send = True
            else:
                raise UserError(_("Please Set %s's Email and Confirm Payslip.") % rec.employee_id.name)

    def action_payslip_done(self):
        self.check_duplicate_record()
        if self.env.user.has_group('saudi_hr_payroll.group_send_payslip'):
            self.send_payslip()
        if any(slip.state == 'cancel' for slip in self):
            raise ValidationError(_("You can't validate a cancelled payslip."))
        self.write({'state' : 'done'})
        self.mapped('payslip_run_id').action_close()
        if self.env.context.get('payslip_generate_pdf'):
            for payslip in self:
                if not payslip.struct_id or not payslip.struct_id.report_id:
                    report = self.env.ref('hr_payroll.action_report_payslip', False)
                else:
                    report = payslip.struct_id.report_id
                pdf_content, content_type = report.render_qweb_pdf(payslip.id)
                if payslip.struct_id.report_id.print_report_name:
                    pdf_name = safe_eval(payslip.struct_id.report_id.print_report_name, {'object': payslip})
                else:
                    pdf_name = _("Payslip")
                self.env['ir.attachment'].create({
                    'name': pdf_name,
                    'type': 'binary',
                    'datas': base64.encodestring(pdf_content),
                    'res_model': payslip._name,
                    'res_id': payslip.id
                })
        precision = self.env['decimal.precision'].precision_get('Payroll')

        # Add payslip without run
        payslips_to_post = self.filtered(lambda slip: not slip.payslip_run_id)

        # Adding pay slips from a batch and deleting pay slips with a batch that is not ready for validation.
        payslip_runs = (self - payslips_to_post).mapped('payslip_run_id')
        for run in payslip_runs:
            if run._are_payslips_ready():
                payslips_to_post |= run.slip_ids

        # A payslip need to have a done state and not an accounting move.
        payslips_to_post = payslips_to_post.filtered(lambda slip: slip.state == 'done' and not slip.move_id)

        # Check that a journal exists on all the structures
        if any(not payslip.struct_id for payslip in payslips_to_post):
            raise ValidationError(_('One of the contract for these payslips has no structure type.'))
        if any(not structure.journal_id for structure in payslips_to_post.mapped('struct_id')):
            raise ValidationError(_('One of the payroll structures has no account journal defined on it.'))

        # Map all payslips by structure journal and pay slips month.
        # {'journal_id': {'month': [slip_ids]}}
        slip_mapped_data = {slip.struct_id.journal_id.id: {fields.Date().end_of(slip.date_to, 'month'): self.env['hr.payslip']} for slip in payslips_to_post}
        for slip in payslips_to_post:
            slip_mapped_data[slip.struct_id.journal_id.id][fields.Date().end_of(slip.date_to, 'month')] |= slip
        for journal_id in slip_mapped_data: # For each journal_id.
            for slip_date in slip_mapped_data[journal_id]: # For each month.
                line_ids = []
                # debit_sum = 0.0
                # credit_sum = 0.0
                date = slip_date
                move_dict = {
                    'narration': '',
                    'ref': date.strftime('%B %Y'),
                    'journal_id': journal_id,
                    'date': date,
                }

                for slip in slip_mapped_data[journal_id][slip_date]:
                    debit_sum = 0.0
                    credit_sum = 0.0
                    move_dict['narration'] += slip.number or '' + ' - ' + slip.employee_id.name or ''
                    move_dict['narration'] += '\n'
                    for line in slip.line_ids.filtered(lambda line: line.category_id):
                        amount = -line.total if slip.credit_note else line.total
                        if line.code == 'NET': # Check if the line is the 'Net Salary'.
                            for tmp_line in slip.line_ids.filtered(lambda line: line.category_id):
                                if tmp_line.salary_rule_id.not_computed_in_net: # Check if the rule must be computed in the 'Net Salary' or not.
                                    if amount > 0:
                                        amount -= abs(tmp_line.total)
                                    elif amount < 0:
                                        amount += abs(tmp_line.total)
                        if float_is_zero(amount, precision_digits=precision):
                            continue
                        debit_account_id = line.salary_rule_id.account_debit.id
                        credit_account_id = line.salary_rule_id.account_credit.id

                        if debit_account_id: # If the rule has a debit account.
                            debit = amount if amount > 0.0 else 0.0
                            credit = -amount if amount < 0.0 else 0.0

                            existing_debit_lines = (
                                line_id for line_id in line_ids if
                                line_id['name'] == line.name
                                and line_id['employee_id'] == slip.employee_id.id
                                and line_id['account_id'] == debit_account_id
                                and line_id['analytic_account_id'] == (line.salary_rule_id.analytic_account_id.id or slip.contract_id.analytic_account_id.id)
                                and line_id['analytic_tag_ids'] == slip.contract_id.analytic_tag_ids.ids
                                and line_id['branch_id'] == slip.employee_id.branch_id.id
                                and ((line_id['debit'] > 0 and credit <= 0) or (line_id['credit'] > 0 and debit <= 0))
                                )
                            debit_line = next(existing_debit_lines, False)

                            if not debit_line:
                                debit_line = {
                                    'name': line.name,
                                    'partner_id': False,
                                    'account_id': debit_account_id,
                                    'journal_id': slip.struct_id.journal_id.id,
                                    'employee_id': slip.employee_id.id,
                                    'date': date,
                                    'debit': debit,
                                    'credit': credit,
                                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id or slip.contract_id.analytic_account_id.id,
                                    'branch_id': slip.employee_id.branch_id.id or False,
                                    'analytic_tag_ids': [(6, 0, slip.contract_id.analytic_tag_ids.ids)] or False
                                }
                                line_ids.append(debit_line)
                            else:
                                debit_line['debit'] += debit
                                debit_line['credit'] += credit
                        
                        if credit_account_id: # If the rule has a credit account.
                            debit = -amount if amount < 0.0 else 0.0
                            credit = amount if amount > 0.0 else 0.0
                            existing_credit_line = (
                                line_id for line_id in line_ids if
                                line_id['name'] == line.name
                                and line_id['employee_id'] == slip.employee_id.id
                                and line_id['account_id'] == credit_account_id
                                and line_id['analytic_account_id'] == (line.salary_rule_id.analytic_account_id.id or slip.contract_id.analytic_account_id.id)
                                and line_id['analytic_tag_ids'] == slip.contract_id.analytic_tag_ids.ids
                                and line_id['branch_id'] == slip.employee_id.branch_id.id
                                and ((line_id['debit'] > 0 and credit <= 0) or (line_id['credit'] > 0 and debit <= 0))
                            )
                            credit_line = next(existing_credit_line, False)

                            if not credit_line:
                                credit_line = {
                                    'name': line.name,
                                    'partner_id': False,
                                    'account_id': credit_account_id,
                                    'journal_id': slip.struct_id.journal_id.id,
                                    'employee_id': slip.employee_id.id,
                                    'date': date,
                                    'debit': debit,
                                    'credit': credit,
                                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id or slip.contract_id.analytic_account_id.id,
                                    'branch_id': slip.employee_id.branch_id.id or False,
                                    'analytic_tag_ids': [(6, 0, slip.contract_id.analytic_tag_ids.ids)] or False
                                }
                                line_ids.append(credit_line)
                            else:
                                credit_line['debit'] += debit
                                credit_line['credit'] += credit

                    for line_id in line_ids: # Get the debit and credit sum.
                        debit_sum += line_id['debit']
                        credit_sum += line_id['credit']
                    # The code below is called if there is an error in the balance between credit and debit sum.
                    if float_compare(credit_sum, debit_sum, precision_digits=precision) == -1:
                        acc_id = slip.journal_id.default_credit_account_id.id
                        if not acc_id:
                            raise UserError(_('The Expense Journal "%s" has not properly configured the Credit Account!') % (slip.journal_id.name))
                        existing_adjustment_line = (
                            line_id for line_id in line_ids if line_id['name'] == _('Adjustment Entry')
                            and line_id['employee_id'] == slip.employee_id.id
                        )
                        adjust_credit = next(existing_adjustment_line, False)
                        if not adjust_credit:
                            adjust_credit = {
                                'name': _('Adjustment Entry'),
                                'partner_id': False,
                                'account_id': acc_id,
                                'journal_id': slip.journal_id.id,
                                'employee_id': slip.employee_id.id,
                                'date': date,
                                'debit': 0.0,
                                'credit': debit_sum - credit_sum,
                                'branch_id': slip.employee_id.branch_id.id or False,
                                'analytic_tag_ids': [(6, 0, slip.contract_id.analytic_tag_ids.ids)] or False
                            }
                            line_ids.append(adjust_credit)
                        else:
                            adjust_credit['credit'] = debit_sum - credit_sum

                    elif float_compare(debit_sum, credit_sum, precision_digits=precision) == -1:
                        acc_id = slip.journal_id.default_debit_account_id.id
                        if not acc_id:
                            raise UserError(_('The Expense Journal "%s" has not properly configured the Debit Account!') % (slip.journal_id.name))
                        existing_adjustment_line = (
                            line_id for line_id in line_ids if line_id['name'] == _('Adjustment Entry')
                            and line_id['employee_id'] == slip.employee_id.id
                        )
                        adjust_debit = next(existing_adjustment_line, False)

                        if not adjust_debit:
                            adjust_debit = {
                                'name': _('Adjustment Entry'),
                                'partner_id': False,
                                'account_id': acc_id,
                                'journal_id': slip.journal_id.id,
                                'employee_id': slip.employee_id.id,
                                'date': date,
                                'debit': credit_sum - debit_sum,
                                'credit': 0.0,
                                'branch_id': slip.employee_id.branch_id.id or False,
                                'analytic_tag_ids': [(6, 0, slip.contract_id.analytic_tag_ids.ids)] or False
                            }
                            line_ids.append(adjust_debit)
                        else:
                            adjust_debit['debit'] = credit_sum - debit_sum

                # Add accounting lines in the move
                move_dict['line_ids'] = [(0, 0, line_vals) for line_vals in line_ids]
                move = self.env['account.move'].create(move_dict)
                for slip in slip_mapped_data[journal_id][slip_date]:
                    slip.write({'move_id': move.id, 'date': date})
        # res = super(HrPayslip, self).action_payslip_done()
        # for payslip in self:
        #     if payslip.move_id:
        #         payslip.move_id.branch_id = payslip.employee_id.branch_id.id
                # line_vals = {'branch_id': payslip.employee_id.branch_id.id or False,
                #             'analytic_tag_ids': [(6, 0, payslip.contract_id.analytic_tag_ids.ids)] or False}
        #         # if payslip.contract_id.analytic_account_id:
        #         #     line_vals.update({'analytic_account_id': payslip.contract_id.analytic_account_id.id or False})
        #         move_id = payslip.move_id.id
        #         line_ids = self.env['account.move.line'].search([('move_id', '=', move_id), ('employee_id', '=', payslip.employee_id.id)])
        #         line_ids.write(line_vals)
        # return res

    def _get_payment_days(self):
        for line in self:
            nb_of_days = (line.date_to - line.date_from).days + 1
            # We will set it to 30 as our calculation is based on 30 days for your company
            month = line.date_from.month
            if nb_of_days > 30 or month == 2 and nb_of_days in (28, 29):
                nb_of_days = 30
            line.payment_days = nb_of_days

    def _get_first_month_days(self):
        for line in self:
            if not line.employee_id.date_of_join:
                raise UserError(_("Please enter 'Joining Date' of Employee first!"))
            number_of_days = (line.date_to - line.employee_id.date_of_join).days + 1
            line.first_month_days = number_of_days

    payment_days = fields.Float(compute='_get_payment_days', string='Payment Day(s)')
    first_month_days = fields.Float(compute='_get_first_month_days', string='No of day(s)')
    is_send = fields.Boolean(default=False, store=True)

    def get_other_allowance_deduction(self, employee_id, date_from, date_to):
        domain = [('employee_id', '=', employee_id.id),
                  ('payslip_id', '=', False), ('state', 'in', ['done']),
                  ('date', '>=', date_from), ('date', '<=', date_to)]
        other_ids = self.env['other.hr.payslip'].search(domain)
        res = []
        if other_ids:
            alw_no_of_days = alw_no_of_hours = alw_percentage = alw_amt = 0.0
            ded_no_of_days = ded_no_of_hours = ded_percentage = ded_amt = 0.0

            other_input_lines = {}

            for other in other_ids:
                if other.operation_type == 'allowance':
                    if other.calc_type == 'amount':
                        alw_amt += other.amount
                        if 'OTHER_ALLOWANCE_AMOUNT' not in other_input_lines:
                            other_input_lines['OTHER_ALLOWANCE_AMOUNT'] = alw_amt
                        else:
                            other_input_lines.update({'OTHER_ALLOWANCE_AMOUNT': alw_amt})
                    elif other.calc_type == 'days':
                        alw_no_of_days += other.no_of_days
                        if 'OTHER_ALLOWANCE_DAYS' not in other_input_lines:
                            other_input_lines['OTHER_ALLOWANCE_DAYS'] = alw_no_of_days
                        else:
                            other_input_lines.update({'OTHER_ALLOWANCE_DAYS': alw_no_of_days})
                    elif other.calc_type == 'hours':
                        alw_no_of_hours += other.no_of_hours
                        if 'OTHER_ALLOWANCE_HOURS' not in other_input_lines:
                            other_input_lines['OTHER_ALLOWANCE_HOURS'] = alw_no_of_hours
                        else:
                            other_input_lines.update({'OTHER_ALLOWANCE_HOURS': alw_no_of_hours})
                    elif other.calc_type == 'percentage':
                        alw_percentage += other.percentage
                        if 'OTHER_ALLOWANCE_PERCENTAGE' not in other_input_lines:
                            other_input_lines['OTHER_ALLOWANCE_PERCENTAGE'] = alw_percentage
                        else:
                            other_input_lines.update({'OTHER_ALLOWANCE_PERCENTAGE': alw_percentage})

                elif other.operation_type == 'deduction':
                    if other.calc_type == 'amount':
                        ded_amt += other.amount
                        if 'OTHER_DEDUCTION_AMOUNT' not in other_input_lines:
                            other_input_lines['OTHER_DEDUCTION_AMOUNT'] = ded_amt
                        else:
                            other_input_lines.update({'OTHER_DEDUCTION_AMOUNT': ded_amt})
                    elif other.calc_type == 'days':
                        ded_no_of_days += other.no_of_days
                        if 'OTHER_DEDUCTION_DAYS' not in other_input_lines:
                            other_input_lines['OTHER_DEDUCTION_DAYS'] = ded_no_of_days
                        else:
                            other_input_lines.update({'OTHER_DEDUCTION_DAYS': ded_no_of_days})
                    elif other.calc_type == 'hours':
                        ded_no_of_hours += other.no_of_hours
                        if 'OTHER_DEDUCTION_HOURS' not in other_input_lines:
                            other_input_lines['OTHER_DEDUCTION_HOURS'] = ded_no_of_hours
                        else:
                            other_input_lines.update({'OTHER_DEDUCTION_HOURS': ded_no_of_hours})
                    elif other.calc_type == 'percentage':
                        ded_percentage += other.percentage
                        if 'OTHER_DEDUCTION_PERCENTAGE' not in other_input_lines:
                            other_input_lines['OTHER_DEDUCTION_PERCENTAGE'] = ded_percentage
                        else:
                            other_input_lines.update({'OTHER_DEDUCTION_PERCENTAGE': ded_percentage})

            for code, amount in other_input_lines.items():
                res.append({'code': code, 'amount': amount})
        return res

    @api.onchange('employee_id', 'struct_id', 'contract_id', 'date_from', 'date_to')
    def _onchange_employee(self):
        res = super()._onchange_employee()
        other_types = {
            'OTHER_ALLOWANCE_AMOUNT': self.env.ref('saudi_hr_payroll.other_allowance_amount_input').id,
            'OTHER_ALLOWANCE_DAYS': self.env.ref('saudi_hr_payroll.other_allowance_days_input').id,
            'OTHER_ALLOWANCE_HOURS': self.env.ref('saudi_hr_payroll.other_allowance_hours_input').id,
            'OTHER_ALLOWANCE_PERCENTAGE': self.env.ref('saudi_hr_payroll.other_allowance_percentage_input').id,
            'OTHER_DEDUCTION_AMOUNT': self.env.ref('saudi_hr_payroll.other_deduction_amount_input').id,
            'OTHER_DEDUCTION_DAYS': self.env.ref('saudi_hr_payroll.other_deduction_days_input').id,
            'OTHER_DEDUCTION_HOURS': self.env.ref('saudi_hr_payroll.other_deduction_hours_input').id,
            'OTHER_DEDUCTION_PERCENTAGE': self.env.ref('saudi_hr_payroll.other_deduction_percentage_input').id,
        }
        if not self.contract_id:
            lines_to_remove = self.input_line_ids.filtered(lambda x: x.input_type_id.id in other_types.values())
            self.update({'input_line_ids': [(3, line.id, False) for line in lines_to_remove]})

        other_allowance_data = self.get_other_allowance_deduction(self.employee_id, self.date_from, self.date_to)
        if other_allowance_data:
            lines_to_keep = self.input_line_ids.filtered(lambda x: x.input_type_id.id not in other_types.values())
            input_line_vals = [(5, 0, 0)] + [(4, line.id, False) for line in lines_to_keep]

            for other_type in other_allowance_data:
                if other_types.get(other_type['code']):
                    input_line_vals.append((0, 0, {
                        'amount': other_type['amount'],
                        'input_type_id': other_types[other_type['code']],
                    }))
            self.update({'input_line_ids': input_line_vals})
        return res


class AccountMoveLine(models.Model):
    _name = 'account.move.line'
    _inherit = 'account.move.line'

    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=False, )
