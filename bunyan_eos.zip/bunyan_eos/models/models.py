# -*- coding: utf-8 -*-

from odoo import models, fields, _, api
from dateutil import relativedelta
from datetime import date
from odoo.exceptions import UserError


class EmployeeEOS(models.Model):
    _name = 'hr.employee.eos'
    _inherit = 'hr.employee.eos'

    type = fields.Selection(selection_add=[('agreed_termination', 'Contract Ending - Mutual Agreement'), ('no_benefits', 'Contract Ending - No Benefits')])
    agreed_termination_months = fields.Integer(string="No. of Months", required=False, )
    total_award_eos_months = fields.Float(string="Total Agreed Months",  default=0.0, )
    payable_eos = fields.Float(compute="_calc_payable_eos", string='Total Amount')

    # TODO : Add constraints on agreed_termination months to be greater than 0 if type='agreed_termination'

    def calc_eos(self):
        """
            Calculate eos
        """
        res = super(EmployeeEOS, self).calc_eos()
        payslip_obj = self.env['hr.payslip']
        for eos in self:
            if eos.type == 'no_benefits':
                eos.total_eos = 0.0
            if eos.type == 'agreed_termination':
                selected_month = eos.date_of_leave.month
                selected2_month = eos.date_of_leave.month + 2
                selected_year = eos.date_of_leave.year
                selected2_year = eos.date_of_leave.year + 2
                date_from = date(selected_year, selected_month, 1)
                date2_from = date(selected2_year, selected2_month, 1)
                date_to = date_from + relativedelta.relativedelta(day=eos.date_of_leave.day)
                date2_to = date2_from + relativedelta.relativedelta(months=1) + relativedelta.relativedelta(days=-1)
                contract_ids = eos.employee_id._get_contracts(date_from, date_to, states=['open', 'close'])

                values = {
                    'name': eos.employee_id.name,
                    'employee_id': eos.employee_id.id or False,
                    'date_from': date2_from,
                    'date_to': date2_to,
                    'contract_id': contract_ids[0].id,
                }
                payslip_final_id = payslip_obj.create(values)
                payslip_final_id.compute_sheet()
                payslip_net_final = payslip_final_id.line_ids.search([('code', '=', 'NET'), ('slip_id', '=', payslip_final_id.id)], limit=1)
                if payslip_net_final:
                    eos.total_award_eos_months = eos.agreed_termination_months * payslip_net_final.total

                payslip_final_id.action_payslip_cancel()
                payslip_final_id.unlink()
            else:
                eos.total_award_eos_months = 0.0
        return res

    def _calc_payable_eos(self):
        """
            Calculate the payable eos
        """
        for eos_amt in self:
            eos_amt.payable_eos = (eos_amt.total_eos + eos_amt.current_month_salary + eos_amt.others + eos_amt.annual_leave_amount + eos_amt.total_award_eos_months) or 0.0

