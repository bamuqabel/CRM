# -*- coding: utf-8 -*-
# from odoo import http


# class BunyanEos(http.Controller):
#     @http.route('/bunyan_eos/bunyan_eos/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bunyan_eos/bunyan_eos/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bunyan_eos.listing', {
#             'root': '/bunyan_eos/bunyan_eos',
#             'objects': http.request.env['bunyan_eos.bunyan_eos'].search([]),
#         })

#     @http.route('/bunyan_eos/bunyan_eos/objects/<model("bunyan_eos.bunyan_eos"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bunyan_eos.object', {
#             'object': obj
#         })
